# Pipedrive Deal Product Editor

A Pipedrive Custom UI app. On a deal it shows the attached products and lets you edit them in an editor that mirrors Pipedrive's native "Add products to deal" window, plus **Min** and **Max** fields.

**Min and Max live on the product records in Pipedrive's Products module**, not in this app's database. The app only stores OAuth tokens.

## How Min/Max work

Other deals may use the same product, so the app never edits an existing product's Min/Max.

| What the user does | What happens |
|---|---|
| Picks an existing product, leaves Min/Max alone | The product is attached to the deal as is. |
| Picks an existing product and changes Min and/or Max | A **new product** is created in the Products list (a copy of the original with the new Min/Max) and attached to the deal. If a product with the same name, code, Min and Max already exists, it is reused. The original is untouched. |
| Types a new name and chooses "Create new product" | The product is created in the Products list with the entered Min/Max, then attached. |
| Edits price, quantity, discount, tax, comments or the on/off toggle | Only the deal line is updated. |
| Removes a row | Only the deal line is deleted. The product stays in the Products list. |

If the product behind a deal line changes, the new line is attached first and the old one deleted second, so a failure never loses data. If Pipedrive rejects a duplicate product name or code, the row shows the error and nothing is attached.

## Architecture

- `server/` Node 20+ / Express. OAuth callback, token refresh, JWT verification, Pipedrive API v2 calls, save logic.
- `client/` React (Vite). `/` is the deal panel, `/modal` is the editor popup.
- Postgres (any hosted one) stores one token set per Pipedrive company and user.

Security design:
- The panel's signed token (JWT, signed with your client secret) is verified on every API call. It proves the page was loaded by Pipedrive for a given user and company.
- **The token does not contain the deal ID.** The deal ID comes from the page URL, which a user could change. So every call uses **that user's own OAuth token**, and Pipedrive itself decides whether they may see the deal. Each Pipedrive user therefore has to authorize the app once.
- The page can only be embedded by `*.pipedrive.com` (`frame-ancestors`).
- Secrets are environment variables only. Nothing secret reaches the browser.
- Comment HTML is sanitised on the server (bold, italic, underline, lists and http(s) links only).

## Free-tier deployment (about 20 minutes)

You need accounts on GitHub, Render and Neon. All three have free plans at the time of writing. Check each site for current limits.

### 1. Pipedrive: create the Min and Max fields
Pipedrive > Settings > Data fields > Products > add two **Numerical** fields named exactly `Min` and `Max`.

### 2. Database (Neon)
1. Create a project at neon.tech.
2. Copy the connection string (it ends in `?sslmode=require`). This is your `DATABASE_URL`.
3. The table is created automatically on first start. You can also run `npm run db:init`.

### 3. Code to GitHub
Create a repository and push this folder. `.gitignore` already excludes `node_modules`, `client/dist` and `.env`.

### 4. Host (Render)
1. New > Web Service > connect the repository.
2. Runtime **Node**, instance type **Free**.
3. Build command: `npm install && npm run build`
4. Start command: `npm start`
5. Environment variables: `NODE_VERSION=22`, `PIPEDRIVE_CLIENT_ID`, `PIPEDRIVE_CLIENT_SECRET`, `PIPEDRIVE_REDIRECT_URI`, `DATABASE_URL`. Add `MODAL_ACTION_ID` later (step 6).
6. Note your URL, for example `https://pipedrive-product-editor.onrender.com`.

Or use `render.yaml` as a Blueprint. The free web service sleeps after about 15 minutes without traffic, so the first load after a pause can take 30 to 60 seconds. For exploring, that is fine. For real use, use a paid always-on instance.

### 5. Pipedrive Developer Hub
Create a new app (a draft app, not a public one). Then:

- **OAuth & access scopes:** Deals: **Full access**, Products: **Full access**. `base` is always on. These cover everything the app calls.
- **Callback URL:** `https://YOUR-APP.onrender.com/auth/pipedrive/callback`. It must be identical to the `PIPEDRIVE_REDIRECT_URI` variable.
- **App extensions > Custom panel:** location **Deal > Details view**, panel URL `https://YOUR-APP.onrender.com/`. Leave the JWT secret empty (the client secret is used).
- **App extensions > Custom modal:** URL `https://YOUR-APP.onrender.com/modal`. Choose the largest size available. Copy the modal's **ID**.

### 6. Connect the modal
Set `MODAL_ACTION_ID` on Render to that ID and redeploy. Without it, "Edit products" opens the same editor inside the panel instead.

### 7. Install and authorize
Use "Install & test" in Developer Hub on your sandbox account and approve. This runs the OAuth flow and stores your tokens. Every other user who opens the panel sees an **Authorize** button once.

If you change scopes later, Pipedrive asks everyone to re-authorize. The callback is a server route, so this works.

## Environment variables

| Variable | Required | Purpose |
|---|---|---|
| `PIPEDRIVE_CLIENT_ID` | yes | OAuth client ID |
| `PIPEDRIVE_CLIENT_SECRET` | yes | OAuth client secret. Also verifies panel tokens |
| `PIPEDRIVE_REDIRECT_URI` | yes | Callback URL, same as in Developer Hub |
| `DATABASE_URL` | yes in production | Postgres connection string. Empty means in-memory tokens (lost on restart) |
| `MODAL_ACTION_ID` | recommended | ID of the Custom modal extension |
| `PIPEDRIVE_JWT_SECRET` | no | Only if you set a JWT secret on the extension |
| `PRODUCT_MIN_FIELD_KEY`, `PRODUCT_MAX_FIELD_KEY` | no | Field keys, only if there are several fields named Min/Max |
| `PORT` | no | Set by Render |

## Local development

```bash
npm install
npm run build        # installs and builds the client
cp .env.example .env # fill in values
npm run dev          # http://localhost:3000
npm test             # backend tests against a fake Pipedrive
```

Browser test (needs Python Playwright):
```bash
node server/test/e2eServer.js > info.log &   # starts the app and a fake Pipedrive on ports 4101/4102
grep '"ready"' info.log > info.json
python3 client/test/e2e.py info.json ./screenshots
```

## What is and is not verified

Verified by automated tests against a **fake** Pipedrive: the OAuth callback and token storage, token refresh and rotation, JWT rejection (forged, missing, `alg: none`), all Min/Max rules, retry safety, validation, sanitising (27 backend tests), and the full editor in a real browser (27 checks).

The backend tests also ran against a real local PostgreSQL 16 (`TEST_DATABASE_URL=postgresql://... npm test`). A hosted Neon database was **not** tried: the app connects to non-local databases with TLS certificate verification on, which Neon supports, but confirm it on your first deploy.

**Not verified: any call to the real Pipedrive.** I had no credentials, and nothing here claims the connection works until you have run it. Endpoint paths and field names were checked against Pipedrive's documentation, but these assumptions still need your first real test:

1. Product custom fields are read and written as `custom_fields: { "<field_key>": number }` (API v2 format).
2. Deal product `comments` accepts the HTML the rich-text box produces (the native editor has formatting, so it should).
3. `GET /api/v2/products?ids=` works. If not, the app falls back to fetching products one by one.
4. Your account allows duplicate product names. If not, the row shows Pipedrive's error and nothing is attached.
5. The deal ID arrives in the panel URL as `selectedIds`. Opening the modal passes it as `dealId`.

## Limitations

- **Row reordering** is not supported: I found no way to set the order through the API.
- **Additional discounts** (the native "Add discount") are not built. The discounts endpoints exist but I did not verify them.
- **Deal currency** is shown but cannot be changed here.
- **Billing frequency and Installments** (paid-plan features) are not included.
- Tax method is deal-wide in Pipedrive, so changing "Amounts are" affects every product on the deal.
- Tokens are stored as plain text in your database. For stronger protection, add column encryption and use a database that is not publicly reachable.
- No rate limiting on this app's own API. Pipedrive's limits apply.

## Manual test checklist

1. Open the sandbox deal. The panel shows the **Authorize** button, or your products if already authorized.
2. Click Authorize, approve, and reload. The callback page says "Authorized" (not the React UI).
3. Open the panel and check the product list with Min/Max chips.
4. Click **Edit products**. The editor opens as a popup.
5. Add an existing product via the dropdown, leave Min/Max alone, Save. Check the Products list: **no** new product.
6. Add an existing product, change Max, Save. Check the Products list: a new product with the new Max exists and the original still has its old value.
7. Repeat step 6 with the same values on another deal. The existing variant is reused (the message says so).
8. Type a new product name, choose "Create new product", set Min/Max, Save. It appears in Products with those values.
9. Edit price, quantity, discount and tax. Toggle a row off. Save and check the deal value in Pipedrive.
10. Remove a row, Save. The deal line is gone and the product is still in Products.
11. Enter quantity 0 or Min greater than Max. Save is blocked with a message.
12. Open a second deal that has the same product. It shows the product's Min/Max.
13. Open the deal as a second Pipedrive user. They see **Authorize** once.
14. Leave the app idle for an hour, then open it again. Token refresh happens silently.
