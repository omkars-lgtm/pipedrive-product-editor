import { loadConfig } from './config.js';
import { createStore } from './store.js';

const config = loadConfig();
if (!config.databaseUrl) {
  console.error('DATABASE_URL is not set. Nothing to initialise.');
  process.exit(1);
}
const store = createStore(config.databaseUrl);
await store.init();
console.log('Database ready (installations table exists).');
await store.close();
