import express from 'express';
import jwt from 'jsonwebtoken';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createPipedrive, PdError } from './pipedrive.js';
import * as pd from './domain.js';
import { processSave } from './save.js';
import { suggestAddress, makeLimiter } from './geocode.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const page = (title, body) => `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(title)}</title><style>body{font:16px system-ui,sans-serif;max-width:520px;margin:15vh auto;padding:0 20px;color:#222}
h1{font-size:22px}p{color:#555;line-height:1.5}</style></head><body>${body}</body></html>`;

export function createApp({ config, store, fetchImpl = fetch, geoFetch = fetch }) {
  const app = express();
  const client = createPipedrive({ config, store, fetchImpl });

  app.disable('x-powered-by');
  app.set('trust proxy', 1);
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    const frame = `frame-ancestors ${config.frameAncestors}`;
    res.setHeader('Content-Security-Policy',
      req.path.startsWith('/api/') || req.path.startsWith('/auth/')
        ? frame
        : `default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; ${frame}`);
    next();
  });
  app.use(express.json({ limit: '256kb' }));

  app.get('/healthz', (req, res) => res.json({ ok: true, store: store.kind }));

  // ---------- OAuth ----------
  app.get('/auth/pipedrive', (req, res) => {
    if (!config.clientId || !config.redirectUri) return res.status(500).send(page('Not configured', '<h1>Not configured</h1><p>PIPEDRIVE_CLIENT_ID and PIPEDRIVE_REDIRECT_URI must be set on the server.</p>'));
    const url = new URL('/oauth/authorize', config.oauthBase);
    url.searchParams.set('client_id', config.clientId);
    url.searchParams.set('redirect_uri', config.redirectUri);
    res.redirect(url.toString());
  });

  // Registered BEFORE the static/SPA handlers so it can never render the React page.
  app.get('/auth/pipedrive/callback', async (req, res) => {
    const { code, error } = req.query;
    if (error || typeof code !== 'string' || !code) {
      client.log('callback.missing_code', 400, String(error || ''));
      return res.status(400).send(page('Authorization failed', `<h1>Authorization was not completed</h1><p>${esc(error || 'No authorization code was received.')} Go back to Pipedrive and try again.</p>`));
    }
    try {
      const t = await client.exchangeCode(code);
      const apiDomain = client.checkApiDomain(t.api_domain);
      const tmp = { rec: { apiDomain, accessToken: t.access_token } };
      const me = await client.request(tmp, 'GET', '/v1/users/me');
      const companyId = Number(me?.data?.company_id);
      const userId = Number(me?.data?.id);
      if (!companyId || !userId) throw new PdError(502, 'Could not read the user and company from Pipedrive');
      await store.save({
        companyId, userId,
        accessToken: t.access_token,
        refreshToken: t.refresh_token,
        expiresAt: Date.now() + (Number(t.expires_in) || 3600) * 1000,
        apiDomain,
        scope: t.scope || '',
      });
      client.log('callback.saved', 200);
      res.send(page('Authorized', '<h1>Authorized</h1><p>You can close this tab and reload the deal in Pipedrive.</p>'));
    } catch (e) {
      client.log('callback.failed', e.status || 500, e.code || '');
      const hint = e.code === 'INVALID_GRANT'
        ? 'The code was already used or expired, or the redirect URI does not match the Callback URL in Developer Hub. Start the authorization again.'
        : 'Check the server logs for the failing step.';
      res.status(e.status && e.status < 600 ? e.status : 500).send(page('Authorization failed', `<h1>Authorization failed</h1><p>${esc(hint)}</p>`));
    }
  });

  // ---------- API auth ----------
  function authenticate(req, res, next) {
    const token = req.get('x-pd-token');
    if (!token) return res.status(401).json({ error: 'Missing Pipedrive token. Open this app from inside Pipedrive.', code: 'NO_TOKEN' });
    const secrets = [config.jwtSecret, config.clientSecret].filter(Boolean);
    let payload = null;
    for (const secret of secrets) {
      try { payload = jwt.verify(token, secret, { algorithms: ['HS256'] }); break; } catch { /* try next secret */ }
    }
    const companyId = Number(payload?.companyId);
    const userId = Number(payload?.userId);
    if (!payload || !companyId || !userId) {
      return res.status(401).json({ error: 'Invalid or expired Pipedrive token. Reload the page.', code: 'BAD_TOKEN' });
    }
    req.pd = { companyId, userId };
    req.store = store;
    next();
  }

  const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);

  async function withSession(req, res, next) {
    try {
      req.session = await client.openSession(req.pd.companyId, req.pd.userId);
      next();
    } catch (e) { next(e); }
  }

  const dealIdOf = (req) => {
    const id = Number(req.params.dealId);
    if (!Number.isInteger(id) || id <= 0) throw new PdError(400, 'Invalid deal id', 'BAD_DEAL');
    return id;
  };

  app.get('/api/config', (req, res) => {
    res.json({ modalActionId: config.modalActionId || null, authorizeUrl: '/auth/pipedrive' });
  });

  app.get('/api/deals/:dealId/bootstrap', authenticate, withSession, wrap(async (req, res) => {
    const dealId = dealIdOf(req);
    const s = req.session;
    const deal = await pd.getDeal(s, dealId); // access check with THIS user's permissions
    const { variantFields } = await pd.getVariantFields(s, req.store, config, { fresh: true });
    const lines = await pd.listDealProducts(s, dealId);
    const products = await pd.fetchProducts(s, lines.map((l) => l.product_id));
    const byId = new Map(products.map((p) => [Number(p.id), p]));
    const fields = await pd.getProductFields(s).catch(() => []);
    res.json({
      deal: { id: deal.id, title: deal.title, currency: deal.currency },
      variantFields,
      currencies: variantFields.some((f) => f.type === 'monetary') ? await pd.getCurrencies(s, [deal.currency]) : [deal.currency].filter(Boolean).map((code) => ({ code, name: code })),
      fieldsMessage: variantFields.length ? null : 'No editable product fields are set up yet. A Pipedrive admin can choose them under "Editable fields".',
      taxMethod: lines.find((l) => l.tax_method)?.tax_method || 'inclusive',
      lines: await Promise.all(lines.map(async (l) => {
        const p = byId.get(Number(l.product_id));
        return {
          dealProductId: Number(l.id),
          productId: Number(l.product_id),
          name: l.name || p?.name || '',
          code: p?.code ?? null,
          itemPrice: Number(l.item_price) || 0,
          quantity: Number(l.quantity) || 0,
          discount: Number(l.discount) || 0,
          discountType: l.discount_type || 'percentage',
          tax: Number(l.tax) || 0,
          comments: l.comments || '',
          isEnabled: l.is_enabled !== false,
          values: p ? await pd.withNames(s, pd.valuesOf(p, variantFields), variantFields) : {},
          details: p ? pd.buildDetails(p, fields, variantFields, await pd.lookupValues(s, p, fields)) : [],
        };
      })),
    });
  }));

  app.get('/api/products/search', authenticate, withSession, wrap(async (req, res) => {
    const q = String(req.query.q || '').trim();
    if (q.length < 2) return res.json({ items: [] });
    const s = req.session;
    const { variantFields } = await pd.getVariantFields(s, req.store, config);
    const ids = await pd.searchProductIds(s, q, { limit: 8 });
    const products = await pd.fetchProducts(s, ids);
    const fields = await pd.getProductFields(s).catch(() => []);
    res.json({
      items: await Promise.all(products.map(async (p) => ({
        id: p.id, name: p.name, code: p.code, tax: p.tax, prices: p.prices.map(({ price, currency }) => ({ price, currency })),
        values: await pd.withNames(s, pd.valuesOf(p, variantFields), variantFields),
        details: pd.buildDetails(p, fields, variantFields, await pd.lookupValues(s, p, fields)),
      }))),
    });
  }));

  // Suggestions for autocomplete text fields (previous values) and address fields (places).
  const allowGeo = makeLimiter(40, 60_000);
  app.get('/api/suggest', authenticate, withSession, wrap(async (req, res) => {
    const kind = String(req.query.kind || '');
    if (kind === 'address') {
      if (!allowGeo(`${req.pd.companyId}:${req.pd.userId}`)) return res.json({ items: [], provider: null });
      try {
        return res.json(await suggestAddress(req.query.q, { fetchImpl: geoFetch, googleKey: config.googlePlacesApiKey }));
      } catch { return res.json({ items: [], provider: null }); } // suggestions are a convenience, never an error
    }
    if (kind === 'field') {
      const s = req.session;
      const f = pd.candidateFields(await pd.getProductFields(s)).find((c) => c.code === String(req.query.code || ''));
      if (!f || f.type !== 'varchar_auto') throw new PdError(400, 'Not an autocomplete field', 'BAD_FIELD');
      return res.json({ items: await pd.suggestValues(s, f.code, req.query.q) });
    }
    throw new PdError(400, 'Unknown suggestion type', 'BAD_SUGGEST');
  }));

  // Pickers for user / organization / person fields.
  app.get('/api/lookup', authenticate, withSession, wrap(async (req, res) => {
    const type = String(req.query.type || '');
    if (!['user', 'org', 'people'].includes(type)) throw new PdError(400, 'Unknown lookup type', 'BAD_LOOKUP');
    try {
      res.json({ items: await pd.lookup(req.session, type, req.query.q) });
    } catch (e) {
      if (e.code === 'NOT_AUTHORIZED') throw e;
      if (e.status === 403) throw new PdError(403, 'The app is not allowed to search this. Re-authorize the app so it can read contacts and users.', 'SCOPE');
      throw e;
    }
  }));

  // Which product fields users may change. Everyone can read it; only Pipedrive admins can change it.
  app.get('/api/settings', authenticate, withSession, wrap(async (req, res) => {
    const s = req.session;
    const [{ variantFields, candidates, isDefault }, admin] = await Promise.all([
      pd.getVariantFields(s, req.store, config, { fresh: true }), pd.isAdmin(s),
    ]);
    res.json({ isAdmin: admin, candidates, selected: variantFields.map((f) => f.code), isDefault });
  }));

  app.put('/api/settings', authenticate, withSession, wrap(async (req, res) => {
    const s = req.session;
    if (!(await pd.isAdmin(s))) throw new PdError(403, 'Only Pipedrive admins can change the editable fields.', 'NOT_ADMIN');
    const codes = req.body?.variantFieldCodes;
    if (!Array.isArray(codes) || codes.length > 200 || codes.some((c) => typeof c !== 'string')) {
      throw new PdError(422, 'Too many fields selected.', 'BAD_SETTINGS');
    }
    const { candidates } = await pd.getVariantFields(s, req.store, config, { fresh: true });
    const known = new Set(candidates.map((c) => c.code));
    if (codes.some((c) => !known.has(c))) throw new PdError(422, 'One of the chosen fields does not exist or cannot be edited here.', 'BAD_SETTINGS');
    await req.store.saveSettings(req.pd.companyId, { variantFieldCodes: [...new Set(codes)] });
    res.json({ ok: true, selected: [...new Set(codes)] });
  }));

  app.post('/api/deals/:dealId/save', authenticate, withSession, wrap(async (req, res) => {
    const dealId = dealIdOf(req);
    const { variantFields } = await pd.getVariantFields(req.session, req.store, config, { fresh: true });
    const out = await processSave({ s: req.session, dealId, body: req.body, variantFields });
    res.status(out.status).json(out.body);
  }));

  app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

  // ---------- Static frontend ----------
  const dist = config.clientDist || path.join(here, '..', 'client', 'dist');
  if (fs.existsSync(dist)) {
    app.use(express.static(dist, { index: false, maxAge: '1h' }));
    app.get(/^\/(?!api\/|auth\/).*/, (req, res) => res.sendFile(path.join(dist, 'index.html')));
  } else {
    app.get('/', (req, res) => res.status(503).send(page('Frontend not built', '<h1>Frontend not built</h1><p>Run <code>npm run build</code> and restart.</p>')));
  }

  // ---------- Errors ----------
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err instanceof PdError) {
      const status = err.status === 429 ? 429 : err.status >= 400 && err.status < 600 ? err.status : 502;
      return res.status(status).json({
        error: err.status === 429 ? 'Pipedrive rate limit reached. Please wait a moment and try again.' : err.message,
        code: err.code,
        authorizeUrl: err.code === 'NOT_AUTHORIZED' ? '/auth/pipedrive' : undefined,
      });
    }
    console.error(JSON.stringify({ at: new Date().toISOString(), step: 'unhandled', message: err?.message }));
    res.status(500).json({ error: 'Unexpected server error', code: 'SERVER_ERROR' });
  });

  return app;
}
