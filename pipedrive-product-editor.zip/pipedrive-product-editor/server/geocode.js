// Address and text suggestions. Addresses use Google Places when GOOGLE_PLACES_API_KEY is set, otherwise the free Photon
// service (OpenStreetMap data). Calls go through this server so the browser never talks to a third party.
const clean = (parts) => {
  const out = [];
  for (const p of parts) { const s = String(p ?? '').trim(); if (s && !out.some((o) => o.toLowerCase() === s.toLowerCase())) out.push(s); }
  return out.join(', ');
};

export async function suggestAddress(q, { fetchImpl = fetch, googleKey = '' } = {}) {
  const term = String(q || '').trim();
  if (term.length < 3 || term.length > 200) return { provider: googleKey ? 'google' : 'osm', items: [] };
  const signal = AbortSignal.timeout(4000);
  if (googleKey) {
    const res = await fetchImpl('https://places.googleapis.com/v1/places:autocomplete', {
      method: 'POST', signal,
      headers: { 'Content-Type': 'application/json', 'X-Goog-Api-Key': googleKey },
      body: JSON.stringify({ input: term }),
    });
    if (!res.ok) throw new Error(`Address service returned ${res.status}`);
    const j = await res.json();
    return { provider: 'google', items: (j.suggestions || []).map((s) => s.placePrediction?.text?.text).filter(Boolean).slice(0, 5) };
  }
  const url = new URL('https://photon.komoot.io/api/');
  url.searchParams.set('q', term); url.searchParams.set('limit', '6'); url.searchParams.set('lang', 'en');
  const res = await fetchImpl(url, { signal, headers: { 'User-Agent': 'pipedrive-product-editor/1.0', Accept: 'application/json' } });
  if (!res.ok) throw new Error(`Address service returned ${res.status}`);
  const j = await res.json();
  const items = [];
  for (const f of j.features || []) {
    const p = f.properties || {};
    const street = [p.housenumber, p.street].filter(Boolean).join(' ');
    const label = clean([p.name && p.name !== p.street ? p.name : '', street, p.district, p.city || p.town || p.village, p.state, p.country]);
    if (label && !items.includes(label)) items.push(label);
  }
  return { provider: 'osm', items: items.slice(0, 5) };
}

/** A tiny per-user rate limit so one user cannot hammer the free address service. */
export function makeLimiter(max = 40, windowMs = 60_000) {
  const hits = new Map();
  return (key) => {
    const now = Date.now();
    const arr = (hits.get(key) || []).filter((t) => now - t < windowMs);
    if (arr.length >= max) { hits.set(key, arr); return false; }
    arr.push(now); hits.set(key, arr);
    if (hits.size > 5000) hits.clear();
    return true;
  };
}
