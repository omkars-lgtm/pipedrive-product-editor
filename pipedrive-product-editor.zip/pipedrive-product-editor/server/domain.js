// Pipedrive operations used by the editor. All use API v2. `s` is a session from pipedrive.openSession().
import { PdError } from './pipedrive.js';

export const numOrNull = (v) => {
  if (v === null || v === undefined || v === '') return null;
  if (typeof v === 'object' && 'value' in v) return numOrNull(v.value);
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

async function paginate(s, path, query = {}) {
  const out = [];
  let cursor;
  for (let i = 0; i < 50; i++) {
    const res = await s.call('GET', path, { query: { ...query, limit: 100, cursor } });
    out.push(...(res?.data || []));
    cursor = res?.additional_data?.next_cursor;
    if (!cursor) break;
  }
  return out;
}

export async function getDeal(s, dealId) {
  const res = await s.call('GET', `/api/v2/deals/${dealId}`);
  if (!res?.data) throw new PdError(404, 'Deal not found');
  return res.data;
}

export const listDealProducts = (s, dealId) => paginate(s, `/api/v2/deals/${dealId}/products`);

/** All product fields (built-in and custom) with labels and option lists, cached for 10 minutes per company. */
const allFieldsCache = new Map();
export async function getProductFields(s, { fresh = false } = {}) {
  const ck = `${s.rec.companyId}`;
  const hit = allFieldsCache.get(ck);
  if (!fresh && hit && Date.now() - hit.at < 10 * 60_000) return hit.fields;
  const fields = await paginate(s, '/api/v2/productFields');
  allFieldsCache.set(ck, { at: Date.now(), fields });
  return fields;
}

// ---- Editable ("variant") fields -------------------------------------------------------------
// An admin chooses which product custom fields users may change on a deal. Changing one never edits the
// master product: it creates (or reuses) a new product that has the changed values.
export const SUPPORTED_TYPES = new Set(['varchar', 'varchar_auto', 'text', 'double', 'int', 'enum', 'set', 'date', 'phone', 'time', 'monetary']);
const isCustom = (f) => (f.is_custom_field ?? /^[0-9a-f]{40}$/.test(String(f.field_code || ''))) === true;

export function candidateFields(fields) {
  return (fields || [])
    .filter((f) => isCustom(f) && SUPPORTED_TYPES.has(f.field_type))
    .map((f) => ({
      code: f.field_code, name: f.field_name || f.field_code, type: f.field_type,
      options: Array.isArray(f.options) ? f.options.map((o) => ({ id: o.id, label: String(o.label ?? o.id) })) : undefined,
    }));
}

/** The company's editable fields: the admin's choice, or (until one is saved) the fields named Min and Max. */
export async function getVariantFields(s, store, config, { fresh = false } = {}) {
  const fields = await getProductFields(s, { fresh });
  const candidates = candidateFields(fields);
  const settings = await store.getSettings(s.rec.companyId);
  let codes;
  if (Array.isArray(settings?.variantFieldCodes)) codes = settings.variantFieldCodes;
  else {
    const find = (name, pinned) => pinned || candidates.find((c) => c.name.trim().toLowerCase() === name)?.code;
    codes = [find('min', config.minFieldKey), find('max', config.maxFieldKey)].filter(Boolean);
  }
  const variantFields = codes.map((c) => candidates.find((x) => x.code === c)).filter(Boolean);
  return { variantFields, candidates, isDefault: !Array.isArray(settings?.variantFieldCodes) };
}

/** Currency codes for monetary inputs (cached per company; falls back to the given codes if Pipedrive refuses). */
const currencyCache = new Map();
export async function getCurrencies(s, fallback = []) {
  const ck = `${s.rec.companyId}`;
  const hit = currencyCache.get(ck);
  if (hit && Date.now() - hit.at < 60 * 60_000) return hit.codes;
  let codes = [];
  try {
    const r = await s.call('GET', '/v1/currencies');
    codes = (r?.data || []).filter((c) => c.active_flag !== false).map((c) => String(c.code).toUpperCase());
  } catch (e) {
    if (e.code === 'NOT_AUTHORIZED') throw e;
  }
  const out = [...new Set([...fallback.filter(Boolean), ...codes])].sort();
  if (codes.length) currencyCache.set(ck, { at: Date.now(), codes: out });
  return out;
}

export async function isAdmin(s) {
  const r = await s.call('GET', '/v1/users/me');
  const v = r?.data?.is_admin;
  return v === true || Number(v) === 1;
}

const unwrap = (v) => (v && typeof v === 'object' && !Array.isArray(v) && 'value' in v ? v.value : v);
const isCode = (c) => typeof c === 'string' && /^[A-Za-z]{3}$/.test(c.trim());
const normTime = (v) => {
  const m = /^(\d{1,2}):(\d{2})(?::(\d{2}))?/.exec(String(v).trim());
  if (!m) return null;
  const [h, mi, se] = [Number(m[1]), Number(m[2]), Number(m[3] ?? 0)];
  if (h > 23 || mi > 59 || se > 59) return null;
  return [h, mi, se].map((n) => String(n).padStart(2, '0')).join(':');
};
const blankish = (v) => v === null || v === undefined || v === '' || (Array.isArray(v) && v.length === 0);

/** Pipedrive value -> normalised value (number, string, option id, sorted array of option ids, or null). */
export function readValue(raw, f) {
  if (f.type === 'monetary') {
    const amount = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw.value : raw;
    if (blankish(amount)) return null;
    const n = Number(amount);
    if (!Number.isFinite(n)) return null;
    const cur = raw && typeof raw === 'object' ? raw.currency : null;
    return { value: n, currency: isCode(cur) ? cur.trim().toUpperCase() : null };
  }
  const v = unwrap(raw);
  if (blankish(v)) return null;
  switch (f.type) {
    case 'time': return normTime(v) ?? String(v);
    case 'double': case 'int': { const n = Number(v); return Number.isFinite(n) ? n : null; }
    case 'enum': { const x = typeof v === 'object' ? (v.id ?? v.value) : v; const n = Number(x); return Number.isFinite(n) ? n : String(x); }
    case 'set': {
      const arr = (Array.isArray(v) ? v : String(v).split(','))
        .map((x) => (x && typeof x === 'object' ? Number(x.value ?? x.id) : Number(x))).filter(Number.isFinite);
      return arr.length ? arr.sort((a, b) => a - b) : null;
    }
    case 'date': return String(v).slice(0, 10);
    default: return String(v);
  }
}

/** User input -> normalised value, or an error message. */
export function parseValue(raw, f) {
  if (blankish(raw) || (typeof raw === 'string' && raw.trim() === '')) return { ok: true, value: null };
  switch (f.type) {
    case 'double': case 'int': {
      const n = Number(String(raw).replace(/,/g, ''));
      if (!Number.isFinite(n)) return { ok: false, error: 'must be a number' };
      if (f.type === 'int' && !Number.isInteger(n)) return { ok: false, error: 'must be a whole number' };
      return { ok: true, value: n };
    }
    case 'monetary': {
      const amount = raw && typeof raw === 'object' ? raw.value : raw;
      if (blankish(amount) || String(amount).trim() === '') return { ok: true, value: null };
      const n = Number(String(amount).replace(/,/g, ''));
      if (!Number.isFinite(n)) return { ok: false, error: 'must be a number' };
      const cur = raw && typeof raw === 'object' ? raw.currency : null;
      if (!isCode(cur)) return { ok: false, error: 'needs a currency' };
      return { ok: true, value: { value: n, currency: cur.trim().toUpperCase() } };
    }
    case 'time': {
      const t = normTime(raw);
      return t ? { ok: true, value: t } : { ok: false, error: 'must be a time (HH:MM)' };
    }
    case 'varchar': case 'varchar_auto': case 'phone': case 'text': {
      const str = String(raw).trim();
      if (str.length > (f.type === 'text' ? 5000 : 255)) return { ok: false, error: 'is too long' };
      return { ok: true, value: str };
    }
    case 'enum': {
      const o = f.options?.find((x) => String(x.id) === String(raw));
      return o ? { ok: true, value: Number.isFinite(Number(o.id)) ? Number(o.id) : o.id } : { ok: false, error: 'is not one of the options' };
    }
    case 'set': {
      const arr = Array.isArray(raw) ? raw : [raw];
      const ids = [];
      for (const x of arr) {
        const o = f.options?.find((y) => String(y.id) === String(x));
        if (!o) return { ok: false, error: 'has an option that does not exist' };
        ids.push(Number(o.id));
      }
      return { ok: true, value: [...new Set(ids)].sort((a, b) => a - b) };
    }
    case 'date': {
      const str = String(raw).trim();
      if (!/^\d{4}-\d{2}-\d{2}$/.test(str) || Number.isNaN(Date.parse(str))) return { ok: false, error: 'must be a date (YYYY-MM-DD)' };
      return { ok: true, value: str };
    }
    default: return { ok: false, error: 'is not an editable field type' };
  }
}

export function valuesEqual(a, b) {
  if (blankish(a) && blankish(b)) return true;
  if (blankish(a) || blankish(b)) return false;
  if (Array.isArray(a) || Array.isArray(b)) return JSON.stringify(a) === JSON.stringify(b);
  if (typeof a === 'number' && typeof b === 'number') return Math.abs(a - b) < 1e-9;
  if (typeof a === 'object' && typeof b === 'object') {
    return Math.abs(Number(a.value) - Number(b.value)) < 1e-9 && (!a.currency || !b.currency || a.currency === b.currency);
  }
  return String(a) === String(b);
}

/** Human-readable value (option labels for dropdowns). */
export function displayValue(v, f) {
  if (blankish(v)) return '';
  const label = (id) => f.options?.find((o) => String(o.id) === String(id))?.label ?? String(id);
  if (f.type === 'monetary' && typeof v === 'object') return `${v.value}${v.currency ? ` ${v.currency}` : ''}`;
  if (f.type === 'time') return String(v).replace(/:00$/, '');
  return Array.isArray(v) ? v.map(label).join(', ') : f.type === 'enum' ? label(v) : String(v);
}

export function valuesOf(product, variantFields) {
  const cf = product?.custom_fields || {};
  return Object.fromEntries(variantFields.map((f) => [f.code, readValue(cf[f.code], f)]));
}

/** Pipedrive write format for a normalised value. */
export const apiValue = (v) => (blankish(v) ? null : v);

export function normalizeProduct(p) {
  return {
    id: p.id,
    name: p.name,
    code: p.code ?? null,
    unit: p.unit ?? null,
    tax: p.tax ?? 0,
    description: p.description ?? null,
    category: p.category ?? null,
    is_linkable: p.is_linkable,
    prices: (p.prices || []).map((x) => ({
      price: Number(x.price) || 0,
      currency: x.currency,
      cost: x.cost ?? 0,
      direct_cost: x.direct_cost ?? 0,
      notes: x.notes ?? '',
    })),
    custom_fields: p.custom_fields || {},
  };
}

const plain = (v, options) => {
  if (v === null || v === undefined || v === '') return '';
  if (Array.isArray(v)) return v.map((x) => plain(x, options)).filter(Boolean).join(', ');
  if (typeof v === 'object') {
    if ('value' in v) return plain(v.value, options) + (v.currency ? ` ${v.currency}` : '');
    if ('label' in v) return String(v.label);
    return '';
  }
  const opt = options?.find((o) => String(o.id) === String(v));
  return String(opt ? opt.label : v);
};

/**
 * Read-only list of every product field for the expanded row: built-in fields first, then all custom fields
 * in Pipedrive's own order. Fields the admin made editable are flagged `variant` (the editor shows them as inputs).
 */
export function buildDetails(p, fields, variantFields) {
  const byCode = new Map((fields || []).map((f) => [f.field_code, f]));
  const vcodes = new Set((variantFields || []).map((f) => f.code));
  const out = [
    { label: 'Product code', value: plain(p.code) },
    { label: 'Unit', value: plain(p.unit) },
    { label: 'Tax %', value: p.tax === null || p.tax === undefined ? '' : String(p.tax) },
    { label: 'Category', value: plain(p.category, byCode.get('category')?.options) },
    { label: 'Description', value: plain(p.description) },
  ];
  const cf = p.custom_fields || {};
  for (const f of fields || []) {
    if (!isCustom(f)) continue;
    out.push({ label: f.field_name || f.field_code, value: plain(cf[f.field_code], f.options), variant: vcodes.has(f.field_code) });
  }
  return out;
}

/** Batch-fetch products; falls back to one-by-one for any that the batch call did not return. */
export async function fetchProducts(s, ids) {
  const unique = [...new Set(ids.filter((i) => Number.isInteger(Number(i))).map(Number))];
  const found = new Map();
  if (unique.length) {
    try {
      const res = await s.call('GET', '/api/v2/products', { query: { ids: unique.join(','), limit: 100 } });
      for (const p of res?.data || []) found.set(Number(p.id), p);
    } catch (e) {
      if (e.code === 'NOT_AUTHORIZED') throw e;
    }
  }
  const missing = unique.filter((id) => !found.has(id));
  for (let i = 0; i < missing.length; i += 5) {
    await Promise.all(missing.slice(i, i + 5).map(async (id) => {
      try {
        const res = await s.call('GET', `/api/v2/products/${id}`);
        if (res?.data) found.set(id, res.data);
      } catch (e) {
        if (e.code === 'NOT_AUTHORIZED') throw e;
      }
    }));
  }
  return unique.filter((id) => found.has(id)).map((id) => normalizeProduct(found.get(id)));
}

export async function searchProductIds(s, term, { exact = false, limit = 8 } = {}) {
  const res = await s.call('GET', '/api/v2/products/search', {
    query: { term, fields: exact ? 'name' : 'name,code', exact_match: exact ? 'true' : undefined, limit },
  });
  return (res?.data?.items || []).map((r) => r.item?.id).filter(Boolean);
}

export async function createProduct(s, body) {
  const res = await s.call('POST', '/api/v2/products', { body });
  if (!res?.data?.id) throw new PdError(502, 'Pipedrive did not return the new product');
  return res.data;
}

export async function attachProduct(s, dealId, body) {
  const res = await s.call('POST', `/api/v2/deals/${dealId}/products`, { body });
  if (!res?.data?.id) throw new PdError(502, 'Pipedrive did not return the new deal product');
  return res.data;
}

export const updateDealProduct = (s, dealId, id, body) =>
  s.call('PATCH', `/api/v2/deals/${dealId}/products/${id}`, { body });

export const deleteDealProduct = (s, dealId, id) =>
  s.call('DELETE', `/api/v2/deals/${dealId}/products/${id}`);
