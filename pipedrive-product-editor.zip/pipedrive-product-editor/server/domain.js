// Pipedrive operations used by the editor. All use API v2. `s` is a session from pipedrive.openSession().
import { PdError } from './pipedrive.js';

export const numOrNull = (v) => {
  if (v === null || v === undefined || v === '') return null;
  if (typeof v === 'object' && 'value' in v) return numOrNull(v.value);
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

async function paginate(s, path, query = {}) {
  const out = [];
  let cursor;
  for (let i = 0; i < 50; i++) {
    const res = await s.call('GET', path, { query: { ...query, limit: 100, cursor } });
    out.push(...(res?.data || []));
    cursor = res?.additional_data?.next_cursor;
    if (!cursor) break;
  }
  return out;
}

export async function getDeal(s, dealId) {
  const res = await s.call('GET', `/api/v2/deals/${dealId}`);
  if (!res?.data) throw new PdError(404, 'Deal not found');
  return res.data;
}

export const listDealProducts = (s, dealId) => paginate(s, `/api/v2/deals/${dealId}/products`);

/** All product fields (built-in and custom) with labels and option lists, cached for 10 minutes per company. */
const allFieldsCache = new Map();
export async function getProductFields(s, { fresh = false } = {}) {
  const ck = `${s.rec.companyId}`;
  const hit = allFieldsCache.get(ck);
  if (!fresh && hit && Date.now() - hit.at < 10 * 60_000) return hit.fields;
  const fields = await paginate(s, '/api/v2/productFields');
  allFieldsCache.set(ck, { at: Date.now(), fields });
  return fields;
}

// ---- Editable ("variant") fields -------------------------------------------------------------
// An admin chooses which product custom fields users may change on a deal. Changing one never edits the
// master product: it creates (or reuses) a new product that has the changed values.
export const SUPPORTED_TYPES = new Set(['varchar', 'varchar_auto', 'text', 'double', 'int', 'enum', 'set', 'date', 'phone', 'time', 'monetary', 'timerange', 'daterange', 'address', 'user', 'org', 'people']);
export const LOOKUP_TYPES = new Set(['user', 'org', 'people']);
const isCustom = (f) => (f.is_custom_field ?? /^[0-9a-f]{40}$/.test(String(f.field_code || ''))) === true;

export function candidateFields(fields) {
  return (fields || [])
    .filter((f) => isCustom(f) && SUPPORTED_TYPES.has(f.field_type))
    .map((f) => ({
      code: f.field_code, name: f.field_name || f.field_code, type: f.field_type,
      options: Array.isArray(f.options) ? f.options.map((o) => ({ id: o.id, label: String(o.label ?? o.id) })) : undefined,
    }));
}

/** The company's editable fields: the admin's choice, or (until one is saved) the fields named Min and Max. */
export async function getVariantFields(s, store, config, { fresh = false } = {}) {
  const fields = await getProductFields(s, { fresh });
  const candidates = candidateFields(fields);
  const settings = await store.getSettings(s.rec.companyId);
  let codes;
  if (Array.isArray(settings?.variantFieldCodes)) codes = settings.variantFieldCodes;
  else {
    const find = (name, pinned) => pinned || candidates.find((c) => c.name.trim().toLowerCase() === name)?.code;
    codes = [find('min', config.minFieldKey), find('max', config.maxFieldKey)].filter(Boolean);
  }
  const variantFields = codes.map((c) => candidates.find((x) => x.code === c)).filter(Boolean);
  return { variantFields, candidates, isDefault: !Array.isArray(settings?.variantFieldCodes) };
}

/** Currency codes for monetary inputs (cached per company; falls back to the given codes if Pipedrive refuses). */
const currencyCache = new Map();
export async function getCurrencies(s, fallback = []) {
  const ck = `${s.rec.companyId}`;
  const hit = currencyCache.get(ck);
  if (hit && Date.now() - hit.at < 60 * 60_000) return hit.codes;
  const byCode = new Map();
  try {
    const r = await s.call('GET', '/v1/currencies');
    for (const c of r?.data || []) if (c.active_flag !== false && c.code) byCode.set(String(c.code).toUpperCase(), String(c.name || c.code));
  } catch (e) {
    if (e.code === 'NOT_AUTHORIZED') throw e;
  }
  const fetched = byCode.size > 0;
  for (const c of fallback.filter(Boolean)) if (!byCode.has(c)) byCode.set(c, c);
  const out = [...byCode].map(([code, name]) => ({ code, name })).sort((a, b) => a.name.localeCompare(b.name));
  if (fetched) currencyCache.set(ck, { at: Date.now(), codes: out });
  return out;
}

export async function isAdmin(s) {
  const r = await s.call('GET', '/v1/users/me');
  const v = r?.data?.is_admin;
  return v === true || Number(v) === 1;
}

const unwrap = (v) => (v && typeof v === 'object' && !Array.isArray(v) && 'value' in v ? v.value : v);
const isCode = (c) => typeof c === 'string' && /^[A-Za-z]{3}$/.test(c.trim());
const normTime = (v) => {
  const m = /^(\d{1,2}):(\d{2})(?::(\d{2}))?/.exec(String(v).trim());
  if (!m) return null;
  const [h, mi, se] = [Number(m[1]), Number(m[2]), Number(m[3] ?? 0)];
  if (h > 23 || mi > 59 || se > 59) return null;
  return [h, mi, se].map((n) => String(n).padStart(2, '0')).join(':');
};
const hhmm = (t) => (t ? String(t).replace(/^(\d{2}:\d{2}):00$/, '$1') : t);
const normDate = (v) => (/^\d{4}-\d{2}-\d{2}/.test(String(v ?? '')) ? String(v).slice(0, 10) : null);
const validDate = (v) => /^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(v));
const idOf = (raw) => {
  if (raw === null || raw === undefined || raw === '') return null;
  if (typeof raw === 'object') return idOf(raw.id ?? (typeof raw.value === 'object' ? raw.value?.id ?? null : raw.value));
  const n = Number(raw);
  return Number.isInteger(n) && n > 0 ? n : null;
};
const nameOf = (raw) => (raw && typeof raw === 'object' ? (raw.name ?? (raw.value && typeof raw.value === 'object' ? raw.value.name : null) ?? null) : null);
const blankish = (v) => v === null || v === undefined || v === '' || (Array.isArray(v) && v.length === 0);

/** Pipedrive value -> normalised value (number, string, option id, sorted ids, {value,currency}, {from,to}, {id,name} or null). */
export function readValue(raw, f) {
  if (f.type === 'monetary') {
    const amount = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw.value : raw;
    if (blankish(amount)) return null;
    const n = Number(amount);
    if (!Number.isFinite(n)) return null;
    const cur = raw && typeof raw === 'object' ? raw.currency : null;
    return { value: n, currency: isCode(cur) ? cur.trim().toUpperCase() : null };
  }
  if (f.type === 'timerange') {
    const from = raw && typeof raw === 'object' ? normTime(raw.value ?? raw.from ?? '') : null;
    const to = raw && typeof raw === 'object' ? normTime(raw.until ?? raw.to ?? '') : null;
    return from || to ? { from, to } : null;
  }
  if (f.type === 'daterange') {
    const from = raw && typeof raw === 'object' ? normDate(raw.value ?? raw.from) : null;
    const to = raw && typeof raw === 'object' ? normDate(raw.until ?? raw.to) : null;
    return from || to ? { from, to } : null;
  }
  if (LOOKUP_TYPES.has(f.type)) {
    const id = idOf(raw);
    return id ? { id, name: nameOf(raw) } : null;
  }
  if (f.type === 'address') {
    const v = raw && typeof raw === 'object' ? (raw.value ?? raw.formatted_address) : raw;
    return blankish(v) ? null : String(v);
  }
  const v = unwrap(raw);
  if (blankish(v)) return null;
  switch (f.type) {
    case 'time': return normTime(v) ?? String(v);
    case 'double': case 'int': { const n = Number(v); return Number.isFinite(n) ? n : null; }
    case 'enum': { const x = typeof v === 'object' ? (v.id ?? v.value) : v; const n = Number(x); return Number.isFinite(n) ? n : String(x); }
    case 'set': {
      const arr = (Array.isArray(v) ? v : String(v).split(','))
        .map((x) => (x && typeof x === 'object' ? Number(x.value ?? x.id) : Number(x))).filter(Number.isFinite);
      return arr.length ? arr.sort((a, b) => a - b) : null;
    }
    case 'date': return String(v).slice(0, 10);
    default: return String(v);
  }
}

/** User input -> normalised value, or an error message. */
export function parseValue(raw, f) {
  const empty = blankish(raw) || (typeof raw === 'string' && raw.trim() === '');
  if (f.type === 'monetary') {
    const amount = raw && typeof raw === 'object' ? raw.value : raw;
    if (blankish(amount) || String(amount).trim() === '') return { ok: true, value: null };
    const n = Number(String(amount).replace(/,/g, ''));
    if (!Number.isFinite(n)) return { ok: false, error: 'must be a number' };
    const cur = raw && typeof raw === 'object' ? raw.currency : null;
    if (!isCode(cur)) return { ok: false, error: 'needs a currency' };
    return { ok: true, value: { value: n, currency: cur.trim().toUpperCase() } };
  }
  if (f.type === 'timerange' || f.type === 'daterange') {
    const isT = f.type === 'timerange';
    const a = raw && typeof raw === 'object' ? raw.from : null; const b = raw && typeof raw === 'object' ? raw.to : null;
    const ea = blankish(a) || String(a).trim() === ''; const eb = blankish(b) || String(b).trim() === '';
    if (ea && eb) return { ok: true, value: null };
    if (ea || eb) return { ok: false, error: 'needs both a start and an end' };
    const from = isT ? normTime(a) : String(a).trim(); const to = isT ? normTime(b) : String(b).trim();
    if (isT ? !from || !to : !validDate(from) || !validDate(to)) return { ok: false, error: isT ? 'must be times (HH:MM)' : 'must be dates (YYYY-MM-DD)' };
    if (from > to) return { ok: false, error: 'start must not be after the end' };
    return { ok: true, value: { from, to } };
  }
  if (LOOKUP_TYPES.has(f.type)) {
    if (empty) return { ok: true, value: null };
    if (raw && typeof raw === 'object' && raw.isNew) {
      const nm = typeof raw.name === 'string' ? raw.name.trim() : '';
      if (f.type === 'user') return { ok: false, error: 'must be an existing user' };
      if (!nm || nm.length > 200) return { ok: false, error: 'needs a name (up to 200 characters)' };
      return { ok: true, value: { id: null, name: nm, isNew: true } };
    }
    const id = idOf(raw);
    if (!id) return { ok: false, error: 'is not a valid selection' };
    const name = raw && typeof raw === 'object' && typeof raw.name === 'string' ? raw.name.trim().slice(0, 200) : '';
    return { ok: true, value: { id, name: name || null } };
  }
  if (empty) return { ok: true, value: null };
  switch (f.type) {
    case 'time': {
      const t = normTime(raw);
      return t ? { ok: true, value: t } : { ok: false, error: 'must be a time (HH:MM)' };
    }
    case 'double': case 'int': {
      const n = Number(String(raw).replace(/,/g, ''));
      if (!Number.isFinite(n)) return { ok: false, error: 'must be a number' };
      if (f.type === 'int' && !Number.isInteger(n)) return { ok: false, error: 'must be a whole number' };
      return { ok: true, value: n };
    }
    case 'varchar': case 'varchar_auto': case 'phone': case 'address': case 'text': {
      const str = String(raw).trim();
      if (str.length > (f.type === 'text' ? 5000 : 255)) return { ok: false, error: 'is too long' };
      return { ok: true, value: str };
    }
    case 'enum': {
      const o = f.options?.find((x) => String(x.id) === String(raw));
      return o ? { ok: true, value: Number.isFinite(Number(o.id)) ? Number(o.id) : o.id } : { ok: false, error: 'is not one of the options' };
    }
    case 'set': {
      const arr = Array.isArray(raw) ? raw : [raw];
      const ids = [];
      for (const x of arr) {
        const o = f.options?.find((y) => String(y.id) === String(x));
        if (!o) return { ok: false, error: 'has an option that does not exist' };
        ids.push(Number(o.id));
      }
      return { ok: true, value: [...new Set(ids)].sort((a, b) => a - b) };
    }
    case 'date': {
      const str = String(raw).trim();
      if (!validDate(str)) return { ok: false, error: 'must be a date (YYYY-MM-DD)' };
      return { ok: true, value: str };
    }
    default: return { ok: false, error: 'is not an editable field type' };
  }
}

export function valuesEqual(a, b) {
  if (blankish(a) && blankish(b)) return true;
  if (blankish(a) || blankish(b)) return false;
  if (Array.isArray(a) || Array.isArray(b)) return JSON.stringify(a) === JSON.stringify(b);
  if (typeof a === 'number' && typeof b === 'number') return Math.abs(a - b) < 1e-9;
  if (typeof a === 'object' && typeof b === 'object') {
    if ('id' in a || 'id' in b) return !!a.id && !!b.id && Number(a.id) === Number(b.id);
    if ('from' in a || 'from' in b) return (a.from ?? null) === (b.from ?? null) && (a.to ?? null) === (b.to ?? null);
    return Math.abs(Number(a.value) - Number(b.value)) < 1e-9 && (!a.currency || !b.currency || a.currency === b.currency);
  }
  return String(a) === String(b);
}

/** Human-readable value (option labels for dropdowns, names for users/organizations/people). */
export function displayValue(v, f) {
  if (blankish(v)) return '';
  const label = (id) => f.options?.find((o) => String(o.id) === String(id))?.label ?? String(id);
  if (f.type === 'monetary' && typeof v === 'object') return `${v.value}${v.currency ? ` ${v.currency}` : ''}`;
  if (f.type === 'timerange') return `${hhmm(v.from) ?? ''}..${hhmm(v.to) ?? ''}`;
  if (f.type === 'daterange') return `${v.from ?? ''}..${v.to ?? ''}`;
  if (LOOKUP_TYPES.has(f.type)) return v.name || (v.id ? `#${v.id}` : '');
  if (f.type === 'time') return hhmm(String(v));
  return Array.isArray(v) ? v.map(label).join(', ') : f.type === 'enum' ? label(v) : String(v);
}

/**
 * Pipedrive v2 write format for a normalised value. Users, organizations and people accept either an object or a bare id
 * depending on the account's API; `bare` selects the bare-id form (used as a retry, or when the master product shows it).
 */
export function apiValue(v, f, { bare = false } = {}) {
  if (blankish(v)) return null;
  switch (f?.type) {
    case 'time': return { value: hhmm(v) };
    case 'timerange': return { value: hhmm(v.from), until: hhmm(v.to) };
    case 'daterange': return { value: v.from, until: v.to };
    case 'address': return { value: v };
    case 'user': case 'org': case 'people': return bare ? v.id : { value: v.id };
    default: return v;
  }
}

/** Fills in names for user/organization/person values so the UI can show them. Failures leave the name empty. */
const userCache = new Map();
export async function listUsers(s) {
  const ck = `${s.rec.companyId}`;
  const hit = userCache.get(ck);
  if (hit && Date.now() - hit.at < 5 * 60_000) return hit.users;
  const r = await s.call('GET', '/v1/users');
  const users = (r?.data || []).filter((u) => u.active_flag !== false)
    .map((u) => ({ id: Number(u.id), name: String(u.name || u.email || `#${u.id}`), sub: u.email || '' }));
  userCache.set(ck, { at: Date.now(), users });
  return users;
}

export async function withNames(s, values, fields) {
  const out = { ...values };
  await Promise.all(fields.filter((f) => LOOKUP_TYPES.has(f.type) && out[f.code]?.id && !out[f.code].name).map(async (f) => {
    const id = out[f.code].id;
    try {
      let name = null;
      if (f.type === 'user') name = (await listUsers(s)).find((u) => u.id === id)?.name ?? null;
      else name = (await s.call('GET', `/api/v2/${f.type === 'org' ? 'organizations' : 'persons'}/${id}`))?.data?.name ?? null;
      out[f.code] = { id, name };
    } catch (e) {
      if (e.code === 'NOT_AUTHORIZED') throw e;
    }
  }));
  return out;
}

/** Finds an organization or person by exact name, or creates it (like Pipedrive's "Add as new" in its own forms). */
export async function ensureRecord(s, type, name) {
  const path = type === 'org' ? 'organizations' : 'persons';
  const nm = String(name).trim();
  try {
    const found = await s.call('GET', `/api/v2/${path}/search`, { query: { term: nm, fields: 'name', exact_match: 'true', limit: 5 } });
    const hit = (found?.data?.items || []).map((x) => x.item).find((x) => x?.id && String(x.name).trim().toLowerCase() === nm.toLowerCase());
    if (hit) return { id: Number(hit.id), name: String(hit.name) };
    const made = await s.call('POST', `/api/v2/${path}`, { body: { name: nm } });
    if (!made?.data?.id) throw new PdError(502, `Pipedrive did not return the new ${type === 'org' ? 'organization' : 'person'}`);
    return { id: Number(made.data.id), name: String(made.data.name || nm) };
  } catch (e) {
    if (e.status === 403) throw new PdError(403, `The app is not allowed to create ${type === 'org' ? 'organizations' : 'people'}. Enable "Contacts: Full access" for the app and re-authorize.`, 'SCOPE');
    throw e;
  }
}

/** Previously used values of an autocomplete text field (most used first), like Pipedrive's own suggestions. */
const suggestCache = new Map();
export async function suggestValues(s, code, q) {
  const ck = `${s.rec.companyId}:${code}`;
  let hit = suggestCache.get(ck);
  if (!hit || Date.now() - hit.at > 5 * 60_000) {
    const counts = new Map();
    let cursor;
    for (let i = 0; i < 6; i++) {
      const res = await s.call('GET', '/api/v2/products', { query: { limit: 500, cursor, custom_fields: code } });
      for (const p of res?.data || []) {
        const v = unwrap(p.custom_fields?.[code]);
        if (typeof v === 'string' && v.trim()) counts.set(v.trim(), (counts.get(v.trim()) || 0) + 1);
      }
      cursor = res?.additional_data?.next_cursor;
      if (!cursor) break;
    }
    hit = { at: Date.now(), values: [...counts].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).map(([v]) => v) };
    suggestCache.set(ck, hit);
  }
  const needle = String(q || '').trim().toLowerCase();
  return hit.values.filter((v) => !needle || v.toLowerCase().includes(needle)).slice(0, 8);
}

/** Search users, organizations or people for the pickers. */
export async function lookup(s, type, q) {
  const term = String(q || '').trim();
  if (type === 'user') {
    const needle = term.toLowerCase();
    return (await listUsers(s)).filter((u) => !needle || u.name.toLowerCase().includes(needle) || u.sub.toLowerCase().includes(needle)).slice(0, 25);
  }
  const path = type === 'org' ? 'organizations' : 'persons';
  if (term.length >= 2) {
    const r = await s.call('GET', `/api/v2/${path}/search`, { query: { term, limit: 10 } });
    return (r?.data?.items || []).map((x) => x.item).filter((x) => x?.id)
      .map((x) => ({ id: Number(x.id), name: String(x.name || `#${x.id}`), sub: type === 'org' ? (x.address || '') : (x.organization?.name || x.emails?.[0] || '') }));
  }
  const r = await s.call('GET', `/api/v2/${path}`, { query: { limit: 10, sort_by: 'update_time', sort_direction: 'desc' } });
  return (r?.data || []).filter((x) => x?.id).map((x) => ({ id: Number(x.id), name: String(x.name || `#${x.id}`), sub: '' }));
}

export function valuesOf(product, variantFields) {
  const cf = product?.custom_fields || {};
  return Object.fromEntries(variantFields.map((f) => [f.code, readValue(cf[f.code], f)]));
}


export function normalizeProduct(p) {
  return {
    id: p.id,
    name: p.name,
    code: p.code ?? null,
    unit: p.unit ?? null,
    tax: p.tax ?? 0,
    description: p.description ?? null,
    category: p.category ?? null,
    is_linkable: p.is_linkable,
    prices: (p.prices || []).map((x) => ({
      price: Number(x.price) || 0,
      currency: x.currency,
      cost: x.cost ?? 0,
      direct_cost: x.direct_cost ?? 0,
      notes: x.notes ?? '',
    })),
    custom_fields: p.custom_fields || {},
  };
}

const plain = (v, options) => {
  if (v === null || v === undefined || v === '') return '';
  if (Array.isArray(v)) return v.map((x) => plain(x, options)).filter(Boolean).join(', ');
  if (typeof v === 'object') {
    if ('value' in v) return plain(v.value, options) + (v.currency ? ` ${v.currency}` : '');
    if ('label' in v) return String(v.label);
    return '';
  }
  const opt = options?.find((o) => String(o.id) === String(v));
  return String(opt ? opt.label : v);
};

/**
 * Read-only list of every product field for the expanded row: built-in fields first, then all custom fields
 * in Pipedrive's own order. Fields the admin made editable are flagged `variant` (the editor shows them as inputs).
 */
/** Resolved names for the user/organization/person fields of one product (all custom fields, not just editable ones). */
export async function lookupValues(s, p, fields) {
  const cands = candidateFields(fields).filter((c) => LOOKUP_TYPES.has(c.type));
  return withNames(s, valuesOf(p, cands), cands);
}

export function buildDetails(p, fields, variantFields, resolved = {}) {
  const byCode = new Map((fields || []).map((f) => [f.field_code, f]));
  const vcodes = new Set((variantFields || []).map((f) => f.code));
  const out = [
    { label: 'Product code', value: plain(p.code) },
    { label: 'Unit', value: plain(p.unit) },
    { label: 'Tax %', value: p.tax === null || p.tax === undefined ? '' : String(p.tax) },
    { label: 'Category', value: plain(p.category, byCode.get('category')?.options) },
    { label: 'Description', value: plain(p.description) },
  ];
  const cf = p.custom_fields || {};
  for (const f of fields || []) {
    if (!isCustom(f)) continue;
    const cand = SUPPORTED_TYPES.has(f.field_type) ? candidateFields([f])[0] : null;
    const text = cand ? displayValue(resolved[cand.code] ?? readValue(cf[f.field_code], cand), cand) : plain(cf[f.field_code], f.options);
    out.push({ label: f.field_name || f.field_code, value: text, variant: vcodes.has(f.field_code) });
  }
  return out;
}

/** Batch-fetch products; falls back to one-by-one for any that the batch call did not return. */
export async function fetchProducts(s, ids) {
  const unique = [...new Set(ids.filter((i) => Number.isInteger(Number(i))).map(Number))];
  const found = new Map();
  if (unique.length) {
    try {
      const res = await s.call('GET', '/api/v2/products', { query: { ids: unique.join(','), limit: 100 } });
      for (const p of res?.data || []) found.set(Number(p.id), p);
    } catch (e) {
      if (e.code === 'NOT_AUTHORIZED') throw e;
    }
  }
  const missing = unique.filter((id) => !found.has(id));
  for (let i = 0; i < missing.length; i += 5) {
    await Promise.all(missing.slice(i, i + 5).map(async (id) => {
      try {
        const res = await s.call('GET', `/api/v2/products/${id}`);
        if (res?.data) found.set(id, res.data);
      } catch (e) {
        if (e.code === 'NOT_AUTHORIZED') throw e;
      }
    }));
  }
  return unique.filter((id) => found.has(id)).map((id) => normalizeProduct(found.get(id)));
}

export async function searchProductIds(s, term, { exact = false, limit = 8 } = {}) {
  const res = await s.call('GET', '/api/v2/products/search', {
    query: { term, fields: exact ? 'name' : 'name,code', exact_match: exact ? 'true' : undefined, limit },
  });
  return (res?.data?.items || []).map((r) => r.item?.id).filter(Boolean);
}

export async function createProduct(s, body) {
  const res = await s.call('POST', '/api/v2/products', { body });
  if (!res?.data?.id) throw new PdError(502, 'Pipedrive did not return the new product');
  return res.data;
}

export async function attachProduct(s, dealId, body) {
  const res = await s.call('POST', `/api/v2/deals/${dealId}/products`, { body });
  if (!res?.data?.id) throw new PdError(502, 'Pipedrive did not return the new deal product');
  return res.data;
}

export const updateDealProduct = (s, dealId, id, body) =>
  s.call('PATCH', `/api/v2/deals/${dealId}/products/${id}`, { body });

export const deleteDealProduct = (s, dealId, id) =>
  s.call('DELETE', `/api/v2/deals/${dealId}/products/${id}`);
