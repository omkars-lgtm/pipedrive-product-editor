// Pipedrive operations used by the editor. All use API v2. `s` is a session from pipedrive.openSession().
import { PdError } from './pipedrive.js';

export const numOrNull = (v) => {
  if (v === null || v === undefined || v === '') return null;
  if (typeof v === 'object' && 'value' in v) return numOrNull(v.value);
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

async function paginate(s, path, query = {}) {
  const out = [];
  let cursor;
  for (let i = 0; i < 50; i++) {
    const res = await s.call('GET', path, { query: { ...query, limit: 100, cursor } });
    out.push(...(res?.data || []));
    cursor = res?.additional_data?.next_cursor;
    if (!cursor) break;
  }
  return out;
}

export async function getDeal(s, dealId) {
  const res = await s.call('GET', `/api/v2/deals/${dealId}`);
  if (!res?.data) throw new PdError(404, 'Deal not found');
  return res.data;
}

export const listDealProducts = (s, dealId) => paginate(s, `/api/v2/deals/${dealId}/products`);

/** All product fields (built-in and custom) with labels and option lists, cached for 10 minutes per company. */
const allFieldsCache = new Map();
export async function getProductFields(s, { fresh = false } = {}) {
  const ck = `${s.rec.companyId}`;
  const hit = allFieldsCache.get(ck);
  if (!fresh && hit && Date.now() - hit.at < 10 * 60_000) return hit.fields;
  const fields = await paginate(s, '/api/v2/productFields');
  allFieldsCache.set(ck, { at: Date.now(), fields });
  return fields;
}

/** Finds the product custom fields named "Min" and "Max" (or uses the env overrides). */
const fieldCache = new Map();
export async function getMinMaxKeys(s, config, { fresh = false } = {}) {
  const ck = `${s.rec.companyId}`;
  const hit = fieldCache.get(ck);
  if (!fresh && hit && Date.now() - hit.at < 10 * 60_000) return hit.keys;
  let minKey = config.minFieldKey;
  let maxKey = config.maxFieldKey;
  if (!minKey || !maxKey) {
    const fields = await getProductFields(s, { fresh });
    const find = (name) => fields.find((f) => String(f.field_name || '').trim().toLowerCase() === name);
    minKey = minKey || find('min')?.field_code || '';
    maxKey = maxKey || find('max')?.field_code || '';
  }
  const keys = { minKey, maxKey, ok: Boolean(minKey && maxKey) };
  if (keys.ok) fieldCache.set(ck, { at: Date.now(), keys });
  return keys;
}

const plain = (v, options) => {
  if (v === null || v === undefined || v === '') return '';
  if (Array.isArray(v)) return v.map((x) => plain(x, options)).filter(Boolean).join(', ');
  if (typeof v === 'object') {
    if ('value' in v) return plain(v.value, options) + (v.currency ? ` ${v.currency}` : '');
    if ('label' in v) return String(v.label);
    return '';
  }
  const opt = options?.find((o) => String(o.id) === String(v));
  return String(opt ? opt.label : v);
};

/**
 * Read-only list of every product field for the expanded row: built-in fields first, then all custom
 * fields (Min and Max included) in Pipedrive's own order. Min/Max carry a `live` marker so the editor
 * can show the value currently typed in the row instead of the saved one.
 */
export function buildDetails(p, fields, keys) {
  const byCode = new Map((fields || []).map((f) => [f.field_code, f]));
  const out = [
    { label: 'Product code', value: plain(p.code) },
    { label: 'Unit', value: plain(p.unit) },
    { label: 'Tax %', value: p.tax === null || p.tax === undefined ? '' : String(p.tax) },
    { label: 'Category', value: plain(p.category, byCode.get('category')?.options) },
    { label: 'Description', value: plain(p.description) },
  ];
  const cf = p.custom_fields || {};
  for (const f of fields || []) {
    if (!f.is_custom_field) continue;
    const row = { label: f.field_name || f.field_code, value: plain(cf[f.field_code], f.options) };
    if (f.field_code === keys.minKey) row.live = 'min';
    if (f.field_code === keys.maxKey) row.live = 'max';
    out.push(row);
  }
  return out;
}

export function normalizeProduct(p, keys) {
  const cf = p.custom_fields || {};
  return {
    id: p.id,
    name: p.name,
    code: p.code ?? null,
    unit: p.unit ?? null,
    tax: p.tax ?? 0,
    description: p.description ?? null,
    category: p.category ?? null,
    is_linkable: p.is_linkable,
    prices: (p.prices || []).map((x) => ({
      price: Number(x.price) || 0,
      currency: x.currency,
      cost: x.cost ?? 0,
      direct_cost: x.direct_cost ?? 0,
      notes: x.notes ?? '',
    })),
    min: numOrNull(cf[keys.minKey]),
    max: numOrNull(cf[keys.maxKey]),
    custom_fields: cf,
  };
}

/** Batch-fetch products; falls back to one-by-one for any that the batch call did not return. */
export async function fetchProducts(s, ids, keys) {
  const unique = [...new Set(ids.filter((i) => Number.isInteger(Number(i))).map(Number))];
  const found = new Map();
  if (unique.length) {
    try {
      const res = await s.call('GET', '/api/v2/products', { query: { ids: unique.join(','), limit: 100 } });
      for (const p of res?.data || []) found.set(Number(p.id), p);
    } catch (e) {
      if (e.code === 'NOT_AUTHORIZED') throw e;
    }
  }
  const missing = unique.filter((id) => !found.has(id));
  for (let i = 0; i < missing.length; i += 5) {
    await Promise.all(missing.slice(i, i + 5).map(async (id) => {
      try {
        const res = await s.call('GET', `/api/v2/products/${id}`);
        if (res?.data) found.set(id, res.data);
      } catch (e) {
        if (e.code === 'NOT_AUTHORIZED') throw e;
      }
    }));
  }
  return unique.filter((id) => found.has(id)).map((id) => normalizeProduct(found.get(id), keys));
}

export async function searchProductIds(s, term, { exact = false, limit = 8 } = {}) {
  const res = await s.call('GET', '/api/v2/products/search', {
    query: { term, fields: exact ? 'name' : 'name,code', exact_match: exact ? 'true' : undefined, limit },
  });
  return (res?.data?.items || []).map((r) => r.item?.id).filter(Boolean);
}

export async function createProduct(s, body) {
  const res = await s.call('POST', '/api/v2/products', { body });
  if (!res?.data?.id) throw new PdError(502, 'Pipedrive did not return the new product');
  return res.data;
}

export async function attachProduct(s, dealId, body) {
  const res = await s.call('POST', `/api/v2/deals/${dealId}/products`, { body });
  if (!res?.data?.id) throw new PdError(502, 'Pipedrive did not return the new deal product');
  return res.data;
}

export const updateDealProduct = (s, dealId, id, body) =>
  s.call('PATCH', `/api/v2/deals/${dealId}/products/${id}`, { body });

export const deleteDealProduct = (s, dealId, id) =>
  s.call('DELETE', `/api/v2/deals/${dealId}/products/${id}`);
