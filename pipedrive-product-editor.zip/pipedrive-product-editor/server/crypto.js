// Encrypts OAuth tokens at rest (AES-256-GCM). The key lives only in the TOKEN_ENCRYPTION_KEY environment variable.
// A value that starts with "enc:v1:" is encrypted; anything else is treated as legacy plain text and upgraded on the next save.
import crypto from 'node:crypto';

const PREFIX = 'enc:v1:';

export function parseKey(raw) {
  if (!raw) return null;
  const buf = /^[0-9a-fA-F]{64}$/.test(raw) ? Buffer.from(raw, 'hex') : Buffer.from(raw, 'base64');
  if (buf.length !== 32) throw new Error('TOKEN_ENCRYPTION_KEY must be 32 bytes: 64 hex characters or a base64 string');
  return buf;
}

export const isEncrypted = (v) => typeof v === 'string' && v.startsWith(PREFIX);

/** aad binds the ciphertext to its row, so a token copied to another user's row will not decrypt. */
export function encrypt(plain, key, aad) {
  if (!key || plain === null || plain === undefined || isEncrypted(plain)) return plain;
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key, iv);
  c.setAAD(Buffer.from(String(aad)));
  const ct = Buffer.concat([c.update(String(plain), 'utf8'), c.final()]);
  return PREFIX + Buffer.concat([iv, c.getAuthTag(), ct]).toString('base64');
}

export function decrypt(value, key, aad) {
  if (!isEncrypted(value)) return value;
  if (!key) throw new Error('Stored tokens are encrypted but TOKEN_ENCRYPTION_KEY is not set');
  const buf = Buffer.from(value.slice(PREFIX.length), 'base64');
  const d = crypto.createDecipheriv('aes-256-gcm', key, buf.subarray(0, 12));
  d.setAAD(Buffer.from(String(aad)));
  d.setAuthTag(buf.subarray(12, 28));
  return Buffer.concat([d.update(buf.subarray(28)), d.final()]).toString('utf8');
}
