import { loadConfig, configProblems } from './config.js';
import { createStore } from './store.js';
import { createApp } from './app.js';

const config = loadConfig();
for (const p of configProblems(config)) console.warn(`[config] ${p}`);

const store = createStore(config.databaseUrl);
await store.init();

const app = createApp({ config, store });
app.listen(config.port, '0.0.0.0', () => {
  console.log(`Listening on :${config.port} (token store: ${store.kind})`);
});
