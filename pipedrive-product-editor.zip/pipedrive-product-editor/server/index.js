import { loadConfig, configProblems } from './config.js';
import { createStore } from './store.js';
import { createApp } from './app.js';

const config = loadConfig();
for (const p of configProblems(config)) console.warn(`[config] ${p}`);

if (config.tokenEncryptionKey) console.log('Token encryption: on'); else console.warn('[config] TOKEN_ENCRYPTION_KEY is not set: tokens are stored unencrypted');
const store = createStore(config.databaseUrl, { encryptionKey: config.tokenEncryptionKey });
await store.init();

const app = createApp({ config, store });
app.listen(config.port, '0.0.0.0', () => {
  console.log(`Listening on :${config.port} (token store: ${store.kind})`);
});
