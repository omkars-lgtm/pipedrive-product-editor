// Save logic for the product editor, including the variant rule:
//   The editable fields (chosen by an admin) belong to the MASTER product, which other deals may use, so an existing
//   master product is never edited. If a line's values differ from its master product, a matching product is reused
//   or a new one is created (optionally with the changed fields added to its name).
import { PdError } from './pipedrive.js';
import { sanitizeHtml, textLength } from './sanitize.js';
import * as pd from './domain.js';

const TAX_METHODS = ['inclusive', 'exclusive', 'none'];
const DISCOUNT_TYPES = ['percentage', 'amount'];
const blank = (v) => v === null || v === undefined || (typeof v === 'string' && v.trim() === '');
const parse = (v) => (blank(v) ? null : Number(String(v).replace(/,/g, '')));
const norm = (s) => String(s ?? '').trim().toLowerCase();
const MAX_NAME = 255;

export function validateSave(body, variantFields = []) {
  const errors = {};
  const global = [];
  const add = (key, msg) => { (errors[key] ||= []).push(msg); };
  if (!body || typeof body !== 'object') return { global: ['Invalid request'], errors, lines: [] };

  const taxMethod = body.taxMethod || 'inclusive';
  if (!TAX_METHODS.includes(taxMethod)) global.push('Tax method must be inclusive, exclusive or none');
  if (!Array.isArray(body.lines)) global.push('lines must be an array');
  if (Array.isArray(body.lines) && body.lines.length > 100) global.push('Too many products (max 100)');
  const removed = Array.isArray(body.removedDealProductIds)
    ? body.removedDealProductIds.map(Number).filter(Number.isInteger) : [];

  const lines = (Array.isArray(body.lines) ? body.lines : []).slice(0, 100).map((l, i) => {
    const key = String(l?.key ?? `row-${i}`);
    const out = {
      key,
      dealProductId: l?.dealProductId ? Number(l.dealProductId) : null,
      productId: l?.productId ? Number(l.productId) : null,
      name: String(l?.name ?? '').trim(),
      code: blank(l?.code) ? null : String(l.code).trim(),
      values: {},
      suffixCodes: Array.isArray(l?.suffixCodes) ? l.suffixCodes.filter((c) => typeof c === 'string') : [],
      itemPrice: parse(l?.itemPrice),
      quantity: parse(l?.quantity),
      discount: parse(l?.discount) ?? 0,
      discountType: l?.discountType || 'percentage',
      tax: parse(l?.tax) ?? 0,
      comments: sanitizeHtml(l?.comments ?? ''),
      isEnabled: l?.isEnabled !== false,
    };
    if (!out.productId && !out.name) add(key, 'Choose a product or type a name');
    if (out.name.length > 255) add(key, 'Product name is too long (max 255)');
    if (out.code && out.code.length > 100) add(key, 'Product code is too long (max 100)');
    if (out.itemPrice === null || Number.isNaN(out.itemPrice) || out.itemPrice < 0) add(key, 'Price must be a number of 0 or more');
    if (out.quantity === null || Number.isNaN(out.quantity) || out.quantity <= 0) add(key, 'Quantity must be greater than 0');
    if (Number.isNaN(out.discount) || out.discount < 0) add(key, 'Discount must be 0 or more');
    if (!DISCOUNT_TYPES.includes(out.discountType)) add(key, 'Discount type must be % or amount');
    else if (out.discountType === 'percentage' && out.discount > 100) add(key, 'Percentage discount cannot exceed 100');
    if (Number.isNaN(out.tax) || out.tax < 0 || out.tax > 100) add(key, 'Tax % must be between 0 and 100');
    const src = l?.values && typeof l.values === 'object' ? l.values : {};
    for (const f of variantFields) {
      const r = pd.parseValue(src[f.code], f);
      if (r.ok) out.values[f.code] = r.value; else add(key, `${f.name} ${r.error}`);
    }
    const byName = (n) => variantFields.find((f) => f.type !== 'text' && norm(f.name) === n);
    const fmin = byName('min'); const fmax = byName('max');
    if (fmin && fmax && typeof out.values[fmin.code] === 'number' && typeof out.values[fmax.code] === 'number' && out.values[fmin.code] > out.values[fmax.code]) {
      add(key, `${fmin.name} cannot be greater than ${fmax.name}`);
    }
    if (textLength(out.comments) > 2000) add(key, 'Comments are limited to 2000 characters');
    return out;
  });
  return { global, errors, lines, removed, taxMethod };
}

const dealProductBody = (line, taxMethod) => ({
  item_price: line.itemPrice,
  quantity: line.quantity,
  discount: line.discount,
  discount_type: line.discountType,
  tax: line.tax,
  tax_method: taxMethod,
  comments: line.comments,
  is_enabled: line.isEnabled,
});

function differs(existing, line, taxMethod) {
  const n = (v) => Number(v ?? 0);
  return n(existing.item_price) !== n(line.itemPrice)
    || n(existing.quantity) !== n(line.quantity)
    || n(existing.discount) !== n(line.discount)
    || (existing.discount_type || 'percentage') !== line.discountType
    || n(existing.tax) !== n(line.tax)
    || (existing.tax_method || taxMethod) !== taxMethod
    || String(existing.comments ?? '') !== String(line.comments ?? '')
    || (existing.is_enabled !== false) !== line.isEnabled;
}

export async function processSave({ s, dealId, body, variantFields }) {
  const v = validateSave(body, variantFields);
  if (v.global.length || Object.keys(v.errors).length) {
    return { status: 422, body: { ok: false, error: 'Please fix the highlighted fields.', global: v.global, lineErrors: v.errors } };
  }
  const deal = await pd.getDeal(s, dealId); // also proves this user can see the deal
  const current = await pd.listDealProducts(s, dealId);
  const currentById = new Map(current.map((c) => [Number(c.id), c]));
  const variantCache = new Map();
  const summary = { created: [], reused: [], updated: 0, attached: 0, removed: 0 };

  const same = (a, b) => variantFields.every((f) => pd.valuesEqual(a[f.code], b[f.code]));

  async function resolveProduct(line) {
    let base = null;
    let baseValues = {};
    if (line.productId) {
      [base] = await pd.fetchProducts(s, [line.productId]);
      if (!base) throw new PdError(404, 'The selected product no longer exists in the Products list.');
      baseValues = pd.valuesOf(base, variantFields);
      if (same(baseValues, line.values)) return { productId: base.id, created: false, reused: false };
    }
    let name = base ? base.name : line.name;
    if (base) {
      // Optional: add the changed fields the user ticked to the new product's name, e.g. "Pipe_OD:70_WT:3 mm".
      const chosen = variantFields.filter((f) => line.suffixCodes.includes(f.code) && !pd.valuesEqual(baseValues[f.code], line.values[f.code]));
      if (chosen.length) name = `${base.name}_${chosen.map((f) => `${f.name}:${pd.displayValue(line.values[f.code], f) || 'none'}`).join('_')}`;
      if (name.length > MAX_NAME) throw new PdError(422, `The product name would be longer than ${MAX_NAME} characters. Untick some fields in "Add to product name".`);
    }
    const code = base ? base.code : line.code;
    const ck = [norm(name), norm(code), JSON.stringify(line.values)].join('|');
    if (variantCache.has(ck)) return { ...variantCache.get(ck), created: false, reused: true };

    // Reuse a product with the same name, code and editable-field values if one already exists.
    const ids = await pd.searchProductIds(s, name, { exact: true, limit: 20 });
    const candidates = await pd.fetchProducts(s, ids);
    const hit = candidates.find((p) => norm(p.name) === norm(name) && norm(p.code) === norm(code) && same(pd.valuesOf(p, variantFields), line.values));
    if (hit) {
      variantCache.set(ck, { productId: hit.id });
      return { productId: hit.id, created: false, reused: true, name };
    }

    const customFields = (bare) => {
      const cf = {};
      for (const [k, val] of Object.entries(base?.custom_fields || {})) if (val !== null && val !== undefined && val !== '') cf[k] = val;
      for (const f of variantFields) {
        delete cf[f.code];
        // If the master product shows a bare id for this field, write bare ids too.
        const hint = base?.custom_fields?.[f.code];
        const val = pd.apiValue(line.values[f.code], f, { bare: bare ?? (typeof hint === 'number') });
        if (val !== null) cf[f.code] = val;
      }
      return cf;
    };
    const prices = base?.prices?.length ? base.prices : [{ price: line.itemPrice, currency: deal.currency }];
    const createBody = { name, prices, custom_fields: customFields(undefined) };
    if (code) createBody.code = String(code);
    if (base) {
      for (const k of ['description', 'unit', 'category', 'is_linkable']) if (base[k] !== null && base[k] !== undefined) createBody[k] = base[k];
      createBody.tax = base.tax ?? 0;
    } else {
      createBody.tax = line.tax;
    }
    let made;
    try {
      made = await pd.createProduct(s, createBody);
    } catch (e) {
      // Users, organizations and people accept an object or a bare id depending on the API; retry once with the other form.
      const lookups = variantFields.some((f) => pd.LOOKUP_TYPES.has(f.type) && line.values[f.code]);
      if (!lookups || ![400, 422].includes(e.status)) throw e;
      const first = createBody.custom_fields;
      const other = customFields(!variantFields.some((f) => pd.LOOKUP_TYPES.has(f.type) && typeof first[f.code] !== 'object'));
      try { made = await pd.createProduct(s, { ...createBody, custom_fields: other }); } catch { throw e; }
    }
    variantCache.set(ck, { productId: made.id });
    return { productId: made.id, created: true, reused: false, name };
  }

  const results = [];
  for (const line of v.lines) {
    const r = { key: line.key, ok: false, name: line.name };
    try {
      const existing = line.dealProductId ? currentById.get(line.dealProductId) : null;
      if (line.dealProductId && !existing) throw new PdError(409, 'This line was removed from the deal elsewhere. Reload the editor.');
      line.values = await pd.withNames(s, line.values, variantFields);
      const target = await resolveProduct(line);
      r.productId = target.productId;
      r.productCreated = target.created;
      r.productReused = target.reused;
      const label = target.name || line.name || `#${target.productId}`;
      r.productName = target.name || undefined;
      if (target.created) summary.created.push(label);
      else if (target.reused) summary.reused.push(label);

      if (existing && Number(existing.product_id) === target.productId) {
        if (differs(existing, line, v.taxMethod)) {
          await pd.updateDealProduct(s, dealId, existing.id, dealProductBody(line, v.taxMethod));
          summary.updated++;
          r.action = 'updated';
        } else {
          r.action = 'unchanged';
        }
        r.dealProductId = Number(existing.id);
      } else {
        // New line, or the product behind an existing line changed: attach first, delete the old line second.
        const attached = await pd.attachProduct(s, dealId, { product_id: target.productId, ...dealProductBody(line, v.taxMethod) });
        r.dealProductId = Number(attached.id);
        summary.attached++;
        r.action = existing ? 'replaced' : 'added';
        if (existing) {
          try {
            await pd.deleteDealProduct(s, dealId, existing.id);
            currentById.delete(Number(existing.id));
          } catch (e) {
            if (e.code === 'NOT_AUTHORIZED') throw e;
            r.warning = `The new line was added, but the old line could not be removed (${e.message}). It will be retried on the next save.`;
            r.pendingDeletes = [Number(existing.id)];
          }
        }
      }
      r.values = line.values;
      r.ok = true;
    } catch (e) {
      if (e.code === 'NOT_AUTHORIZED') throw e;
      r.error = e.message || 'Unknown error';
    }
    results.push(r);
  }

  const deleted = [];
  for (const id of v.removed) {
    if (!currentById.has(id)) { deleted.push({ id, ok: true, alreadyGone: true }); continue; }
    try {
      await pd.deleteDealProduct(s, dealId, id);
      summary.removed++;
      deleted.push({ id, ok: true });
    } catch (e) {
      if (e.code === 'NOT_AUTHORIZED') throw e;
      deleted.push({ id, ok: false, error: e.message });
    }
  }

  const ok = results.every((r) => r.ok && !r.warning) && deleted.every((d) => d.ok);
  return { status: ok ? 200 : 207, body: { ok, results, deleted, summary } };
}
