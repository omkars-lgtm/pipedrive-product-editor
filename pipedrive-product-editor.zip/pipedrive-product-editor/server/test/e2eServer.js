// Starts the real app + a fake Pipedrive for browser tests. Not part of production.
import http from 'node:http';
import jwt from 'jsonwebtoken';
import { createApp } from '../app.js';
import { createStore } from '../store.js';
import { startMockPipedrive, MIN_KEY, MAX_KEY, OD_KEY, WT_KEY } from './mockPipedrive.js';

const APP_PORT = Number(process.env.E2E_APP_PORT || 4101);
const STATE_PORT = Number(process.env.E2E_STATE_PORT || 4102);
const mock = await startMockPipedrive();
const store = createStore('');
const config = {
  port: APP_PORT, clientId: 'cid', clientSecret: 'csecret', jwtSecret: '', redirectUri: `http://127.0.0.1:${APP_PORT}/auth/pipedrive/callback`,
  oauthBase: mock.url, databaseUrl: '', modalActionId: process.env.E2E_MODAL_ID || '', minFieldKey: '', maxFieldKey: '',
  frameAncestors: '*', allowAnyApiDomain: true, clientDist: '',
};
const geoFetch = async () => ({ ok: true, json: async () => ({ features: [{ properties: { name: 'Borivali', city: 'Mumbai', state: 'Maharashtra', country: 'India' } }, { properties: { name: 'Bordeaux', country: 'France' } }] }) });
const app = createApp({ config, store, geoFetch });
await new Promise((r) => app.listen(APP_PORT, '127.0.0.1', r));

const p1 = mock.state.addProduct({ name: 'Test Product 1', code: 'TP1', unit: 'pc', description: 'First product', category: 3, custom_fields: { [MIN_KEY]: 5, [MAX_KEY]: 10, [OD_KEY]: '60.3', [WT_KEY]: 7 }, prices: [{ price: 10, currency: 'USD' }] });
const p2 = mock.state.addProduct({ name: 'Test Product 2', custom_fields: { [MIN_KEY]: 1, [MAX_KEY]: 3 }, prices: [{ price: 20, currency: 'USD' }] });
mock.state.addProduct({ name: 'Rod Steel', code: 'RS-1', tax: 5, custom_fields: { [MIN_KEY]: 2, [MAX_KEY]: 8 }, prices: [{ price: 30, currency: 'USD' }] });
mock.state.addProduct({ name: 'Autoprod', custom_fields: { ['2'.repeat(40)]: 'auto1' }, prices: [{ price: 1, currency: 'USD' }] });
mock.state.addDealProduct(p1.id, { item_price: 10 });
mock.state.addDealProduct(p2.id, { item_price: 20, comments: '<b>Note</b> here' });
await fetch(`http://127.0.0.1:${APP_PORT}/auth/pipedrive/callback?code=goodcode`);

const token = jwt.sign({ userId: 7, companyId: 99 }, 'csecret', { algorithm: 'HS256', expiresIn: 3600 });
http.createServer((req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify({
    products: [...mock.state.products.values()],
    dealProducts: [...mock.state.dealProducts.values()],
    calls: mock.state.calls,
  }));
}).listen(STATE_PORT, '127.0.0.1');

console.log(JSON.stringify({ ready: true, app: `http://127.0.0.1:${APP_PORT}`, state: `http://127.0.0.1:${STATE_PORT}`, token, minKey: MIN_KEY, maxKey: MAX_KEY }));
