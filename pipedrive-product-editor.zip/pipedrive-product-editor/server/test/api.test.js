import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import jwt from 'jsonwebtoken';
import { createApp } from '../app.js';
import { createStore } from '../store.js';
import { startMockPipedrive, MIN_KEY, OD_KEY, WT_KEY, MAX_KEY } from './mockPipedrive.js';

let mock, store, server, base;
const CLIENT_SECRET = 'csecret';
const tokenFor = (o = {}) => jwt.sign({ userId: 7, companyId: 99, ...o }, CLIENT_SECRET, { algorithm: 'HS256', expiresIn: 300 });

async function boot(opts) {
  mock = await startMockPipedrive(opts);
  store = createStore(process.env.TEST_DATABASE_URL || '');
  await store.init();
  const config = {
    port: 0, clientId: 'cid', clientSecret: CLIENT_SECRET, jwtSecret: '', redirectUri: 'https://app.example/auth/pipedrive/callback',
    oauthBase: mock.url, databaseUrl: '', modalActionId: 'modal-1', minFieldKey: '', maxFieldKey: '',
    frameAncestors: 'https://*.pipedrive.com', allowAnyApiDomain: true, clientDist: '/nonexistent',
  };
  const app = createApp({ config, store });
  await new Promise((r) => { server = app.listen(0, '127.0.0.1', r); });
  base = `http://127.0.0.1:${server.address().port}`;
}
async function shutdown() { await store.close(); await new Promise((r) => { server.closeAllConnections?.(); server.close(r); }); await mock.close(); }

const api = async (method, path, body, token = tokenFor()) => {
  const res = await fetch(base + path, {
    method, headers: { 'Content-Type': 'application/json', ...(token ? { 'x-pd-token': token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, json: await res.json().catch(() => null) };
};
const authorize = async () => (await fetch(`${base}/auth/pipedrive/callback?code=goodcode`)).status;
// `min`/`max` are shorthand for values of the default editable fields (the product fields named Min and Max).
const line = ({ min, max, ...over } = {}) => {
  const values = { ...(over.values || {}) };
  if (min !== undefined) values[MIN_KEY] = min;
  if (max !== undefined) values[MAX_KEY] = max;
  return { key: 'k' + Math.random(), itemPrice: 10, quantity: 1, discount: 0, discountType: 'percentage', tax: 0, comments: '', isEnabled: true, ...over, values };
};

before(async () => { await boot(); });
after(shutdown);
beforeEach(async () => {
  mock.state.products.clear(); mock.state.dealProducts.clear(); mock.state.failDeleteIds.clear();
  mock.state.rejectDuplicateNames = false;
  mock.state.nextProductId = 100; mock.state.nextDealProductId = 500;
  mock.state.validCodes.add('goodcode');
  mock.state.accessToken = 'AT1'; mock.state.refreshToken = 'RT1'; mock.state.counter = 1;
  await store.remove(99, 7);
  await authorize();
});

test('OAuth callback is a server route, exchanges the code and stores tokens per company+user', async () => {
  const rec = await store.get(99, 7);
  assert.equal(rec.accessToken, 'AT1');
  assert.equal(rec.refreshToken, 'RT1');
  const again = await fetch(`${base}/auth/pipedrive/callback?code=goodcode`);
  assert.equal(again.status, 401, 'a reused code must fail');
  const missing = await fetch(`${base}/auth/pipedrive/callback`);
  assert.equal(missing.status, 400);
  const html = await (await fetch(`${base}/auth/pipedrive/callback?code=goodcode`)).text();
  assert.ok(!html.includes('AT1'), 'tokens never appear in responses');
});

test('API rejects missing, forged and wrongly signed tokens', async () => {
  assert.equal((await api('GET', '/api/deals/1/bootstrap', null, null)).status, 401);
  assert.equal((await api('GET', '/api/deals/1/bootstrap', null, 'not.a.jwt')).status, 401);
  const forged = jwt.sign({ userId: 7, companyId: 99 }, 'wrong-secret');
  assert.equal((await api('GET', '/api/deals/1/bootstrap', null, forged)).status, 401);
  const noneAlg = jwt.sign({ userId: 7, companyId: 99 }, '', { algorithm: 'none' });
  assert.equal((await api('GET', '/api/deals/1/bootstrap', null, noneAlg)).status, 401);
});

test('user who never authorized gets NOT_AUTHORIZED with an authorize link', async () => {
  const r = await api('GET', '/api/deals/1/bootstrap', null, tokenFor({ userId: 8 }));
  assert.equal(r.status, 401);
  assert.equal(r.json.code, 'NOT_AUTHORIZED');
  assert.equal(r.json.authorizeUrl, '/auth/pipedrive');
});

test('cannot read a deal the user cannot see (deal id is not trusted from the token)', async () => {
  const r = await api('GET', '/api/deals/999/bootstrap');
  assert.equal(r.status, 404);
});

test('bootstrap returns deal lines enriched with Min/Max from the master product', async () => {
  const p = mock.state.addProduct({ name: 'Test Product 1', code: 'TP1', custom_fields: { [MIN_KEY]: 5, [MAX_KEY]: 9 }, prices: [{ price: 10, currency: 'USD' }] });
  mock.state.addDealProduct(p.id, { item_price: 10 });
  const r = await api('GET', '/api/deals/1/bootstrap');
  assert.equal(r.status, 200);
  assert.equal(r.json.deal.title, 'Moveer Deal');
  assert.equal(r.json.lines.length, 1);
  assert.equal(r.json.lines[0].values[MIN_KEY], 5);
  assert.equal(r.json.lines[0].values[MAX_KEY], 9);
  assert.deepEqual(r.json.variantFields.map((f) => f.name), ['Min', 'Max']);
});

test('bootstrap and search return every product field, custom ones included, with option labels', async () => {
  const p = mock.state.addProduct({ name: 'Pipe X', code: 'PX', unit: 'm', tax: 5, description: 'Seamless', category: 3,
    custom_fields: { [MIN_KEY]: 2, [MAX_KEY]: 8, [OD_KEY]: '60.3', [WT_KEY]: 7 }, prices: [{ price: 10, currency: 'USD' }] });
  mock.state.addDealProduct(p.id, { item_price: 10 });
  const r = await api('GET', '/api/deals/1/bootstrap');
  const d = Object.fromEntries(r.json.lines[0].details.map((x) => [x.label, x]));
  assert.equal(d['Product code'].value, 'PX');
  assert.equal(d['Unit'].value, 'm');
  assert.equal(d['Description'].value, 'Seamless');
  assert.equal(d['Category'].value, 'Valves');
  assert.equal(d['OD'].value, '60.3');
  assert.equal(d['WT'].value, '2.5 mm');
  assert.equal(d['Min'].variant, true);
  assert.equal(d['OD'].variant, false);
  const s = await api('GET', '/api/products/search?q=pipe');
  assert.ok(s.json.items[0].details.some((x) => x.label === 'OD' && x.value === '60.3'));
});

test('settings: everyone can read, only admins can change; invalid fields are rejected', async () => {
  const g = await api('GET', '/api/settings');
  assert.equal(g.status, 200);
  assert.equal(g.json.isAdmin, true);
  assert.equal(g.json.isDefault, true);
  assert.deepEqual(g.json.selected, [MIN_KEY, MAX_KEY]);
  const names = g.json.candidates.map((c) => c.name);
  assert.ok(['Min', 'Max', 'OD', 'WT'].every((n) => names.includes(n)) && !names.includes('Name'), 'only custom, editable-type fields are offered');

  assert.equal((await api('PUT', '/api/settings', { variantFieldCodes: ['nope'] })).status, 422);
  assert.equal((await api('PUT', '/api/settings', { variantFieldCodes: 'x' })).status, 422);
  const ok = await api('PUT', '/api/settings', { variantFieldCodes: [OD_KEY, WT_KEY] });
  assert.equal(ok.status, 200);
  const again = await api('GET', '/api/settings');
  assert.deepEqual(again.json.selected, [OD_KEY, WT_KEY]);
  assert.equal(again.json.isDefault, false);

  mock.state.isAdmin = false;
  const denied = await api('PUT', '/api/settings', { variantFieldCodes: [MIN_KEY] });
  assert.equal(denied.status, 403);
  assert.equal((await api('GET', '/api/settings')).json.isAdmin, false);
  mock.state.isAdmin = true;
  await api('PUT', '/api/settings', { variantFieldCodes: [MIN_KEY, MAX_KEY] });
});

test('admin-chosen fields: changing OD/WT creates a variant; unchosen fields are ignored; name suffix is optional', async () => {
  await api('PUT', '/api/settings', { variantFieldCodes: [OD_KEY, WT_KEY] });
  const p = mock.state.addProduct({ name: 'Pipe', code: 'PP', custom_fields: { [MIN_KEY]: 1, [OD_KEY]: '60.3', [WT_KEY]: 7 }, prices: [{ price: 10, currency: 'USD' }] });
  const body = (over) => ({ taxMethod: 'inclusive', lines: [line({ key: 'a', productId: p.id, name: 'Pipe', values: { [OD_KEY]: '70', [WT_KEY]: 7 }, ...over })] });

  // unchanged chosen fields + a changed UNCHOSEN field (Min) -> no new product
  const same = await api('POST', '/api/deals/1/save', { taxMethod: 'inclusive', lines: [line({ key: 'x', productId: p.id, name: 'Pipe', values: { [OD_KEY]: '60.3', [WT_KEY]: 7, [MIN_KEY]: 99 } })] });
  assert.equal(same.status, 200);
  assert.equal(mock.state.products.size, 1);

  // changed OD, no suffix -> same name, new product, other fields copied, original untouched
  const r1 = await api('POST', '/api/deals/1/save', body());
  assert.equal(r1.status, 200, JSON.stringify(r1.json));
  assert.equal(mock.state.products.size, 2);
  const v1 = [...mock.state.products.values()].find((x) => x.id !== p.id);
  assert.equal(v1.name, 'Pipe');
  assert.equal(v1.custom_fields[OD_KEY], '70');
  assert.equal(v1.custom_fields[WT_KEY], 7);
  assert.equal(v1.custom_fields[MIN_KEY], 1, 'untouched custom fields are carried over');
  assert.equal(mock.state.products.get(p.id).custom_fields[OD_KEY], '60.3');

  // same change again -> reused
  mock.state.dealProducts.clear();
  const r1b = await api('POST', '/api/deals/1/save', body());
  assert.equal(mock.state.products.size, 2);
  assert.equal(r1b.json.summary.reused.length, 1);

  // changed OD and WT, both ticked -> suffix with field names and option labels; only changed+ticked fields count
  mock.state.dealProducts.clear();
  const r2 = await api('POST', '/api/deals/1/save', body({ values: { [OD_KEY]: '80', [WT_KEY]: 7 }, suffixCodes: [OD_KEY, WT_KEY] }));
  assert.equal(r2.status, 200);
  assert.ok([...mock.state.products.values()].some((x) => x.name === 'Pipe_OD:80'), 'WT was not changed so it is not in the name');
});

test('dropdown fields are validated against their options and shown by label in the name', async () => {
  await api('PUT', '/api/settings', { variantFieldCodes: [WT_KEY] });
  const p = mock.state.addProduct({ name: 'Tube', custom_fields: { [WT_KEY]: 7 }, prices: [{ price: 5, currency: 'USD' }] });
  const bad = await api('POST', '/api/deals/1/save', { taxMethod: 'inclusive', lines: [line({ key: 'a', productId: p.id, name: 'Tube', values: { [WT_KEY]: 999 } })] });
  assert.equal(bad.status, 422);
  const ok = await api('POST', '/api/deals/1/save', { taxMethod: 'inclusive', lines: [line({ key: 'a', productId: p.id, name: 'Tube', values: { [WT_KEY]: 8 }, suffixCodes: [WT_KEY] })] });
  assert.equal(ok.status, 200, JSON.stringify(ok.json));
  assert.ok([...mock.state.products.values()].some((x) => x.name === 'Tube_WT:3 mm'));
  await api('PUT', '/api/settings', { variantFieldCodes: [MIN_KEY, MAX_KEY] });
});

test('expired access token is refreshed (refresh token rotates) and the call is retried', async () => {
  const rec = await store.get(99, 7);
  await store.save({ ...rec, expiresAt: Date.now() - 1000 });
  const r = await api('GET', '/api/deals/1/bootstrap');
  assert.equal(r.status, 200);
  const after = await store.get(99, 7);
  assert.equal(after.accessToken, 'AT2');
  assert.equal(after.refreshToken, 'RT2');
});

test('a 401 from Pipedrive triggers one refresh and a retry', async () => {
  mock.state.accessToken = 'REVOKED-ON-SERVER'; // stored token no longer matches
  mock.state.refreshToken = 'RT1';
  const r = await api('GET', '/api/deals/1/bootstrap');
  assert.equal(r.status, 200);
  assert.equal((await store.get(99, 7)).refreshToken, 'RT2');
});

test('revoked refresh token yields NOT_AUTHORIZED, not a crash', async () => {
  mock.state.accessToken = 'X'; mock.state.refreshToken = 'DIFFERENT';
  const r = await api('GET', '/api/deals/1/bootstrap');
  assert.equal(r.status, 401);
  assert.equal(r.json.code, 'NOT_AUTHORIZED');
});

test('search returns Min/Max and prices; short queries return nothing', async () => {
  mock.state.addProduct({ name: 'Widget', code: 'W1', custom_fields: { [MIN_KEY]: 1, [MAX_KEY]: 2 }, prices: [{ price: 12, currency: 'USD' }] });
  assert.deepEqual((await api('GET', '/api/products/search?q=w')).json.items, []);
  const r = await api('GET', '/api/products/search?q=widg');
  assert.equal(r.json.items.length, 1);
  assert.equal(r.json.items[0].values[MIN_KEY], 1);
  assert.equal(r.json.items[0].prices[0].price, 12);
});

test('rule (a): existing product, Min/Max unchanged -> attached as is, no new product', async () => {
  const p = mock.state.addProduct({ name: 'Rod', custom_fields: { [MIN_KEY]: 2, [MAX_KEY]: 8 }, prices: [{ price: 10, currency: 'USD' }] });
  const r = await api('POST', '/api/deals/1/save', { taxMethod: 'inclusive', lines: [line({ key: 'a', productId: p.id, name: 'Rod', min: '2', max: '8' })] });
  assert.equal(r.status, 200);
  assert.equal(r.json.ok, true);
  assert.equal(mock.state.products.size, 1, 'no new master product');
  assert.equal([...mock.state.dealProducts.values()][0].product_id, p.id);
});

test('rule (b): existing product with changed Max -> NEW master product, original untouched', async () => {
  const p = mock.state.addProduct({ name: 'Rod', code: 'R1', unit: 'pcs', tax: 5, custom_fields: { [MIN_KEY]: 2, [MAX_KEY]: 8 }, prices: [{ price: 10, currency: 'USD' }] });
  const r = await api('POST', '/api/deals/1/save', { taxMethod: 'inclusive', lines: [line({ key: 'a', productId: p.id, name: 'Rod', min: '2', max: '99' })] });
  assert.equal(r.status, 200);
  assert.equal(mock.state.products.size, 2);
  assert.equal(mock.state.products.get(p.id).custom_fields[MAX_KEY], 8, 'original unchanged');
  const created = [...mock.state.products.values()].find((x) => x.id !== p.id);
  assert.equal(created.name, 'Rod');
  assert.equal(created.code, 'R1');
  assert.equal(created.unit, 'pcs');
  assert.equal(created.custom_fields[MIN_KEY], 2);
  assert.equal(created.custom_fields[MAX_KEY], 99);
  assert.equal([...mock.state.dealProducts.values()][0].product_id, created.id);
  assert.deepEqual(r.json.summary.created, ['Rod']);
});

test('rule (b) is idempotent: saving the same variant twice reuses it instead of duplicating', async () => {
  const p = mock.state.addProduct({ name: 'Rod', custom_fields: { [MIN_KEY]: 2, [MAX_KEY]: 8 }, prices: [{ price: 10, currency: 'USD' }] });
  const body = () => ({ taxMethod: 'inclusive', lines: [line({ key: 'a', productId: p.id, name: 'Rod', min: '2', max: '99' })] });
  await api('POST', '/api/deals/1/save', body());
  mock.state.dealProducts.clear();
  const r2 = await api('POST', '/api/deals/1/save', body());
  assert.equal(r2.status, 200);
  assert.equal(mock.state.products.size, 2, 'second save reuses the variant');
  assert.deepEqual(r2.json.summary.reused, ['Rod']);
});

test('rule (c): brand-new typed product is created in the master list with Min/Max, then attached', async () => {
  const r = await api('POST', '/api/deals/1/save', { taxMethod: 'exclusive', lines: [line({ key: 'n', name: 'Brand New', code: 'BN', min: '1.5', max: '4', itemPrice: 25, quantity: 3, tax: 18 })] });
  assert.equal(r.status, 200);
  const created = [...mock.state.products.values()][0];
  assert.equal(created.name, 'Brand New');
  assert.equal(created.custom_fields[MIN_KEY], 1.5);
  assert.equal(created.prices[0].price, 25);
  assert.equal(created.prices[0].currency, 'USD');
  const dp = [...mock.state.dealProducts.values()][0];
  assert.equal(dp.quantity, 3);
  assert.equal(dp.tax_method, 'exclusive');
});

test('rule (d): changing Min/Max on an existing line attaches the new product first, then deletes the old line', async () => {
  const p = mock.state.addProduct({ name: 'Rod', custom_fields: { [MIN_KEY]: 2, [MAX_KEY]: 8 }, prices: [{ price: 10, currency: 'USD' }] });
  const dp = mock.state.addDealProduct(p.id, { quantity: 4, comments: 'keep me' });
  mock.state.calls.length = 0;
  const r = await api('POST', '/api/deals/1/save', { taxMethod: 'inclusive', lines: [line({ key: 'a', dealProductId: dp.id, productId: p.id, name: 'Rod', min: '2', max: '50', quantity: 4, comments: 'keep me' })] });
  assert.equal(r.status, 200);
  const postIdx = mock.state.calls.findIndex((c) => c === 'POST /api/v2/deals/1/products');
  const delIdx = mock.state.calls.findIndex((c) => c.startsWith('DELETE /api/v2/deals/1/products/'));
  assert.ok(postIdx >= 0 && delIdx > postIdx, 'attach happens before delete');
  assert.equal(mock.state.dealProducts.size, 1);
  const now = [...mock.state.dealProducts.values()][0];
  assert.notEqual(now.product_id, p.id);
  assert.equal(now.quantity, 4);
  assert.equal(now.comments, 'keep me');
});

test('rule (d) failure safety: if deleting the old line fails nothing is lost and the delete is retried via pendingDeletes', async () => {
  const p = mock.state.addProduct({ name: 'Rod', custom_fields: { [MIN_KEY]: 2, [MAX_KEY]: 8 }, prices: [{ price: 10, currency: 'USD' }] });
  const dp = mock.state.addDealProduct(p.id);
  mock.state.failDeleteIds.add(dp.id);
  const r = await api('POST', '/api/deals/1/save', { taxMethod: 'inclusive', lines: [line({ key: 'a', dealProductId: dp.id, productId: p.id, name: 'Rod', min: '2', max: '50' })] });
  assert.equal(r.status, 207);
  assert.equal(r.json.results[0].ok, true);
  assert.deepEqual(r.json.results[0].pendingDeletes, [dp.id]);
  assert.equal(mock.state.dealProducts.size, 2, 'both lines exist: no data lost');
  mock.state.failDeleteIds.clear();
  const r2 = await api('POST', '/api/deals/1/save', { taxMethod: 'inclusive', lines: [], removedDealProductIds: [dp.id] });
  assert.equal(r2.status, 200);
  assert.equal(mock.state.dealProducts.size, 1);
});

test('rule (e): other edits PATCH the deal line only; untouched lines are not re-sent', async () => {
  const p = mock.state.addProduct({ name: 'Rod', custom_fields: { [MIN_KEY]: 2, [MAX_KEY]: 8 }, prices: [{ price: 10, currency: 'USD' }] });
  const a = mock.state.addDealProduct(p.id);
  const b = mock.state.addDealProduct(p.id, { quantity: 2 });
  mock.state.calls.length = 0;
  const r = await api('POST', '/api/deals/1/save', { taxMethod: 'inclusive', lines: [
    line({ key: 'a', dealProductId: a.id, productId: p.id, name: 'Rod', min: '2', max: '8', quantity: 7 }),
    line({ key: 'b', dealProductId: b.id, productId: p.id, name: 'Rod', min: '2', max: '8', quantity: 2 }),
  ] });
  assert.equal(r.status, 200);
  assert.equal(mock.state.dealProducts.get(a.id).quantity, 7);
  assert.equal(mock.state.calls.filter((c) => c.startsWith('PATCH')).length, 1);
  assert.equal(mock.state.products.size, 1);
});

test('rule (f): removed rows delete only the deal line, never the master product', async () => {
  const p = mock.state.addProduct({ name: 'Rod', custom_fields: {}, prices: [] });
  const dp = mock.state.addDealProduct(p.id);
  const r = await api('POST', '/api/deals/1/save', { taxMethod: 'inclusive', lines: [], removedDealProductIds: [dp.id] });
  assert.equal(r.status, 200);
  assert.equal(mock.state.dealProducts.size, 0);
  assert.equal(mock.state.products.size, 1);
  assert.equal(r.json.summary.removed, 1);
});

test('duplicate-name rejection from Pipedrive surfaces as a per-row error and nothing is attached', async () => {
  const p = mock.state.addProduct({ name: 'Rod', custom_fields: { [MIN_KEY]: 2, [MAX_KEY]: 8 }, prices: [{ price: 10, currency: 'USD' }] });
  mock.state.rejectDuplicateNames = true;
  const r = await api('POST', '/api/deals/1/save', { taxMethod: 'inclusive', lines: [line({ key: 'a', productId: p.id, name: 'Rod', min: '2', max: '99' })] });
  assert.equal(r.status, 207);
  assert.equal(r.json.results[0].ok, false);
  assert.match(r.json.results[0].error, /already exists/);
  assert.equal(mock.state.dealProducts.size, 0);
});

test('one failing row does not block the others', async () => {
  const p = mock.state.addProduct({ name: 'Rod', custom_fields: { [MIN_KEY]: 2, [MAX_KEY]: 8 }, prices: [{ price: 10, currency: 'USD' }] });
  mock.state.rejectDuplicateNames = true;
  const r = await api('POST', '/api/deals/1/save', { taxMethod: 'inclusive', lines: [
    line({ key: 'bad', productId: p.id, name: 'Rod', min: '2', max: '99' }),
    line({ key: 'good', productId: p.id, name: 'Rod', min: '2', max: '8' }),
  ] });
  assert.equal(r.status, 207);
  assert.equal(r.json.results.find((x) => x.key === 'bad').ok, false);
  assert.equal(r.json.results.find((x) => x.key === 'good').ok, true);
  assert.equal(mock.state.dealProducts.size, 1);
});

test('validation: bad numbers, Min > Max, empty product, huge comments are rejected before any Pipedrive write', async () => {
  mock.state.calls.length = 0;
  const r = await api('POST', '/api/deals/1/save', { taxMethod: 'inclusive', lines: [
    line({ key: 'a', name: 'X', min: '10', max: '5' }),
    line({ key: 'b', name: 'Y', quantity: 0 }),
    line({ key: 'c', name: '' }),
    line({ key: 'd', name: 'Z', itemPrice: 'abc' }),
    line({ key: 'e', name: 'W', comments: 'x'.repeat(2001) }),
    line({ key: 'f', name: 'V', discount: 150 }),
    line({ key: 'g', name: 'U', min: 'zz' }),
  ] });
  assert.equal(r.status, 422);
  for (const k of ['a', 'b', 'c', 'd', 'e', 'f', 'g']) assert.ok(r.json.lineErrors[k], `row ${k} flagged`);
  assert.ok(!mock.state.calls.some((c) => c.startsWith('POST /api/v2/products') || c.startsWith('POST /api/v2/deals')), 'no writes happened');
});

test('comments are sanitised (scripts, handlers, javascript: links removed)', async () => {
  const r = await api('POST', '/api/deals/1/save', { taxMethod: 'inclusive', lines: [line({ key: 'n', name: 'San', comments: '<b>ok</b><script>alert(1)</script><img src=x onerror=alert(2)><a href="javascript:alert(3)">x</a><a href="https://example.com">y</a>' })] });
  assert.equal(r.status, 200);
  const saved = [...mock.state.dealProducts.values()][0].comments;
  assert.ok(!/script|onerror|javascript:|<img/i.test(saved), saved);
  assert.match(saved, /<b>ok<\/b>/);
  assert.match(saved, /https:\/\/example\.com/);
});

test('Min/Max may be left empty', async () => {
  const r = await api('POST', '/api/deals/1/save', { taxMethod: 'inclusive', lines: [line({ key: 'n', name: 'NoMinMax' })] });
  assert.equal(r.status, 200);
  const created = [...mock.state.products.values()][0];
  assert.equal(MIN_KEY in created.custom_fields, false);
});

test('security headers: only Pipedrive may frame the app', async () => {
  const r = await fetch(`${base}/api/config`);
  assert.match(r.headers.get('content-security-policy'), /frame-ancestors https:\/\/\*\.pipedrive\.com/);
  assert.equal((await r.json()).modalActionId, 'modal-1');
});
