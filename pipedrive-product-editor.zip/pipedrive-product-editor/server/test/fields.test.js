import { test } from 'node:test';
import assert from 'node:assert/strict';
import jwt from 'jsonwebtoken';
import { createApp } from '../app.js';
import { createStore } from '../store.js';
import { startMockPipedrive } from './mockPipedrive.js';
import { sanitizeHtml, textLength } from '../sanitize.js';

test('without any Min/Max or chosen fields the editor still works, with a hint for admins', async () => {
  const mock = await startMockPipedrive({ withFields: false });
  const store = createStore('');
  const config = { clientId: 'cid', clientSecret: 'csecret', jwtSecret: '', redirectUri: 'x', oauthBase: mock.url, allowAnyApiDomain: true,
    frameAncestors: '*', clientDist: '/nonexistent', minFieldKey: '', maxFieldKey: '', modalActionId: '' };
  const app = createApp({ config, store });
  const server = await new Promise((r) => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  const base = `http://127.0.0.1:${server.address().port}`;
  await fetch(`${base}/auth/pipedrive/callback?code=goodcode`);
  const token = jwt.sign({ userId: 7, companyId: 99 }, 'csecret', { algorithm: 'HS256' });
  const headers = { 'x-pd-token': token, 'Content-Type': 'application/json' };
  const boot = await (await fetch(`${base}/api/deals/1/bootstrap`, { headers })).json();
  assert.deepEqual(boot.variantFields, []);
  assert.match(boot.fieldsMessage, /admin/i);
  const save = await fetch(`${base}/api/deals/1/save`, { method: 'POST', headers, body: JSON.stringify({ taxMethod: 'inclusive', lines: [{ key: 'a', name: 'X', itemPrice: 1, quantity: 1 }] }) });
  assert.equal(save.status, 200);
  server.closeAllConnections?.(); server.close(); await mock.close();
});

test('sanitizer unit checks', () => {
  assert.equal(sanitizeHtml('<b>a</b>'), '<b>a</b>');
  assert.equal(sanitizeHtml('<script>x</script>t'), 't');
  assert.equal(sanitizeHtml('<p onclick="x()">t</p>'), '<p>t</p>');
  assert.equal(textLength('<b>abc</b>&nbsp;d'), 5);
});
