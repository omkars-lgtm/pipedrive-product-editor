import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createStore } from '../store.js';

// Runs against the in-memory store always, and against Postgres when TEST_DATABASE_URL is set.
for (const [label, url] of [['memory', ''], ['postgres', process.env.TEST_DATABASE_URL || null]]) {
  test(`token store (${label}): save, read, upsert, remove`, { skip: url === null && 'TEST_DATABASE_URL not set' }, async () => {
    const store = createStore(url);
    await store.init();
    await store.init(); // idempotent
    const rec = { companyId: 123456789012, userId: 42, accessToken: 'a1', refreshToken: 'r1', expiresAt: 1790000000000, apiDomain: 'https://x.pipedrive.com', scope: 'base products:full' };
    await store.remove(rec.companyId, rec.userId);
    assert.equal(await store.get(rec.companyId, rec.userId), null);
    await store.save(rec);
    assert.deepEqual(await store.get(rec.companyId, rec.userId), rec);
    await store.save({ ...rec, accessToken: 'a2', refreshToken: 'r2' });
    const again = await store.get(rec.companyId, rec.userId);
    assert.equal(again.accessToken, 'a2');
    assert.equal(again.refreshToken, 'r2');
    assert.equal(typeof again.expiresAt, 'number');
    assert.equal(await store.get(rec.companyId, 43), null, 'tokens are per user');
    await store.remove(rec.companyId, rec.userId);
    assert.equal(await store.get(rec.companyId, rec.userId), null);
    await store.close();
  });
}

import { encrypt, decrypt, isEncrypted } from '../crypto.js';

test('tokens are encrypted at rest, bound to their row, and plain legacy values still read', async () => {
  const key = '00'.repeat(32);
  const store = createStore('', { encryptionKey: key });
  const rec = { companyId: 5, userId: 6, accessToken: 'AT-secret', refreshToken: 'RT-secret', expiresAt: 1, apiDomain: 'https://x.pipedrive.com', scope: 'base' };
  await store.save(rec);
  const raw = await store.getRaw(5, 6);
  assert.ok(isEncrypted(raw.accessToken) && isEncrypted(raw.refreshToken));
  assert.ok(!raw.accessToken.includes('AT-secret'));
  assert.deepEqual(await store.get(5, 6), rec);
  // a ciphertext moved to another user's row must not decrypt
  assert.throws(() => decrypt(raw.accessToken, Buffer.from(key, 'hex'), '5:7'));
  // wrong key must not decrypt
  assert.throws(() => decrypt(raw.accessToken, Buffer.from('11'.repeat(32), 'hex'), '5:6'));
  // legacy plain text passes through
  assert.equal(decrypt('plain', Buffer.from(key, 'hex'), 'x'), 'plain');
  assert.notEqual(encrypt('a', Buffer.from(key, 'hex'), 'x'), encrypt('a', Buffer.from(key, 'hex'), 'x'), 'random IV per value');
  assert.throws(() => createStore('', { encryptionKey: 'short' }));
});

test('company settings are stored per company', async () => {
  const store = createStore('');
  assert.equal(await store.getSettings(1), null);
  await store.saveSettings(1, { variantFieldCodes: ['a', 'b'] });
  assert.deepEqual(await store.getSettings(1), { variantFieldCodes: ['a', 'b'] });
  assert.equal(await store.getSettings(2), null);
});
