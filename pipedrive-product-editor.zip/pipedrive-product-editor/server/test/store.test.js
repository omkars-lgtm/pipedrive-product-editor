import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createStore } from '../store.js';

// Runs against the in-memory store always, and against Postgres when TEST_DATABASE_URL is set.
for (const [label, url] of [['memory', ''], ['postgres', process.env.TEST_DATABASE_URL || null]]) {
  test(`token store (${label}): save, read, upsert, remove`, { skip: url === null && 'TEST_DATABASE_URL not set' }, async () => {
    const store = createStore(url);
    await store.init();
    await store.init(); // idempotent
    const rec = { companyId: 123456789012, userId: 42, accessToken: 'a1', refreshToken: 'r1', expiresAt: 1790000000000, apiDomain: 'https://x.pipedrive.com', scope: 'base products:full' };
    await store.remove(rec.companyId, rec.userId);
    assert.equal(await store.get(rec.companyId, rec.userId), null);
    await store.save(rec);
    assert.deepEqual(await store.get(rec.companyId, rec.userId), rec);
    await store.save({ ...rec, accessToken: 'a2', refreshToken: 'r2' });
    const again = await store.get(rec.companyId, rec.userId);
    assert.equal(again.accessToken, 'a2');
    assert.equal(again.refreshToken, 'r2');
    assert.equal(typeof again.expiresAt, 'number');
    assert.equal(await store.get(rec.companyId, 43), null, 'tokens are per user');
    await store.remove(rec.companyId, rec.userId);
    assert.equal(await store.get(rec.companyId, rec.userId), null);
    await store.close();
  });
}
