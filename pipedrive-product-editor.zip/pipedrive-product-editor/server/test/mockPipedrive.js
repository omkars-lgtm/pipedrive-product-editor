// A small in-memory fake of the Pipedrive endpoints this app uses. Used ONLY by tests: it is not Pipedrive.
import http from 'node:http';

export const MIN_KEY = 'a'.repeat(40);
export const MAX_KEY = 'b'.repeat(40);

export async function startMockPipedrive({ withFields = true } = {}) {
  const state = {
    clientId: 'cid', clientSecret: 'csecret',
    accessToken: 'AT1', refreshToken: 'RT1', counter: 1,
    validCodes: new Set(['goodcode']),
    calls: [],
    deal: { id: 1, title: 'Moveer Deal', currency: 'USD' },
    nextProductId: 100, nextDealProductId: 500,
    failDeleteIds: new Set(),
    rejectDuplicateNames: false,
    products: new Map(),
    dealProducts: new Map(),
    fields: withFields
      ? [{ field_name: 'Name', field_code: 'name', field_type: 'varchar' },
         { field_name: 'Min', field_code: MIN_KEY, field_type: 'double' },
         { field_name: 'Max', field_code: MAX_KEY, field_type: 'double' }]
      : [{ field_name: 'Name', field_code: 'name', field_type: 'varchar' }],
  };
  const addProduct = (p) => {
    const id = state.nextProductId++;
    const prod = { id, name: p.name, code: p.code ?? null, unit: p.unit ?? null, tax: p.tax ?? 0,
      prices: p.prices || [], custom_fields: p.custom_fields || {}, description: p.description ?? null, is_linkable: true };
    state.products.set(id, prod);
    return prod;
  };
  const addDealProduct = (productId, over = {}) => {
    const id = state.nextDealProductId++;
    const p = state.products.get(productId);
    const dp = { id, deal_id: 1, product_id: productId, name: p.name, item_price: 10, quantity: 1, discount: 0,
      discount_type: 'percentage', tax: 0, tax_method: 'inclusive', comments: '', is_enabled: true, currency: 'USD', ...over };
    state.dealProducts.set(id, dp);
    return dp;
  };
  state.addProduct = addProduct;
  state.addDealProduct = addDealProduct;

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://x');
    let raw = '';
    for await (const c of req) raw += c;
    const send = (status, body) => { res.writeHead(status, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(body)); };
    const bodyJson = () => { try { return JSON.parse(raw); } catch { return {}; } };
    state.calls.push(`${req.method} ${url.pathname}`);

    if (url.pathname === '/oauth/token' && req.method === 'POST') {
      const expected = 'Basic ' + Buffer.from(`${state.clientId}:${state.clientSecret}`).toString('base64');
      if (req.headers.authorization !== expected) return send(401, { error: 'invalid_client' });
      const p = new URLSearchParams(raw);
      const base = `http://127.0.0.1:${server.address().port}`;
      if (p.get('grant_type') === 'authorization_code') {
        if (!state.validCodes.delete(p.get('code'))) return send(400, { error: 'invalid_grant', message: 'bad code' });
        return send(200, { access_token: state.accessToken, refresh_token: state.refreshToken, expires_in: 3600, api_domain: base, scope: 'deals:full products:full', token_type: 'Bearer' });
      }
      if (p.get('grant_type') === 'refresh_token') {
        if (p.get('refresh_token') !== state.refreshToken) return send(400, { error: 'invalid_grant' });
        state.counter++;
        state.accessToken = `AT${state.counter}`; state.refreshToken = `RT${state.counter}`;
        return send(200, { access_token: state.accessToken, refresh_token: state.refreshToken, expires_in: 3600, api_domain: base, token_type: 'Bearer' });
      }
      return send(400, { error: 'unsupported_grant_type' });
    }

    if (req.headers.authorization !== `Bearer ${state.accessToken}`) return send(401, { success: false, error: 'Invalid token: access_token is invalid' });

    if (url.pathname === '/v1/users/me') return send(200, { data: { id: 7, company_id: 99 } });

    let m;
    if ((m = url.pathname.match(/^\/api\/v2\/deals\/(\d+)$/))) {
      return Number(m[1]) === state.deal.id ? send(200, { data: state.deal }) : send(404, { success: false, error: 'Deal not found' });
    }
    if ((m = url.pathname.match(/^\/api\/v2\/deals\/(\d+)\/products$/))) {
      if (req.method === 'GET') return send(200, { data: [...state.dealProducts.values()], additional_data: { next_cursor: null } });
      if (req.method === 'POST') {
        const b = bodyJson();
        if (!state.products.has(b.product_id)) return send(400, { success: false, error: 'product not found' });
        return send(200, { data: addDealProduct(b.product_id, b) });
      }
    }
    if ((m = url.pathname.match(/^\/api\/v2\/deals\/(\d+)\/products\/(\d+)$/))) {
      const id = Number(m[2]);
      const dp = state.dealProducts.get(id);
      if (!dp) return send(404, { success: false, error: 'not found' });
      if (req.method === 'PATCH') { Object.assign(dp, bodyJson()); return send(200, { data: dp }); }
      if (req.method === 'DELETE') {
        if (state.failDeleteIds.has(id)) return send(500, { success: false, error: 'boom' });
        state.dealProducts.delete(id); return send(200, { data: { id } });
      }
    }
    if (url.pathname === '/api/v2/productFields') return send(200, { data: state.fields, additional_data: { next_cursor: null } });
    if (url.pathname === '/api/v2/products/search') {
      const term = (url.searchParams.get('term') || '').toLowerCase();
      const exact = url.searchParams.get('exact_match') === 'true';
      const items = [...state.products.values()]
        .filter((p) => (exact ? p.name.toLowerCase() === term : p.name.toLowerCase().includes(term) || String(p.code || '').toLowerCase().includes(term)))
        .map((p) => ({ item: { id: p.id, name: p.name, code: p.code, custom_fields: [] } }));
      return send(200, { data: { items }, additional_data: {} });
    }
    if (url.pathname === '/api/v2/products' && req.method === 'GET') {
      const ids = (url.searchParams.get('ids') || '').split(',').filter(Boolean).map(Number);
      return send(200, { data: [...state.products.values()].filter((p) => !ids.length || ids.includes(p.id)), additional_data: { next_cursor: null } });
    }
    if (url.pathname === '/api/v2/products' && req.method === 'POST') {
      const b = bodyJson();
      if (state.rejectDuplicateNames && [...state.products.values()].some((p) => p.name === b.name)) {
        return send(400, { success: false, error: 'A product with this name already exists' });
      }
      return send(200, { data: addProduct(b) });
    }
    if ((m = url.pathname.match(/^\/api\/v2\/products\/(\d+)$/))) {
      const p = state.products.get(Number(m[1]));
      return p ? send(200, { data: p }) : send(404, { success: false, error: 'not found' });
    }
    send(404, { success: false, error: `mock: no route ${req.method} ${url.pathname}` });
  });

  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const url = `http://127.0.0.1:${server.address().port}`;
  return { url, state, close: () => new Promise((r) => { server.closeAllConnections?.(); server.close(r); }) };
}
