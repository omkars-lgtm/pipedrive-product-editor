import pg from 'pg';

// Stores one OAuth token set per (company, user). Each user acts with their OWN Pipedrive permissions.
const SCHEMA = `
CREATE TABLE IF NOT EXISTS installations (
  company_id    BIGINT NOT NULL,
  user_id       BIGINT NOT NULL,
  access_token  TEXT NOT NULL,
  refresh_token TEXT NOT NULL,
  expires_at    BIGINT NOT NULL,
  api_domain    TEXT NOT NULL,
  scope         TEXT,
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (company_id, user_id)
);`;

function fromRow(r) {
  if (!r) return null;
  return {
    companyId: Number(r.company_id),
    userId: Number(r.user_id),
    accessToken: r.access_token,
    refreshToken: r.refresh_token,
    expiresAt: Number(r.expires_at),
    apiDomain: r.api_domain,
    scope: r.scope || '',
  };
}

export function createStore(databaseUrl) {
  if (!databaseUrl) {
    const mem = new Map();
    return {
      kind: 'memory',
      async init() {},
      async get(companyId, userId) { return mem.get(`${companyId}:${userId}`) || null; },
      async save(rec) { mem.set(`${rec.companyId}:${rec.userId}`, { ...rec }); },
      async remove(companyId, userId) { mem.delete(`${companyId}:${userId}`); },
      async close() {},
    };
  }
  const local = /localhost|127\.0\.0\.1/.test(databaseUrl);
  const pool = new pg.Pool({
    connectionString: databaseUrl,
    max: 5,
    ssl: local ? false : { rejectUnauthorized: true },
  });
  return {
    kind: 'postgres',
    async init() { await pool.query(SCHEMA); },
    async get(companyId, userId) {
      const { rows } = await pool.query('SELECT * FROM installations WHERE company_id=$1 AND user_id=$2', [companyId, userId]);
      return fromRow(rows[0]);
    },
    async save(r) {
      await pool.query(
        `INSERT INTO installations (company_id,user_id,access_token,refresh_token,expires_at,api_domain,scope,updated_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,now())
         ON CONFLICT (company_id,user_id) DO UPDATE SET
           access_token=EXCLUDED.access_token, refresh_token=EXCLUDED.refresh_token,
           expires_at=EXCLUDED.expires_at, api_domain=EXCLUDED.api_domain, scope=EXCLUDED.scope, updated_at=now()`,
        [r.companyId, r.userId, r.accessToken, r.refreshToken, r.expiresAt, r.apiDomain, r.scope || '']
      );
    },
    async remove(companyId, userId) {
      await pool.query('DELETE FROM installations WHERE company_id=$1 AND user_id=$2', [companyId, userId]);
    },
    async close() { await pool.end(); },
  };
}

export { SCHEMA };
