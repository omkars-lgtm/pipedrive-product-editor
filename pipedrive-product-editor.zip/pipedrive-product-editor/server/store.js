import pg from 'pg';
import { decrypt, encrypt, parseKey } from './crypto.js';

// Stores one OAuth token set per (company, user). Each user acts with their OWN Pipedrive permissions.
const SCHEMA = `
CREATE TABLE IF NOT EXISTS installations (
  company_id    BIGINT NOT NULL,
  user_id       BIGINT NOT NULL,
  access_token  TEXT NOT NULL,
  refresh_token TEXT NOT NULL,
  expires_at    BIGINT NOT NULL,
  api_domain    TEXT NOT NULL,
  scope         TEXT,
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (company_id, user_id)
);
CREATE TABLE IF NOT EXISTS company_settings (
  company_id          BIGINT PRIMARY KEY,
  variant_field_codes JSONB NOT NULL,
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);`;

function fromRow(r) {
  if (!r) return null;
  return {
    companyId: Number(r.company_id),
    userId: Number(r.user_id),
    accessToken: r.access_token,
    refreshToken: r.refresh_token,
    expiresAt: Number(r.expires_at),
    apiDomain: r.api_domain,
    scope: r.scope || '',
  };
}

function createRawStore(databaseUrl) {
  if (!databaseUrl) {
    const mem = new Map();
    const settings = new Map();
    return {
      kind: 'memory',
      async init() {},
      async getSettings(companyId) { return settings.get(String(companyId)) || null; },
      async saveSettings(companyId, s) { settings.set(String(companyId), { ...s }); },
      async get(companyId, userId) { return mem.get(`${companyId}:${userId}`) || null; },
      async save(rec) { mem.set(`${rec.companyId}:${rec.userId}`, { ...rec }); },
      async remove(companyId, userId) { mem.delete(`${companyId}:${userId}`); },
      async close() {},
    };
  }
  const local = /localhost|127\.0\.0\.1/.test(databaseUrl);
  const pool = new pg.Pool({
    connectionString: databaseUrl,
    max: 5,
    ssl: local ? false : { rejectUnauthorized: true },
  });
  return {
    kind: 'postgres',
    async init() { await pool.query(SCHEMA); },
    async getSettings(companyId) {
      const { rows } = await pool.query('SELECT variant_field_codes FROM company_settings WHERE company_id=$1', [companyId]);
      return rows[0] ? { variantFieldCodes: rows[0].variant_field_codes } : null;
    },
    async saveSettings(companyId, s) {
      await pool.query(
        `INSERT INTO company_settings (company_id, variant_field_codes, updated_at) VALUES ($1, $2::jsonb, now())
         ON CONFLICT (company_id) DO UPDATE SET variant_field_codes=EXCLUDED.variant_field_codes, updated_at=now()`,
        [companyId, JSON.stringify(s.variantFieldCodes || [])]
      );
    },
    async get(companyId, userId) {
      const { rows } = await pool.query('SELECT * FROM installations WHERE company_id=$1 AND user_id=$2', [companyId, userId]);
      return fromRow(rows[0]);
    },
    async save(r) {
      await pool.query(
        `INSERT INTO installations (company_id,user_id,access_token,refresh_token,expires_at,api_domain,scope,updated_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,now())
         ON CONFLICT (company_id,user_id) DO UPDATE SET
           access_token=EXCLUDED.access_token, refresh_token=EXCLUDED.refresh_token,
           expires_at=EXCLUDED.expires_at, api_domain=EXCLUDED.api_domain, scope=EXCLUDED.scope, updated_at=now()`,
        [r.companyId, r.userId, r.accessToken, r.refreshToken, r.expiresAt, r.apiDomain, r.scope || '']
      );
    },
    async remove(companyId, userId) {
      await pool.query('DELETE FROM installations WHERE company_id=$1 AND user_id=$2', [companyId, userId]);
    },
    async close() { await pool.end(); },
  };
}

/** Wraps the raw store so access and refresh tokens are encrypted at rest when an encryption key is given. */
export function createStore(databaseUrl, { encryptionKey = '' } = {}) {
  const raw = createRawStore(databaseUrl);
  const key = parseKey(encryptionKey);
  const aad = (r) => `${r.companyId}:${r.userId}`;
  return {
    ...raw,
    encrypted: Boolean(key),
    async get(companyId, userId) {
      const r = await raw.get(companyId, userId);
      if (!r) return null;
      return { ...r, accessToken: decrypt(r.accessToken, key, aad(r)), refreshToken: decrypt(r.refreshToken, key, aad(r)) };
    },
    async save(r) {
      await raw.save({ ...r, accessToken: encrypt(r.accessToken, key, aad(r)), refreshToken: encrypt(r.refreshToken, key, aad(r)) });
    },
    /** Test helper: the stored (possibly encrypted) form. */
    async getRaw(companyId, userId) { return raw.get(companyId, userId); },
  };
}

export { SCHEMA };
