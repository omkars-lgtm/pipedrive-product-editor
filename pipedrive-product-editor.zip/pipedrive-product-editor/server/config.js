// All configuration comes from environment variables. Nothing secret is ever sent to the browser.
export function loadConfig(env = process.env) {
  const config = {
    port: Number(env.PORT || 3000),
    clientId: env.PIPEDRIVE_CLIENT_ID || '',
    clientSecret: env.PIPEDRIVE_CLIENT_SECRET || '',
    // Optional: only needed if you typed a separate JWT secret on the custom UI extension in Developer Hub.
    jwtSecret: env.PIPEDRIVE_JWT_SECRET || '',
    redirectUri: env.PIPEDRIVE_REDIRECT_URI || '',
    oauthBase: (env.PIPEDRIVE_OAUTH_BASE || 'https://oauth.pipedrive.com').replace(/\/$/, ''),
    databaseUrl: env.DATABASE_URL || '',
    // 64 hex characters (32 bytes). Encrypts OAuth tokens at rest. Generate: node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
    tokenEncryptionKey: env.TOKEN_ENCRYPTION_KEY || '',
    // Public value (not a secret): the ID of the Custom Modal extension from Developer Hub.
    modalActionId: env.MODAL_ACTION_ID || '',
    // Optional: default editable fields (before an admin chooses) are the product fields called Min and Max; these pin them by key.
    minFieldKey: env.PRODUCT_MIN_FIELD_KEY || '',
    maxFieldKey: env.PRODUCT_MAX_FIELD_KEY || '',
    frameAncestors: env.FRAME_ANCESTORS || 'https://*.pipedrive.com',
    // Safety net against a poisoned api_domain. Tests turn this off to talk to a local mock.
    allowAnyApiDomain: env.ALLOW_ANY_API_DOMAIN === 'true',
    clientDist: env.CLIENT_DIST || '',
  };
  return config;
}

export function configProblems(config) {
  const problems = [];
  if (!config.clientId) problems.push('PIPEDRIVE_CLIENT_ID is not set');
  if (!config.clientSecret) problems.push('PIPEDRIVE_CLIENT_SECRET is not set');
  if (!config.redirectUri) problems.push('PIPEDRIVE_REDIRECT_URI is not set');
  if (!config.databaseUrl) problems.push('DATABASE_URL is not set (tokens will be kept in memory and lost on every restart)');
  return problems;
}
