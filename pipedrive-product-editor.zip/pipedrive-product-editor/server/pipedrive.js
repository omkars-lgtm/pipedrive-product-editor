// Low-level Pipedrive client: OAuth code exchange, token refresh (with rotation) and authenticated requests.

export class PdError extends Error {
  constructor(status, message, code = 'PIPEDRIVE_ERROR') {
    super(message);
    this.status = status;
    this.code = code;
  }
}

const API_DOMAIN_RE = /^https:\/\/[a-z0-9-]+\.pipedrive\.com$/i;

export function createPipedrive({ config, store, fetchImpl = fetch }) {
  const refreshLocks = new Map();

  const basic = () =>
    'Basic ' + Buffer.from(`${config.clientId}:${config.clientSecret}`).toString('base64');

  function log(step, status, extra = '') {
    // Never log tokens, codes or secrets: only the step and the HTTP status.
    console.log(JSON.stringify({ at: new Date().toISOString(), step, status, extra }));
  }

  function checkApiDomain(domain) {
    if (config.allowAnyApiDomain) return domain.replace(/\/$/, '');
    if (!API_DOMAIN_RE.test(domain)) throw new PdError(502, 'Unexpected api_domain from Pipedrive', 'BAD_API_DOMAIN');
    return domain;
  }

  async function oauthPost(params, step) {
    const res = await fetchImpl(`${config.oauthBase}/oauth/token`, {
      method: 'POST',
      headers: {
        Authorization: basic(),
        'Content-Type': 'application/x-www-form-urlencoded',
        Accept: 'application/json',
      },
      body: new URLSearchParams(params),
    });
    let body = {};
    try { body = await res.json(); } catch { /* non-JSON body */ }
    log(step, res.status, res.ok ? '' : String(body.error || body.message || ''));
    if (!res.ok) {
      throw new PdError(res.status === 400 || res.status === 401 ? 401 : 502,
        body.message || body.error || 'OAuth request failed',
        body.error === 'invalid_grant' ? 'INVALID_GRANT' : 'OAUTH_FAILED');
    }
    return body;
  }

  async function exchangeCode(code) {
    return oauthPost({ grant_type: 'authorization_code', code, redirect_uri: config.redirectUri }, 'oauth.exchange');
  }

  async function refreshRecord(rec) {
    const key = `${rec.companyId}:${rec.userId}`;
    if (refreshLocks.has(key)) return refreshLocks.get(key);
    const p = (async () => {
      // Another request may have refreshed while we waited: re-read before using the (single-use) refresh token.
      const current = (await store.get(rec.companyId, rec.userId)) || rec;
      if (current.refreshToken !== rec.refreshToken && current.expiresAt > Date.now() + 60_000) return current;
      let t;
      try {
        t = await oauthPost({ grant_type: 'refresh_token', refresh_token: current.refreshToken }, 'oauth.refresh');
      } catch (e) {
        if (e.code === 'INVALID_GRANT' || e.status === 401) {
          throw new PdError(401, 'Authorization expired. Please re-authorize the app.', 'NOT_AUTHORIZED');
        }
        throw e;
      }
      const next = {
        ...current,
        accessToken: t.access_token,
        refreshToken: t.refresh_token || current.refreshToken,
        expiresAt: Date.now() + (Number(t.expires_in) || 3600) * 1000,
        apiDomain: checkApiDomain(t.api_domain || current.apiDomain),
        scope: t.scope || current.scope,
      };
      await store.save(next);
      return next;
    })().finally(() => refreshLocks.delete(key));
    refreshLocks.set(key, p);
    return p;
  }

  async function getSession(companyId, userId) {
    const rec = await store.get(companyId, userId);
    if (!rec) throw new PdError(401, 'This user has not authorized the app yet.', 'NOT_AUTHORIZED');
    if (rec.expiresAt - Date.now() < 60_000) return refreshRecord(rec);
    return rec;
  }

  /** Authenticated call. Refreshes once on 401. Returns the parsed JSON body. */
  async function request(session, method, path, { query, body } = {}) {
    let rec = session.rec;
    for (let attempt = 0; attempt < 2; attempt++) {
      const url = new URL(path, rec.apiDomain);
      for (const [k, v] of Object.entries(query || {})) {
        if (v !== undefined && v !== null && v !== '') url.searchParams.set(k, String(v));
      }
      const res = await fetchImpl(url, {
        method,
        headers: {
          Authorization: `Bearer ${rec.accessToken}`,
          Accept: 'application/json',
          ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
        },
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });
      let json = null;
      try { json = await res.json(); } catch { /* empty body */ }
      if (res.status === 401 && attempt === 0) {
        log('api.401', 401, `${method} ${path.split('?')[0]}`);
        rec = await refreshRecord(rec);
        session.rec = rec;
        continue;
      }
      if (!res.ok) {
        log('api.error', res.status, `${method} ${path.split('?')[0]}`);
        const msg = (json && (json.error || json.message)) || `Pipedrive returned HTTP ${res.status}`;
        if (res.status === 401) throw new PdError(401, 'Authorization expired. Please re-authorize the app.', 'NOT_AUTHORIZED');
        throw new PdError(res.status, typeof msg === 'string' ? msg : JSON.stringify(msg));
      }
      return json;
    }
    throw new PdError(401, 'Authorization expired. Please re-authorize the app.', 'NOT_AUTHORIZED');
  }

  /** Loads the user's stored tokens and returns a session whose call() handles refresh automatically. */
  async function openSession(companyId, userId) {
    const rec = await getSession(companyId, userId);
    const session = { rec };
    session.call = (method, path, opts) => request(session, method, path, opts);
    return session;
  }

  return { exchangeCode, refreshRecord, getSession, openSession, request, checkApiDomain, log };
}
