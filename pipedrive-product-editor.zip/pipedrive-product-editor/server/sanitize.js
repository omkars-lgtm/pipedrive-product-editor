// Minimal allow-list sanitiser for the rich-text Comments field (b, i, u, lists, links only).
const ALLOWED = new Set(['b', 'strong', 'i', 'em', 'u', 'ul', 'ol', 'li', 'br', 'p', 'div', 'a']);

export function sanitizeHtml(html) {
  return String(html ?? '')
    .replace(/<!--[\s\S]*?-->/g, '')
    .replace(/<(script|style)\b[\s\S]*?<\/\1\s*>/gi, '')
    .replace(/<\/?([a-zA-Z][a-zA-Z0-9]*)\b([^>]*)>/g, (m, tag, attrs) => {
      tag = tag.toLowerCase();
      if (!ALLOWED.has(tag)) return '';
      if (m.startsWith('</')) return `</${tag}>`;
      if (tag === 'a') {
        const h = /href\s*=\s*"(https?:\/\/[^"<>\s]*)"/i.exec(attrs) || /href\s*=\s*'(https?:\/\/[^'<>\s]*)'/i.exec(attrs);
        return h ? `<a href="${h[1]}" target="_blank" rel="noopener noreferrer">` : '<a>';
      }
      return `<${tag}>`;
    });
}

export function textLength(html) {
  return String(html ?? '')
    .replace(/<[^>]*>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&(amp|lt|gt|quot|#39);/g, 'x').length;
}
