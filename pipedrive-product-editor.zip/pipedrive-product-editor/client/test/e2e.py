"""Browser test against the real built app and a fake Pipedrive. Usage: python3 e2e.py <info.json> <outdir>"""
import json, sys, urllib.request
from playwright.sync_api import sync_playwright, expect

info = json.load(open(sys.argv[1]))
out = sys.argv[2]
APP, TOKEN, MIN, MAX = info["app"], info["token"], info["minKey"], info["maxKey"]
state = lambda: json.load(urllib.request.urlopen(info["state"]))
results = []

def check(name, cond, detail=""):
    results.append((name, bool(cond), detail))
    print(("PASS " if cond else "FAIL ") + name + (f"  -> {detail}" if detail and not cond else ""))

with sync_playwright() as p:
    browser = p.chromium.launch()
    page = browser.new_page(viewport={"width": 1280, "height": 900})
    errors = []
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.on("pageerror", lambda e: errors.append(str(e)))

    # 0. outside Pipedrive, no token
    page.goto(f"{APP}/modal?dealId=1")
    check("outside Pipedrive shows 'Open this from a deal'", page.get_by_text("Open this from a deal").is_visible())

    # 1. modal editor loads the deal
    page.goto(f"{APP}/modal?dealId=1&token={TOKEN}")
    page.wait_for_selector("text=Add products to deal - Moveer Deal")
    check("editor shows 2 existing rows", page.locator(".row").count() == 2)
    check("existing Min/Max shown from master product", page.locator('input[aria-label="Min"]').first.input_value() == "5" and page.locator('input[aria-label="Max"]').first.input_value() == "10")
    check("summary total is 30", "$30.00" in page.locator(".summary").inner_text())
    page.screenshot(path=f"{out}/1-loaded.png")

    # 1b. expanding a row shows every product field, custom ones included
    page.locator('button[aria-label="Expand row"]').first.click()
    det = page.locator(".details").first
    det.wait_for()
    dt = det.inner_text()
    check("expanded row lists built-in fields", all(x in dt for x in ["Product code", "TP1", "Unit", "pc", "Category", "Valves", "Description", "First product"]), dt)
    check("expanded row lists custom fields incl. OD and WT with option label", all(x in dt for x in ["OD", "60.3", "WT", "2.5 mm", "Min", "Max"]), dt)
    page.locator('input[aria-label="Max"]').first.fill("12")
    check("Min/Max in details follow what is typed", "12" in page.locator(".details").first.inner_text())
    page.locator('input[aria-label="Max"]').first.fill("10")
    page.screenshot(path=f"{out}/1b-expanded.png")

    # 2. pick an existing product from the dropdown, change Max -> variant
    page.get_by_role("button", name="+ Product").click()
    inp = page.locator('input[aria-label="Product"]')
    inp.fill("Rod")
    page.wait_for_selector(".dd-item")
    dd = page.locator(".dropdown").inner_text()
    check("dropdown shows name, code and Min/Max", "Rod Steel" in dd and "RS-1" in dd and "Min 2" in dd and "Max 8" in dd, dd)
    bb = page.locator(".dd-create").bounding_box()
    check("'Create new product' option is fully visible (not clipped)", bb and bb["y"] >= 0 and bb["y"] + bb["height"] <= 900 and page.locator(".table-wrap").evaluate("el => el.getBoundingClientRect().bottom") is not None and page.locator(".dd-create").evaluate("el => { const r = el.getBoundingClientRect(); const t = document.elementFromPoint(r.left + 5, r.top + r.height / 2); return el.contains(t) || t === el.parentElement; }"), str(bb))
    page.screenshot(path=f"{out}/2-dropdown.png")
    page.locator(".dd-item", has_text="Rod Steel").click()
    last = page.locator(".row").last
    check("selection fills price and tax", last.locator('input[aria-label="Price"]').input_value() == "30" and last.locator('input[aria-label="Tax %"]').input_value() == "5")
    check("selection fills Min/Max", last.locator('input[aria-label="Min"]').input_value() == "2" and last.locator('input[aria-label="Max"]').input_value() == "8")
    check("no variant hint before editing Min/Max", last.locator(".hint").count() == 0)
    last.locator('input[aria-label="Max"]').fill("99")
    check("variant hint appears after changing Max", "new product" in last.locator(".hint").inner_text())
    last.locator('input[aria-label="Quantity"]').fill("3")
    page.screenshot(path=f"{out}/3-variant.png")
    before = state()
    page.get_by_role("button", name="Save").click()
    page.wait_for_selector(".banner.success")
    msg = page.locator(".banner.success").inner_text()
    after = state()
    check("success message mentions the new product", "new product" in msg and "Rod Steel" in msg, msg)
    check("a NEW master product was created", len(after["products"]) == len(before["products"]) + 1)
    rod_orig = next(x for x in after["products"] if x["name"] == "Rod Steel" and x["custom_fields"].get(MAX) == 8)
    rod_new = next(x for x in after["products"] if x["name"] == "Rod Steel" and x["custom_fields"].get(MAX) == 99)
    check("original product untouched, new has Max 99", rod_orig and rod_new and rod_new["custom_fields"][MIN] == 2 and rod_new["code"] == "RS-1")
    check("deal now has 3 lines; new line uses the variant with qty 3", len(after["dealProducts"]) == 3 and any(d["product_id"] == rod_new["id"] and d["quantity"] == 3 for d in after["dealProducts"]))
    page.screenshot(path=f"{out}/4-saved.png")

    # 3. brand-new product typed
    page.get_by_role("button", name="+ Product").click()
    inp = page.locator('input[aria-label="Product"]')
    inp.fill("Brand New X")
    page.wait_for_selector(".dd-create")
    page.locator(".dd-create").click()
    check("new-product badge shown", page.locator(".new-badge").is_visible())
    last = page.locator(".row").last
    last.locator('input[aria-label="Min"]').fill("1.5")
    last.locator('input[aria-label="Max"]').fill("4")
    last.locator('input[aria-label="Price"]').fill("25")
    # rich text comment
    ed = last.locator('.rt-editor')
    ed.click(); ed.type("Hello")
    page.keyboard.press("Control+A")
    last.get_by_role("button", name="Bold").click()
    check("character counter updates", "1995 characters left" in last.inner_text(), last.inner_text())
    page.get_by_role("button", name="Save").click()
    page.wait_for_selector(".banner.success")
    s2 = state()
    bn = next((x for x in s2["products"] if x["name"] == "Brand New X"), None)
    check("brand-new product exists in master list with Min/Max and price", bn and bn["custom_fields"][MIN] == 1.5 and bn["custom_fields"][MAX] == 4 and bn["prices"][0]["price"] == 25, str(bn))
    bd = next((d for d in s2["dealProducts"] if bn and d["product_id"] == bn["id"]), None)
    check("rich-text comment saved as bold HTML", bd and "<b>Hello</b>" in bd["comments"], str(bd and bd["comments"]))

    # 4. validation blocks the save
    calls_before = len(state()["calls"])
    page.locator(".row").first.locator('input[aria-label="Quantity"]').fill("0")
    page.get_by_role("button", name="Save").click()
    page.wait_for_selector(".hint.err")
    check("validation message shown", "Quantity must be greater than 0" in page.locator(".hint.err").first.inner_text())
    check("validation made no API writes", not any(c.startswith(("POST", "PATCH", "DELETE")) for c in state()["calls"][calls_before:]))
    page.locator(".row").first.locator('input[aria-label="Quantity"]').fill("1")

    # 5. remove a row -> only the deal line is deleted
    n_prod = len(state()["products"])
    page.locator(".row").nth(1).get_by_role("button", name="Remove product").click()
    page.get_by_role("button", name="Save").click()
    page.wait_for_selector(".banner.success")
    s3 = state()
    check("removed deal line gone, master product kept", len(s3["products"]) == n_prod and not any(d["name"] == "Test Product 2" for d in s3["dealProducts"]))
    page.screenshot(path=f"{out}/5-final.png")

    # 6. panel
    page.goto(f"{APP}/?selectedIds=1&token={TOKEN}")
    page.wait_for_selector(".plist li")
    txt = page.locator(".plist").inner_text()
    check("panel lists products with Min/Max chips", "Test Product 1" in txt and "Min: 5" in txt and "Max: 10" in txt and "Brand New X" in txt, txt)
    page.screenshot(path=f"{out}/6-panel.png")
    page.get_by_role("button", name="Edit products").click()
    page.wait_for_selector("text=Add products to deal - Moveer Deal")
    check("Edit products falls back to the inline editor when no modal ID is configured", page.locator(".row").count() >= 2)
    page.get_by_role("button", name="Cancel").click()
    page.wait_for_selector(".plist li")
    check("Cancel returns to the panel list", True)

    # 7. a deal the user cannot see
    page.goto(f"{APP}/modal?dealId=999&token={TOKEN}")
    page.wait_for_selector(".banner.error")
    check("unknown deal shows an error with Retry", page.get_by_role("button", name="Retry").is_visible())

    # 8. narrow sidebar width
    page.set_viewport_size({"width": 360, "height": 800})
    page.goto(f"{APP}/?selectedIds=1&token={TOKEN}")
    page.wait_for_selector(".plist li")
    check("panel has no horizontal overflow at 360px", page.evaluate("document.documentElement.scrollWidth <= window.innerWidth"))
    page.screenshot(path=f"{out}/7-panel-narrow.png")

    check("no browser console errors", not [e for e in errors if "404" not in e and "401" not in e], str(errors))
    browser.close()

failed = [r for r in results if not r[1]]
print(f"\n{len(results) - len(failed)}/{len(results)} browser checks passed")
sys.exit(1 if failed else 0)
