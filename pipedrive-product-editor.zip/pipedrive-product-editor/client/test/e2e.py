"""Browser test against the real built app and a fake Pipedrive. Usage: python3 e2e.py <info.json> <outdir>"""
import json, re, sys, urllib.request
from playwright.sync_api import sync_playwright, expect

info = json.load(open(sys.argv[1]))
out = sys.argv[2]
APP, TOKEN, MIN, MAX = info["app"], info["token"], info["minKey"], info["maxKey"]
state = lambda: json.load(urllib.request.urlopen(info["state"]))
results = []

def check(name, cond, detail=""):
    results.append((name, bool(cond), detail))
    print(("PASS " if cond else "FAIL ") + name + (f"  -> {detail}" if detail and not cond else ""))

with sync_playwright() as p:
    browser = p.chromium.launch()
    page = browser.new_page(viewport={"width": 1280, "height": 900})
    errors = []
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.on("pageerror", lambda e: errors.append(str(e)))

    # 0. outside Pipedrive, no token
    page.goto(f"{APP}/modal?dealId=1")
    check("outside Pipedrive shows 'Open this from a deal'", page.get_by_text("Open this from a deal").is_visible())

    # 1. modal editor loads the deal
    page.goto(f"{APP}/modal?dealId=1&token={TOKEN}")
    page.wait_for_selector("text=Add products to deal - Moveer Deal")
    check("editor shows 2 existing rows", page.locator(".row").count() == 2)
    check("summary total is 30", "$30.00" in page.locator(".summary").inner_text())
    page.screenshot(path=f"{out}/1-loaded.png")

    # 1b. expanding a row shows every product field, custom ones included
    page.locator('button[aria-label="Expand row"]').first.click()
    det = page.locator(".details").first
    det.wait_for()
    dt = det.inner_text()
    check("expanded row lists built-in fields", all(x in dt for x in ["Product code", "TP1", "Unit", "pc", "Category", "Valves", "Description", "First product"]), dt)
    check("expanded row lists custom fields incl. OD and WT with option label", all(x in dt for x in ["OD", "60.3", "WT", "2.5 mm"]), dt)
    check("editable fields (Min/Max) are inputs, not read-only text", page.locator('input[aria-label="Min"]').first.input_value() == "5" and page.locator('input[aria-label="Max"]').first.input_value() == "10" and "Min" not in dt)
    page.locator('input[aria-label="Max"]').first.fill("12")
    check("changing an editable field shows the name-suffix choice, unticked by default", page.locator(".suffix-pick input").count() == 1 and not page.locator(".suffix-pick input").first.is_checked())
    page.locator('input[aria-label="Max"]').first.fill("10")
    page.screenshot(path=f"{out}/1b-expanded.png")

    # 2. pick an existing product from the dropdown, change Max -> variant
    page.get_by_role("button", name="+ Product").click()
    inp = page.locator('input[aria-label="Product"]')
    inp.fill("Rod")
    page.wait_for_selector(".dd-item")
    dd = page.locator(".dropdown").inner_text()
    check("dropdown shows name, code and Min/Max", "Rod Steel" in dd and "RS-1" in dd and "Min 2" in dd and "Max 8" in dd, dd)
    bb = page.locator(".dd-create").bounding_box()
    check("'Create new product' option is fully visible (not clipped)", bb and bb["y"] >= 0 and bb["y"] + bb["height"] <= 900 and page.locator(".table-wrap").evaluate("el => el.getBoundingClientRect().bottom") is not None and page.locator(".dd-create").evaluate("el => { const r = el.getBoundingClientRect(); const t = document.elementFromPoint(r.left + 5, r.top + r.height / 2); return el.contains(t) || t === el.parentElement; }"), str(bb))
    page.screenshot(path=f"{out}/2-dropdown.png")
    page.locator(".dd-item", has_text="Rod Steel").click()
    last = page.locator(".row").last
    check("selection fills price and tax", last.locator('input[aria-label="Price"]').input_value() == "30" and last.locator('input[aria-label="Tax %"]').input_value() == "5")
    check("selection fills Min/Max", last.locator('input[aria-label="Min"]').input_value() == "2" and last.locator('input[aria-label="Max"]').input_value() == "8")
    check("no variant hint before editing Min/Max", last.locator(".hint").count() == 0)
    last.locator('input[aria-label="Max"]').fill("99")
    check("variant hint appears after changing Max", "new product" in last.locator(".hint").inner_text())
    last.locator('input[aria-label="Quantity"]').fill("3")
    page.screenshot(path=f"{out}/3-variant.png")
    before = state()
    page.get_by_role("button", name="Save").click()
    page.wait_for_selector(".banner.success")
    msg = page.locator(".banner.success").inner_text()
    after = state()
    check("success message mentions the new product", "new product" in msg and "Rod Steel" in msg, msg)
    check("a NEW master product was created", len(after["products"]) == len(before["products"]) + 1)
    rod_orig = next(x for x in after["products"] if x["name"] == "Rod Steel" and x["custom_fields"].get(MAX) == 8)
    rod_new = next(x for x in after["products"] if x["name"] == "Rod Steel" and x["custom_fields"].get(MAX) == 99)
    check("original product untouched, new has Max 99", rod_orig and rod_new and rod_new["custom_fields"][MIN] == 2 and rod_new["code"] == "RS-1")
    check("deal now has 3 lines; new line uses the variant with qty 3", len(after["dealProducts"]) == 3 and any(d["product_id"] == rod_new["id"] and d["quantity"] == 3 for d in after["dealProducts"]))
    page.screenshot(path=f"{out}/4-saved.png")

    # 2b. same product, change Min and choose to add it to the name
    page.get_by_role("button", name="+ Product").click()
    page.locator('input[aria-label="Product"]').fill("Rod")
    page.wait_for_selector(".dd-item")
    page.locator(".dd-item", has_text="Rod Steel").first.click()
    last = page.locator(".row").last
    last.locator('input[aria-label="Min"]').fill("3")
    last.get_by_label("Add Min to product name").check()
    check("name preview shows the suffix", "Rod Steel_Min:3" in last.locator(".variant-hint").inner_text(), last.locator(".variant-hint").inner_text())
    page.get_by_role("button", name="Save").click()
    page.wait_for_selector(".banner.success")
    check("product created with the chosen name suffix", any(x["name"] == "Rod Steel_Min:3" for x in state()["products"]))

    # 3. brand-new product typed
    page.get_by_role("button", name="+ Product").click()
    inp = page.locator('input[aria-label="Product"]')
    inp.fill("Brand New X")
    page.wait_for_selector(".dd-create")
    page.locator(".dd-create").click()
    check("new-product badge shown", page.locator(".new-badge").is_visible())
    last = page.locator(".row").last
    last.locator('input[aria-label="Min"]').fill("1.5")
    last.locator('input[aria-label="Max"]').fill("4")
    last.locator('input[aria-label="Price"]').fill("25")
    # rich text comment
    ed = last.locator('.rt-editor')
    ed.click(); ed.type("Hello")
    page.keyboard.press("Control+A")
    last.get_by_role("button", name="Bold").click()
    check("character counter updates", "1995 characters left" in last.inner_text(), last.inner_text())
    page.get_by_role("button", name="Save").click()
    page.wait_for_selector(".banner.success")
    s2 = state()
    bn = next((x for x in s2["products"] if x["name"] == "Brand New X"), None)
    check("brand-new product exists in master list with Min/Max and price", bn and bn["custom_fields"][MIN] == 1.5 and bn["custom_fields"][MAX] == 4 and bn["prices"][0]["price"] == 25, str(bn))
    bd = next((d for d in s2["dealProducts"] if bn and d["product_id"] == bn["id"]), None)
    check("rich-text comment saved as bold HTML", bd and "<b>Hello</b>" in bd["comments"], str(bd and bd["comments"]))

    # 4. validation blocks the save
    calls_before = len(state()["calls"])
    page.locator(".row").first.locator('input[aria-label="Quantity"]').fill("0")
    page.get_by_role("button", name="Save").click()
    page.wait_for_selector(".hint.err")
    check("validation message shown", "Quantity must be greater than 0" in page.locator(".hint.err").first.inner_text())
    check("validation made no API writes", not any(c.startswith(("POST", "PATCH", "DELETE")) for c in state()["calls"][calls_before:]))
    page.locator(".row").first.locator('input[aria-label="Quantity"]').fill("1")

    # 5. remove a row -> only the deal line is deleted
    n_prod = len(state()["products"])
    page.locator(".row").nth(1).get_by_role("button", name="Remove product").click()
    page.get_by_role("button", name="Save").click()
    page.wait_for_selector(".banner.success")
    s3 = state()
    check("removed deal line gone, master product kept", len(s3["products"]) == n_prod and not any(d["name"] == "Test Product 2" for d in s3["dealProducts"]))
    page.screenshot(path=f"{out}/5-final.png")

    # 6. panel
    page.goto(f"{APP}/?selectedIds=1&token={TOKEN}")
    page.wait_for_selector(".plist li")
    txt = page.locator(".plist").inner_text()
    check("panel lists products with Min/Max chips", "Test Product 1" in txt and "Min: 5" in txt and "Max: 10" in txt and "Brand New X" in txt, txt)
    page.screenshot(path=f"{out}/6-panel.png")
    page.get_by_role("button", name="Edit products").click()
    page.wait_for_selector("text=Add products to deal - Moveer Deal")
    check("Edit products falls back to the inline editor when no modal ID is configured", page.locator(".row").count() >= 2)
    page.get_by_role("button", name="Cancel").click()
    page.wait_for_selector(".plist li")
    check("Cancel returns to the panel list", True)

    # 6b. admin settings: choose other fields
    page.goto(f"{APP}/settings?token={TOKEN}")
    page.wait_for_selector(".field-list")
    names = page.locator(".field-list li").all_inner_texts()
    check("settings lists custom fields with their type", any("OD" in n for n in names) and any("WT" in n and "Dropdown" in n for n in names) and not any(n.startswith("Name") for n in names), str(names))
    page.get_by_label("OD", exact=True).check(); page.get_by_label("WT", exact=True).check()
    page.get_by_label("Min", exact=True).uncheck(); page.get_by_label("Max", exact=True).uncheck()
    page.get_by_role("button", name="Save").click()
    page.wait_for_selector(".banner.success")
    page.goto(f"{APP}/modal?dealId=1&token={TOKEN}")
    page.wait_for_selector(".row")
    page.locator('button[aria-label="Expand row"]').first.click()
    check("editor now offers OD and WT instead of Min/Max", page.locator('input[aria-label="OD"]').count() == 1 and page.locator('[role=radiogroup][aria-label="WT"]').count() == 1 and page.locator('input[aria-label="Min"]').count() == 0)
    page.screenshot(path=f"{out}/8-custom-fields.png")
    page.goto(f"{APP}/settings?token={TOKEN}")
    page.wait_for_selector(".field-list")
    page.get_by_label("OD", exact=True).uncheck(); page.get_by_label("WT", exact=True).uncheck()
    page.get_by_label("Min", exact=True).check(); page.get_by_label("Max", exact=True).check()
    page.get_by_role("button", name="Save").click()
    page.wait_for_selector(".banner.success")

    # 7. a deal the user cannot see
    page.goto(f"{APP}/modal?dealId=999&token={TOKEN}")
    page.wait_for_selector(".banner.error")
    check("unknown deal shows an error with Retry", page.get_by_role("button", name="Retry").is_visible())

    # 8. narrow sidebar width
    page.set_viewport_size({"width": 360, "height": 800})
    page.goto(f"{APP}/?selectedIds=1&token={TOKEN}")
    page.wait_for_selector(".plist li")
    check("panel has no horizontal overflow at 360px", page.evaluate("document.documentElement.scrollWidth <= window.innerWidth"))
    page.screenshot(path=f"{out}/7-panel-narrow.png")

    page.set_viewport_size({"width": 480, "height": 800})
    page.goto(f"{APP}/modal?dealId=1&token={TOKEN}")
    page.wait_for_selector(".row")
    page.locator('button[aria-label="Expand row"]').first.click()
    left = page.locator(".expanded").first.evaluate("el => el.getBoundingClientRect().left")
    check("expanded details stay visible in a narrow panel", left >= 0, str(left))

    # 9. all field types, Pipedrive-style inputs
    import urllib.request as ur
    def call(m, path, body=None):
        r = ur.Request(APP + path, method=m, data=json.dumps(body).encode() if body else None, headers={"x-pd-token": TOKEN, "Content-Type": "application/json"})
        return json.load(ur.urlopen(r))
    cands = {c["name"]: c["code"] for c in call("GET", "/api/settings")["candidates"]}
    call("PUT", "/api/settings", {"variantFieldCodes": [cands[n] for n in ["Tags", "Grade", "WT", "Cost", "DR", "TR", "Open", "Address", "User", "Org", "Person", "Brand"]]})
    page.set_viewport_size({"width": 1280, "height": 1000})
    page.goto(f"{APP}/modal?dealId=1&token={TOKEN}")
    page.wait_for_selector(".row")
    page.locator('button[aria-label="Expand row"]').first.click()
    ex = page.locator(".expanded").first
    check("single option with few short options is a segmented control", ex.locator('[role=radiogroup][aria-label="WT"]').count() == 1)
    check("single option with many options is a searchable dropdown", ex.locator('button[aria-label="Grade"]').count() == 1)
    ex.locator('button[aria-label="Grade"]').click()
    page.get_by_placeholder("Search…").fill("gam")
    page.locator(".dd-item", has_text="Gamma").click()
    check("dropdown pick shows the label", "Gamma" in ex.locator('button[aria-label="Grade"]').inner_text())
    ex.locator('[aria-label="Tags"]').click()
    page.locator(".check-row", has_text="Red").locator("input").check()
    page.locator(".check-row", has_text="Blue").locator("input").check()
    page.keyboard.press("Escape"); page.mouse.click(5, 5)
    check("multi-select shows chips", ex.locator(".tag").count() == 2, ex.locator('[aria-label="Tags"]').inner_text())
    ex.locator('[role=radiogroup][aria-label="WT"] button', has_text="3 mm").click()
    ex.locator('input[aria-label="Cost"]').fill("12.5")
    check("money shows currency names", "US Dollar" in ex.locator('select[aria-label="Cost currency"] option:checked').inner_text())
    ex.locator('input[aria-label="DR from"]').fill("2026-03-01"); ex.locator('input[aria-label="DR to"]').fill("2026-03-15")
    ex.locator('input[aria-label="TR from"]').fill("09:00"); ex.locator('input[aria-label="TR to"]').fill("17:30")
    ex.locator('input[aria-label="Open"]').fill("08:15")
    ex.locator('input[aria-label="Address"]').fill("bor")
    page.locator(".dd-item", has_text="Borivali, Mumbai, Maharashtra, India").wait_for()
    check("address field recommends places", page.locator(".dd-item.sug").count() == 2)
    page.locator(".dd-item", has_text="Borivali").click()
    check("picking an address fills it", ex.locator('input[aria-label="Address"]').input_value() == "Borivali, Mumbai, Maharashtra, India")
    ex.locator('input[aria-label="Brand"]').fill("aut")
    page.locator(".dd-item", has_text="auto1").wait_for()
    page.locator(".dd-item", has_text="auto1").click()
    check("autocomplete field recommends earlier values", ex.locator('input[aria-label="Brand"]').input_value() == "auto1")
    ex.locator('input[aria-label="Org"]').fill("acm")
    page.locator(".dd-item", has_text="Acme Corp").click()
    ex.locator('input[aria-label="Person"]').fill("Zed Newperson")
    page.locator(".dd-add", has_text="as new contact").click()
    check("new person can be added from the picker", "Zed Newperson" in ex.locator('button[aria-label="Person"]').inner_text() and ex.locator(".badge-new").count() == 1)
    ex.locator('input[aria-label="User"]').click()
    page.locator(".dd-item", has_text="Ben Lee").click()
    check("picked organization is shown by name", "Acme Corp" in ex.locator('button[aria-label="Org"]').inner_text())
    page.screenshot(path=f"{out}/9-all-fields.png", full_page=True)
    page.locator(".suffix-pick label", has_text=re.compile(r"^Org:")).locator("input").check()
    page.locator(".suffix-pick label", has_text=re.compile(r"^DR:")).locator("input").check()
    page.get_by_role("button", name="Save").click()
    page.wait_for_selector(".banner.success")
    made = [p for p in state()["products"] if p["name"].startswith("Test Product 1_")]
    check("variant created with readable suffix", len(made) == 1 and made[0]["name"] == "Test Product 1_DR:2026-03-01..2026-03-15_Org:Acme Corp", str([p["name"] for p in made]))
    cf = made[0]["custom_fields"] if made else {}
    check("all new field types written in Pipedrive's object formats",
          cf.get(cands["Open"]) == {"value": "08:15"} and cf.get(cands["TR"]) == {"value": "09:00", "until": "17:30"}
          and cf.get(cands["DR"]) == {"value": "2026-03-01", "until": "2026-03-15"} and cf.get(cands["Org"]) == {"value": 31}
          and cf.get(cands["Cost"]) == {"value": 12.5, "currency": "USD"} and cf.get(cands["Address"]) == {"value": "Borivali, Mumbai, Maharashtra, India"} and isinstance(cf.get(cands["Person"]), dict) and cf[cands["Person"]]["value"] >= 900 and cf.get(cands["Tags"]) == [21, 23], str(cf))

    check("no browser console errors", not [e for e in errors if "404" not in e and "401" not in e], str(errors))
    browser.close()

failed = [r for r in results if not r[1]]
print(f"\n{len(results) - len(failed)}/{len(results)} browser checks passed")
sys.exit(1 if failed else 0)
