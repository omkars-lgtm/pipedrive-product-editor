export const num = (v) => {
  if (v === '' || v === null || v === undefined) return 0;
  const n = Number(String(v).replace(/,/g, ''));
  return Number.isFinite(n) ? n : 0;
};

/** Mirrors Pipedrive's native modal: price x quantity - discount, with tax inclusive / exclusive / none. */
export function lineTotals(l, taxMethod) {
  if (!l.isEnabled) return { amount: 0, excl: 0, tax: 0, total: 0 };
  const base = num(l.itemPrice) * num(l.quantity);
  const disc = l.discountType === 'percentage' ? (base * num(l.discount)) / 100 : num(l.discount);
  const net = Math.max(0, base - disc);
  const rate = num(l.tax) / 100;
  if (taxMethod === 'inclusive') { const excl = net / (1 + rate); return { amount: net, excl, tax: net - excl, total: net }; }
  if (taxMethod === 'exclusive') { const t = net * rate; return { amount: net, excl: net, tax: t, total: net + t }; }
  return { amount: net, excl: net, tax: 0, total: net };
}

export function sumTotals(lines, taxMethod) {
  return lines.reduce((a, l) => {
    const t = lineTotals(l, taxMethod);
    return { excl: a.excl + t.excl, tax: a.tax + t.tax, total: a.total + t.total };
  }, { excl: 0, tax: 0, total: 0 });
}

export function money(v, currency = 'USD') {
  try { return new Intl.NumberFormat(undefined, { style: 'currency', currency }).format(v); }
  catch { return `${Number(v).toFixed(2)} ${currency}`; }
}

export const plain = (html) => String(html || '').replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
