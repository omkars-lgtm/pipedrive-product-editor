import React, { useEffect, useRef, useState } from 'react';

const LIMIT = 2000;
const textLen = (html) => html.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').replace(/&(amp|lt|gt|quot|#39);/g, 'x').length;

/** Small rich-text box: bold, italic, underline, lists, link, clear. Uncontrolled after mount for stable caret. */
export default function RichText({ value, onChange, label = 'Comments' }) {
  const ref = useRef(null);
  const saved = useRef(null);
  const [linkOpen, setLinkOpen] = useState(false);
  const [url, setUrl] = useState('https://');
  const [len, setLen] = useState(textLen(value || ''));

  useEffect(() => {
    if (ref.current) ref.current.innerHTML = value || '';
    setLen(textLen(value || ''));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const emit = () => {
    const html = ref.current.innerHTML;
    setLen(textLen(html));
    onChange(html === '<br>' ? '' : html);
  };
  const cmd = (name, arg) => {
    ref.current.focus();
    document.execCommand(name, false, arg);
    emit();
  };
  const keepSelection = () => {
    const sel = window.getSelection();
    if (sel && sel.rangeCount && ref.current.contains(sel.anchorNode)) saved.current = sel.getRangeAt(0).cloneRange();
  };
  const applyLink = () => {
    const sel = window.getSelection();
    ref.current.focus();
    if (saved.current) { sel.removeAllRanges(); sel.addRange(saved.current); }
    if (/^https?:\/\//i.test(url)) cmd('createLink', url);
    setLinkOpen(false);
    setUrl('https://');
  };
  const btn = (title, content, onClick) => (
    <button type="button" className="rt-btn" title={title} aria-label={title}
      onMouseDown={(e) => e.preventDefault()} onClick={onClick}>{content}</button>
  );

  return (
    <div className="rt">
      <div className="rt-label">{label}</div>
      <div className="rt-box">
        <div className="rt-editor" ref={ref} contentEditable suppressContentEditableWarning role="textbox" aria-label={label}
          aria-multiline="true" onInput={emit} onBlur={keepSelection} onKeyUp={keepSelection} onMouseUp={keepSelection} />
        <div className="rt-bar">
          {btn('Bold', <b>B</b>, () => cmd('bold'))}
          {btn('Italic', <i>I</i>, () => cmd('italic'))}
          {btn('Underline', <u>U</u>, () => cmd('underline'))}
          {btn('Numbered list', '1.', () => cmd('insertOrderedList'))}
          {btn('Bulleted list', '•', () => cmd('insertUnorderedList'))}
          {btn('Link', 'Link', () => { keepSelection(); setLinkOpen((o) => !o); })}
          {btn('Clear formatting', 'Clear', () => cmd('removeFormat'))}
          <span className={`rt-count ${len > LIMIT ? 'over' : ''}`}>{LIMIT - len} characters left</span>
        </div>
        {linkOpen && (
          <div className="rt-link">
            <input value={url} onChange={(e) => setUrl(e.target.value)} aria-label="Link URL" />
            <button type="button" className="btn small" onClick={applyLink}>Add link</button>
          </div>
        )}
      </div>
    </div>
  );
}
