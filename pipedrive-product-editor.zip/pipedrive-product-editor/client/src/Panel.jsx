import React, { useCallback, useEffect, useRef, useState } from 'react';
import { api, getConfig } from './api.js';
import { embedded, getDealId, onModalClosed, openEditorModal, resizeTo, standaloneToken } from './pd.js';
import { money, plain } from './calc.js';
import Editor from './Editor.jsx';
import Settings from './Settings.jsx';
import { formFromServer, showValue } from './fields.js';
import { AuthCard, Banner, OpenFromDeal, Spinner } from './Shared.jsx';

export default function Panel() {
  const dealId = getDealId();
  const [phase, setPhase] = useState('loading');
  const [data, setData] = useState(null);
  const [err, setErr] = useState(null);
  const [editing, setEditing] = useState(false);
  const [note, setNote] = useState(null);
  const [showSettings, setShowSettings] = useState(false);
  const root = useRef(null);

  const load = useCallback(async () => {
    setPhase('loading'); setErr(null);
    const r = await api('GET', `/api/deals/${dealId}/bootstrap`);
    if (!r.ok) { setErr(r.json || { error: 'Could not load products.' }); setPhase('error'); return; }
    setData(r.json); setPhase('ready');
  }, [dealId]);

  useEffect(() => { if (dealId) load(); }, [dealId, load]);
  useEffect(() => {
    let off = () => {};
    onModalClosed(() => load()).then((fn) => { off = fn; }).catch(() => {});
    return () => off();
  }, [load]);
  useEffect(() => {
    if (!root.current || editing) return undefined;
    const ro = new ResizeObserver(() => resizeTo(root.current.scrollHeight + 8));
    ro.observe(root.current);
    return () => ro.disconnect();
  }, [editing, phase]);

  if (!dealId || (!embedded && !standaloneToken)) return <div className="panel" ref={root}><OpenFromDeal /></div>;

  async function openEditor() {
    setNote(null);
    const cfg = await getConfig();
    if (cfg.modalActionId && embedded) {
      try { await openEditorModal(cfg.modalActionId, dealId); return; }
      catch { setNote('The editor popup could not be opened, so it is shown here instead. Check the Custom modal extension ID in Developer Hub.'); }
    }
    setEditing(true);
  }

  if (showSettings) {
    return <div className="panel" ref={root}><Settings onDone={() => { setShowSettings(false); load(); }} /></div>;
  }
  if (editing) {
    return <div className="panel" ref={root}><Editor dealId={dealId} mode="inline" onDone={(m) => { setEditing(false); if (m) setNote(m); load(); }} /></div>;
  }
  return (
    <div className="panel" ref={root}>
      <div className="panel-head">
        <strong>Products{data ? ` (${data.lines.length})` : ''}</strong>
        <button type="button" className="btn small primary" onClick={openEditor} disabled={phase !== 'ready'}>Edit products</button>
      </div>
      {note && <Banner kind="info" onClose={() => setNote(null)}>{note}</Banner>}
      {phase === 'loading' && <Spinner label="Loading products…" />}
      {phase === 'error' && (err?.code === 'NOT_AUTHORIZED'
        ? <AuthCard authorizeUrl={err.authorizeUrl} onRetry={load} />
        : <Banner kind="error">{err?.error} <button type="button" className="btn small" onClick={load}>Retry</button></Banner>)}
      {phase === 'ready' && (
        <>
          {data.fieldsMessage && <Banner kind="info">{data.fieldsMessage}</Banner>}
          {data.lines.length === 0 && <p className="muted">No products on this deal.</p>}
          <ul className="plist">
            {data.lines.map((l) => (
              <li key={l.dealProductId} className={l.isEnabled ? '' : 'off'}>
                <div className="pl-top"><span className="pl-name">{l.name}</span><span>{money(l.itemPrice * l.quantity, data.deal.currency)}</span></div>
                <div className="muted">{l.quantity} × {money(l.itemPrice, data.deal.currency)}{l.isEnabled ? '' : ' · disabled'}</div>
                {data.variantFields.length > 0 && (
                  <div className="chips">
                    {data.variantFields.map((f) => {
                      const v = showValue(f, formFromServer(l.values, data.variantFields)[f.code]);
                      return <span className="chip" key={f.code}>{f.name}: {v || '–'}</span>;
                    })}
                  </div>
                )}
                {plain(l.comments) && <div className="muted clip">{plain(l.comments)}</div>}
              </li>
            ))}
          </ul>
          <p className="muted small-link"><button type="button" className="link" onClick={() => setShowSettings(true)}>Editable fields (admins)</button></p>
        </>
      )}
    </div>
  );
}
