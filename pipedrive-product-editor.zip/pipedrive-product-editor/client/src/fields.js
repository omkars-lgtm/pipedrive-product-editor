// Helpers for the admin-chosen editable product fields (types: text, autocomplete, phone, number, time, monetary, dropdown, multi-select, date).
const optLabel = (f, id) => f.options?.find((o) => String(o.id) === String(id))?.label ?? String(id);

/** Server value -> form value (strings; arrays of strings for dropdown-multi). */
export const toForm = (v, f, defCur = '') => {
  if (f.type === 'daterange' || f.type === 'timerange') {
    const cut = (x) => (x ? (f.type === 'timerange' ? String(x).slice(0, 5) : String(x)) : '');
    return { from: cut(v?.from), to: cut(v?.to) };
  }
  if (f.type === 'user' || f.type === 'org' || f.type === 'people') return v && v.id ? { id: v.id, name: v.name || null } : null;
  if (f.type === 'monetary') return v && typeof v === 'object' ? { value: String(v.value), currency: v.currency || defCur } : { value: '', currency: defCur };
  if (f.type === 'time') return v ? String(v).slice(0, 5) : '';
  if (f.type === 'set') return Array.isArray(v) ? v.map(String) : [];
  return v === null || v === undefined ? '' : String(v);
};
export const blankForm = (fields, defCur = '') => Object.fromEntries(fields.map((f) => [f.code, toForm(null, f, defCur)]));
export const formFromServer = (values, fields, defCur = '') => Object.fromEntries(fields.map((f) => [f.code, toForm(values?.[f.code], f, defCur)]));

const normForm = (f, v) => {
  if (f.type === 'daterange' || f.type === 'timerange') return v?.from || v?.to ? `${v.from || ''}|${v.to || ''}` : '';
  if (f.type === 'user' || f.type === 'org' || f.type === 'people') return v?.id ? String(v.id) : '';
  if (f.type === 'monetary') {
    const a = String(v?.value ?? '').trim();
    return a === '' ? '' : `${Number(a.replace(/,/g, ''))} ${String(v?.currency ?? '').toUpperCase()}`;
  }
  if (f.type === 'set') return [...(v || [])].map(String).sort().join(',');
  const s = String(v ?? '').trim();
  if (s === '') return '';
  return f.type === 'double' || f.type === 'int' ? String(Number(s.replace(/,/g, ''))) : s;
};
export const sameForm = (f, a, b) => normForm(f, a) === normForm(f, b);

export const changedFields = (line, fields) => (line.productId
  ? fields.filter((f) => !sameForm(f, line.values?.[f.code], line.baseValues?.[f.code])) : []);

/** Human-readable value of a form value (option labels for dropdowns). */
export const showValue = (f, v) => {
  if (f.type === 'daterange' || f.type === 'timerange') return v?.from || v?.to ? `${v.from || ''}..${v.to || ''}` : '';
  if (f.type === 'user' || f.type === 'org' || f.type === 'people') return v?.id ? (v.name || `#${v.id}`) : '';
  if (f.type === 'monetary') return String(v?.value ?? '').trim() === '' ? '' : `${String(v.value).trim()} ${v.currency || ''}`.trim();
  if (f.type === 'set') return (v || []).map((id) => optLabel(f, id)).join(', ');
  const s = String(v ?? '').trim();
  return f.type === 'enum' && s ? optLabel(f, s) : s;
};

/** Mirrors the server's naming: Pipe_OD:70_WT:3 mm */
export const suffixPreview = (baseName, fields, line) => {
  const chosen = changedFields(line, fields).filter((f) => (line.suffixCodes || []).includes(f.code));
  return chosen.length ? `${baseName}_${chosen.map((f) => `${f.name}:${showValue(f, line.values[f.code]) || 'none'}`).join('_')}` : baseName;
};

export function validateField(f, v) {
  if (f.type === 'daterange' || f.type === 'timerange') {
    if (!v?.from && !v?.to) return null;
    if (!v.from || !v.to) return `${f.name} needs both a start and an end.`;
    return v.from > v.to ? `${f.name}: the start must not be after the end.` : null;
  }
  if (f.type === 'user' || f.type === 'org' || f.type === 'people') return null;
  if (f.type === 'monetary') {
    const a = String(v?.value ?? '').trim();
    if (a === '') return null;
    if (!Number.isFinite(Number(a.replace(/,/g, '')))) return `${f.name} must be a number.`;
    return v?.currency ? null : `${f.name} needs a currency.`;
  }
  if (f.type === 'set') return null;
  const s = String(v ?? '').trim();
  if (s === '') return null;
  if (f.type === 'double' || f.type === 'int') {
    const n = Number(s.replace(/,/g, ''));
    if (!Number.isFinite(n)) return `${f.name} must be a number.`;
    if (f.type === 'int' && !Number.isInteger(n)) return `${f.name} must be a whole number.`;
  }
  if ((f.type === 'varchar' || f.type === 'varchar_auto' || f.type === 'phone') && s.length > 255) return `${f.name} is too long.`;
  if (f.type === 'time' && !/^\d{2}:\d{2}(:\d{2})?$/.test(s)) return `${f.name} must be a time.`;
  if (f.type === 'date' && !/^\d{4}-\d{2}-\d{2}$/.test(s)) return `${f.name} must be a date.`;
  return null;
}
