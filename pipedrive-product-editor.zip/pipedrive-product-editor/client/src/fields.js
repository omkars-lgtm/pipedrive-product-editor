// Helpers for the admin-chosen editable product fields (types: varchar, text, double, int, enum, set, date).
const optLabel = (f, id) => f.options?.find((o) => String(o.id) === String(id))?.label ?? String(id);

/** Server value -> form value (strings; arrays of strings for dropdown-multi). */
export const toForm = (v, f) => {
  if (f.type === 'set') return Array.isArray(v) ? v.map(String) : [];
  return v === null || v === undefined ? '' : String(v);
};
export const blankForm = (fields) => Object.fromEntries(fields.map((f) => [f.code, toForm(null, f)]));
export const formFromServer = (values, fields) => Object.fromEntries(fields.map((f) => [f.code, toForm(values?.[f.code], f)]));

const normForm = (f, v) => {
  if (f.type === 'set') return [...(v || [])].map(String).sort().join(',');
  const s = String(v ?? '').trim();
  if (s === '') return '';
  return f.type === 'double' || f.type === 'int' ? String(Number(s.replace(/,/g, ''))) : s;
};
export const sameForm = (f, a, b) => normForm(f, a) === normForm(f, b);

export const changedFields = (line, fields) => (line.productId
  ? fields.filter((f) => !sameForm(f, line.values?.[f.code], line.baseValues?.[f.code])) : []);

/** Human-readable value of a form value (option labels for dropdowns). */
export const showValue = (f, v) => {
  if (f.type === 'set') return (v || []).map((id) => optLabel(f, id)).join(', ');
  const s = String(v ?? '').trim();
  return f.type === 'enum' && s ? optLabel(f, s) : s;
};

/** Mirrors the server's naming: Pipe_OD:70_WT:3 mm */
export const suffixPreview = (baseName, fields, line) => {
  const chosen = changedFields(line, fields).filter((f) => (line.suffixCodes || []).includes(f.code));
  return chosen.length ? `${baseName}_${chosen.map((f) => `${f.name}:${showValue(f, line.values[f.code]) || 'none'}`).join('_')}` : baseName;
};

export function validateField(f, v) {
  if (f.type === 'set') return null;
  const s = String(v ?? '').trim();
  if (s === '') return null;
  if (f.type === 'double' || f.type === 'int') {
    const n = Number(s.replace(/,/g, ''));
    if (!Number.isFinite(n)) return `${f.name} must be a number.`;
    if (f.type === 'int' && !Number.isInteger(n)) return `${f.name} must be a whole number.`;
  }
  if (f.type === 'varchar' && s.length > 255) return `${f.name} is too long.`;
  if (f.type === 'date' && !/^\d{4}-\d{2}-\d{2}$/.test(s)) return `${f.name} must be a date.`;
  return null;
}
