import React, { useEffect, useRef, useState } from 'react';

/** A dropdown panel anchored to an element, positioned against the viewport so scrolling tables never clip it. */
export default function Popover({ anchor, open, onClose, children, minWidth = 220, className = '' }) {
  const ref = useRef(null);
  const [pos, setPos] = useState(null);

  useEffect(() => {
    if (!open) return undefined;
    const update = () => {
      const r = anchor.current?.getBoundingClientRect();
      if (!r) return;
      const below = window.innerHeight - r.bottom;
      const flip = below < 260 && r.top > below;
      setPos({
        left: Math.max(4, Math.min(r.left, window.innerWidth - Math.max(r.width, minWidth) - 4)),
        width: Math.max(r.width, minWidth),
        ...(flip ? { bottom: window.innerHeight - r.top + 4, maxHeight: Math.max(140, r.top - 12) }
                 : { top: r.bottom + 4, maxHeight: Math.max(140, below - 12) }),
      });
    };
    update();
    const down = (e) => { if (!ref.current?.contains(e.target) && !anchor.current?.contains(e.target)) onClose?.(); };
    window.addEventListener('scroll', update, true);
    window.addEventListener('resize', update);
    document.addEventListener('mousedown', down);
    return () => {
      window.removeEventListener('scroll', update, true); window.removeEventListener('resize', update);
      document.removeEventListener('mousedown', down);
    };
  }, [open, anchor, onClose, minWidth]);

  if (!open) return null;
  return <div ref={ref} className={`dropdown ${className}`} style={pos || { visibility: 'hidden' }}>{children}</div>;
}
