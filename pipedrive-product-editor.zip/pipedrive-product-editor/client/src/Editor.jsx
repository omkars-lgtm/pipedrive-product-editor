import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { api } from './api.js';
import { closeModal, embedded, resizeTo, snackbar } from './pd.js';
import { lineTotals, money, sumTotals } from './calc.js';
import ProductInput from './ProductInput.jsx';
import RichText from './RichText.jsx';
import FieldInput from './FieldInput.jsx';
import { blankForm, changedFields, formFromServer, showValue, suffixPreview, validateField } from './fields.js';
import { AuthCard, Banner, Spinner } from './Shared.jsx';

let seq = 0;
const newKey = () => `n${++seq}`;
const s = (v) => (v === null || v === undefined ? '' : String(v));
const parse = (v) => (String(v).trim() === '' ? null : Number(String(v).replace(/,/g, '')));

const fromServer = (l, vf, cur) => ({
  key: `d${l.dealProductId}`, dealProductId: l.dealProductId, productId: l.productId, name: l.name, code: l.code,
  itemPrice: s(l.itemPrice), quantity: s(l.quantity), discount: s(l.discount), discountType: l.discountType,
  tax: s(l.tax), comments: l.comments || '', isEnabled: l.isEnabled,
  values: formFromServer(l.values, vf, cur), baseValues: formFromServer(l.values, vf, cur), suffixCodes: [], expanded: false, details: l.details || [],
});
const blankLine = (vf, cur) => ({
  key: newKey(), dealProductId: null, productId: null, name: '', code: null, itemPrice: '0', quantity: '1',
  discount: '0', discountType: 'percentage', tax: '0', comments: '', isEnabled: true,
  values: blankForm(vf, cur), baseValues: blankForm(vf, cur), suffixCodes: [], expanded: true, details: [],
});
const snapshot = (lines, removed, taxMethod) => JSON.stringify({ taxMethod, removed, lines: lines.map(({ expanded, error, warning, details, ...rest }) => rest) });

export function validateLine(l, vf = []) {
  const e = [];
  if (!l.productId && !l.name.trim()) e.push('Choose a product or type a name.');
  const price = parse(l.itemPrice); if (price === null || !Number.isFinite(price) || price < 0) e.push('Price must be 0 or more.');
  const qty = parse(l.quantity); if (qty === null || !Number.isFinite(qty) || qty <= 0) e.push('Quantity must be greater than 0.');
  const disc = parse(l.discount) ?? 0; if (!Number.isFinite(disc) || disc < 0 || (l.discountType === 'percentage' && disc > 100)) e.push('Discount is not valid.');
  const tax = parse(l.tax) ?? 0; if (!Number.isFinite(tax) || tax < 0 || tax > 100) e.push('Tax % must be between 0 and 100.');
  for (const f of vf) { const m = validateField(f, l.values?.[f.code]); if (m) e.push(m); }
  const byName = (n) => vf.find((f) => f.name.trim().toLowerCase() === n && (f.type === 'double' || f.type === 'int'));
  const fmin = byName('min'); const fmax = byName('max');
  if (fmin && fmax) {
    const a = parse(l.values[fmin.code]); const b = parse(l.values[fmax.code]);
    if (a !== null && b !== null && Number.isFinite(a) && Number.isFinite(b) && a > b) e.push(`${fmin.name} cannot be greater than ${fmax.name}.`);
  }
  if (l.comments.replace(/<[^>]*>/g, '').length > 2000) e.push('Comments are limited to 2000 characters.');
  return e;
}


export default function Editor({ dealId, mode, onDone }) {
  const [phase, setPhase] = useState('loading');
  const [loadError, setLoadError] = useState(null);
  const [deal, setDeal] = useState(null);
  const [taxMethod, setTaxMethod] = useState('inclusive');
  const [fieldsMsg, setFieldsMsg] = useState(null);
  const [vf, setVf] = useState([]);
  const [currencies, setCurrencies] = useState([]);
  const [lines, setLines] = useState([]);
  const [removed, setRemoved] = useState([]);
  const [initial, setInitial] = useState('');
  const [saving, setSaving] = useState(false);
  const [banner, setBanner] = useState(null);
  const [confirmDiscard, setConfirmDiscard] = useState(false);
  const root = useRef(null);

  const load = useCallback(async () => {
    setPhase('loading'); setLoadError(null);
    const r = await api('GET', `/api/deals/${dealId}/bootstrap`);
    if (!r.ok) { setLoadError(r.json || { error: 'Could not load the deal.' }); setPhase('error'); return; }
    const fields = r.json.variantFields || [];
    const ls = r.json.lines.map((l) => fromServer(l, fields, r.json.deal.currency));
    setCurrencies(r.json.currencies || []);
    setDeal(r.json.deal); setTaxMethod(r.json.taxMethod); setFieldsMsg(r.json.fieldsMessage); setVf(fields);
    setLines(ls); setRemoved([]); setInitial(snapshot(ls, [], r.json.taxMethod)); setPhase('ready');
  }, [dealId]);
  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (mode !== 'inline' || !root.current) return undefined;
    const ro = new ResizeObserver(() => resizeTo(root.current.scrollHeight + 8));
    ro.observe(root.current);
    return () => ro.disconnect();
  }, [mode, phase]);

  const dirty = useMemo(() => phase === 'ready' && snapshot(lines, removed, taxMethod) !== initial, [lines, removed, taxMethod, initial, phase]);
  const totals = useMemo(() => sumTotals(lines, taxMethod), [lines, taxMethod]);
  const currency = deal?.currency || 'USD';

  const patch = (key, p) => setLines((ls) => ls.map((l) => (l.key === key ? { ...l, ...p, error: undefined } : l)));
  const pickProduct = (key, p) => patch(key, {
    productId: p.id, name: p.name, code: p.code, itemPrice: s(p.price), tax: s(p.tax ?? 0), expanded: true,
    values: formFromServer(p.values, vf, deal?.currency), baseValues: formFromServer(p.values, vf, deal?.currency), suffixCodes: [], details: p.details || [],
  });
  const clearProduct = (key) => patch(key, { productId: null, name: '', code: null, values: blankForm(vf, deal?.currency), baseValues: blankForm(vf, deal?.currency), suffixCodes: [], details: [] });
  const setValue = (l, code, v) => patch(l.key, { values: { ...l.values, [code]: v } });
  const toggleSuffix = (l, code) => patch(l.key, { suffixCodes: l.suffixCodes.includes(code) ? l.suffixCodes.filter((c) => c !== code) : [...l.suffixCodes, code] });
  const removeLine = (l) => {
    setLines((ls) => ls.filter((x) => x.key !== l.key));
    if (l.dealProductId) setRemoved((r) => [...r, l.dealProductId]);
  };
  const allOpen = lines.length > 0 && lines.every((l) => l.expanded);

  async function save() {
    setBanner(null);
    let bad = false;
    const checked = lines.map((l) => { const e = validateLine(l, vf); if (e.length) bad = true; return { ...l, error: e.length ? e.join(' ') : undefined, expanded: l.expanded || e.length > 0 }; });
    if (bad) { setLines(checked); setBanner({ kind: 'error', text: 'Please fix the highlighted rows.' }); return; }
    if (!dirty) { finish('No changes to save.'); return; }
    setSaving(true);
    const payload = {
      taxMethod, removedDealProductIds: removed,
      lines: lines.map((l) => ({
        key: l.key, dealProductId: l.dealProductId, productId: l.productId, name: l.name, code: l.code,
        values: l.values, suffixCodes: l.suffixCodes.filter((c) => changedFields(l, vf).some((f) => f.code === c)), itemPrice: l.itemPrice, quantity: l.quantity, discount: l.discount,
        discountType: l.discountType, tax: l.tax, comments: l.comments, isEnabled: l.isEnabled,
      })),
    };
    const r = await api('POST', `/api/deals/${dealId}/save`, payload);
    setSaving(false);

    if (r.status === 200 && r.json?.ok) {
      const sm = r.json.summary;
      const parts = [];
      if (sm.created.length) parts.push(`${sm.created.length} new product${sm.created.length > 1 ? 's' : ''} added to the Products list (${sm.created.join(', ')})`);
      if (sm.reused.length) parts.push(`${sm.reused.length} existing variant${sm.reused.length > 1 ? 's' : ''} reused`);
      if (sm.attached) parts.push(`${sm.attached} added to the deal`);
      if (sm.updated) parts.push(`${sm.updated} updated`);
      if (sm.removed) parts.push(`${sm.removed} removed`);
      finish(parts.length ? `Saved: ${parts.join(', ')}.` : 'Saved.');
      return;
    }
    if (r.status === 422) {
      const le = r.json.lineErrors || {};
      setLines((ls) => ls.map((l) => (le[l.key] ? { ...l, error: le[l.key].join(' '), expanded: true } : l)));
      setBanner({ kind: 'error', text: r.json.error || 'Please fix the highlighted rows.' });
      return;
    }
    if (r.status === 207 && r.json?.results) {
      const byKey = new Map(r.json.results.map((x) => [x.key, x]));
      const pending = r.json.results.flatMap((x) => x.pendingDeletes || []);
      const deletedOk = new Set((r.json.deleted || []).filter((d) => d.ok).map((d) => d.id));
      setLines((ls) => ls.map((l) => {
        const x = byKey.get(l.key);
        if (!x) return l;
        if (!x.ok) return { ...l, error: x.error, expanded: true };
        return { ...l, dealProductId: x.dealProductId, productId: x.productId ?? l.productId, baseValues: l.values, suffixCodes: [], error: undefined, warning: x.warning };
      }));
      setRemoved((rem) => [...new Set([...rem.filter((id) => !deletedOk.has(id)), ...pending])]);
      const failed = r.json.results.filter((x) => !x.ok).length + (r.json.deleted || []).filter((d) => !d.ok).length;
      setBanner({ kind: 'error', text: `${failed ? `${failed} item${failed > 1 ? 's' : ''} could not be saved.` : 'Saved with warnings.'} Everything else was saved. Fix the marked rows and press Save again. Retrying is safe.` });
      setInitial(snapshot([], [], taxMethod) + 'stale'); // force "dirty" so Save stays available
      return;
    }
    if (r.json?.code === 'NOT_AUTHORIZED') { setLoadError(r.json); setPhase('error'); return; }
    setBanner({ kind: 'error', text: r.json?.error || 'Saving failed.' });
  }

  async function finish(message) {
    snackbar(message);
    if (!embedded) { // standalone test mode: nothing to close, so show the result here
      setBanner({ kind: 'success', text: message });
      await load();
      setBanner({ kind: 'success', text: message });
      return;
    }
    if (mode === 'modal') { await closeModal(); } else { onDone?.(message); }
  }
  const cancel = () => {
    if (dirty && !confirmDiscard) { setConfirmDiscard(true); return; }
    if (mode === 'modal') closeModal(); else onDone?.();
  };

  if (phase === 'loading') return <div className="editor" ref={root}><Spinner label="Loading deal products…" /></div>;
  if (phase === 'error') {
    return (
      <div className="editor" ref={root}>
        {loadError?.code === 'NOT_AUTHORIZED'
          ? <AuthCard authorizeUrl={loadError.authorizeUrl} onRetry={load} />
          : <Banner kind="error">{loadError?.error || 'Could not load.'} <button type="button" className="btn small" onClick={load}>Retry</button></Banner>}
      </div>
    );
  }

  return (
    <div className={`editor ${mode}`} ref={root}>
      <header className="ed-head"><h2>Add products to deal - {deal.title}</h2></header>
      <div className="ed-body">
        {fieldsMsg && <Banner kind="info">{fieldsMsg}</Banner>}
        {banner && <Banner kind={banner.kind} onClose={() => setBanner(null)}>{banner.text}</Banner>}

        <div className="top-row">
          <label>Deal currency
            <select value={currency} disabled aria-label="Deal currency"><option>{currency}</option></select>
          </label>
          <label>Amounts are
            <select value={taxMethod} onChange={(e) => setTaxMethod(e.target.value)} aria-label="Amounts are">
              <option value="inclusive">Tax inclusive</option><option value="exclusive">Tax exclusive</option><option value="none">No tax</option>
            </select>
          </label>
        </div>

        <div className="table-wrap">
          <div className="grid head" role="row">
            <span /> <span>Product</span><span>Price</span><span>Quantity</span><span>Discount</span><span>Tax %</span><span>Amount</span>
            <span><button type="button" className="btn small" onClick={() => setLines((ls) => ls.map((l) => ({ ...l, expanded: !allOpen })))}>{allOpen ? 'Collapse all' : 'Expand all'}</button></span>
          </div>
          {lines.length === 0 && <div className="empty">No products on this deal yet. Add one below.</div>}
          {lines.map((l) => {
            const t = lineTotals(l, taxMethod);
            const changed = changedFields(l, vf);
            return (
              <div key={l.key} className={`row ${l.error ? 'has-error' : ''}`}>
                <div className="grid" role="row">
                  <label className="toggle" title={l.isEnabled ? 'Enabled' : 'Disabled'}>
                    <input type="checkbox" checked={l.isEnabled} onChange={(e) => patch(l.key, { isEnabled: e.target.checked })} aria-label="Enabled" />
                    <span className="slider" />
                  </label>
                  <ProductInput line={l} currency={currency} variantFields={vf} autoFocus={!l.dealProductId && !l.name}
                    onPick={(p) => pickProduct(l.key, p)} onType={(v) => patch(l.key, { name: v })} onClear={() => clearProduct(l.key)} />
                  <input inputMode="decimal" value={l.itemPrice} onChange={(e) => patch(l.key, { itemPrice: e.target.value })} aria-label="Price" />
                  <input inputMode="decimal" value={l.quantity} onChange={(e) => patch(l.key, { quantity: e.target.value })} aria-label="Quantity" />
                  <span className="disc">
                    <select value={l.discountType} onChange={(e) => patch(l.key, { discountType: e.target.value })} aria-label="Discount type">
                      <option value="percentage">%</option><option value="amount">{currency}</option>
                    </select>
                    <input inputMode="decimal" value={l.discount} onChange={(e) => patch(l.key, { discount: e.target.value })} aria-label="Discount" />
                  </span>
                  <input inputMode="decimal" value={l.tax} onChange={(e) => patch(l.key, { tax: e.target.value })} aria-label="Tax %" />
                  <output className="amount" aria-label="Amount">{money(t.amount, currency)}</output>
                  <span className="actions">
                    <button type="button" className="icon-btn" aria-label={l.expanded ? 'Collapse row' : 'Expand row'} onClick={() => patch(l.key, { expanded: !l.expanded })}>{l.expanded ? '▴' : '▾'}</button>
                    <button type="button" className="icon-btn danger" aria-label="Remove product" onClick={() => removeLine(l)}>🗑</button>
                  </span>
                </div>
                {changed.length > 0 && (
                  <div className="hint variant-hint">
                    <div>You changed {changed.map((f) => f.name).join(', ')}. On save, a new product with these values is created in the Products list (or an identical one is reused). The original product stays unchanged.</div>
                    <div className="suffix-pick">
                      <span>Add to product name:</span>
                      {changed.map((f) => (
                        <label key={f.code} className="check">
                          <input type="checkbox" checked={l.suffixCodes.includes(f.code)} onChange={() => toggleSuffix(l, f.code)} aria-label={`Add ${f.name} to product name`} />
                          {f.name}: {showValue(f, l.values[f.code]) || 'none'}
                        </label>
                      ))}
                    </div>
                    <div className="muted">New product name: <strong>{suffixPreview(l.name, vf, l)}</strong></div>
                  </div>
                )}
                {l.warning && <div className="hint warn">{l.warning}</div>}
                {l.error && <div className="hint err" role="alert">{l.error}</div>}
                {l.expanded && <div className="expanded">
                  {vf.length > 0 && (
                    <div className="vfields" aria-label="Editable fields">
                      {vf.map((f) => (
                        <label key={f.code} className="vfield"><span>{f.name}</span>
                          <FieldInput field={f} currencies={currencies} value={l.values[f.code]} onChange={(v) => setValue(l, f.code, v)} />
                        </label>
                      ))}
                    </div>
                  )}
                  {l.details.some((d) => !d.variant) && (
                    <dl className="details" aria-label="Product details">
                      {l.details.filter((d) => !d.variant).map((d) => (
                        <React.Fragment key={d.label}><dt>{d.label}</dt><dd>{String(d.value ?? '').trim() === '' ? '–' : d.value}</dd></React.Fragment>
                      ))}
                    </dl>
                  )}
                  <RichText value={l.comments} onChange={(html) => patch(l.key, { comments: html })} />
                </div>}
              </div>
            );
          })}
        </div>

        <div className="below">
          <button type="button" className="btn" onClick={() => setLines((ls) => [...ls, blankLine(vf, deal?.currency)])}>+ Product</button>
          <span className="muted">Products: {lines.length} · Total product quantity: {lines.reduce((a, l) => a + (Number(l.quantity) || 0), 0)}</span>
        </div>

        <section className="summary" aria-label="Summary">
          <h4>Summary</h4>
          <dl>
            <dt>Subtotal excluding tax</dt><dd>{money(totals.excl, currency)}</dd>
            <dt>Tax</dt><dd>{money(totals.tax, currency)}</dd>
            <dt className="strong">Total</dt><dd className="strong">{money(totals.total, currency)}</dd>
          </dl>
        </section>
      </div>
      <footer className="ed-foot">
        {confirmDiscard ? (
          <>
            <span>Discard your changes?</span>
            <button type="button" className="btn" onClick={() => setConfirmDiscard(false)}>Keep editing</button>
            <button type="button" className="btn danger" onClick={() => (mode === 'modal' ? closeModal() : onDone?.())}>Discard</button>
          </>
        ) : (
          <>
            <button type="button" className="btn" onClick={cancel} disabled={saving}>Cancel</button>
            <button type="button" className="btn primary" onClick={save} disabled={saving}>
              {saving ? <><span className="spinner small" aria-hidden="true" /> Saving…</> : 'Save'}
            </button>
          </>
        )}
      </footer>
    </div>
  );
}
