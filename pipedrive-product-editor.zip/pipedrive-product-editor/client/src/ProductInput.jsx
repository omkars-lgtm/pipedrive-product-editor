import React, { useEffect, useRef, useState } from 'react';
import { api } from './api.js';

import { showValue, toForm } from './fields.js';
const meta = (p, vf) => (vf || []).map((f) => [f.name, showValue(f, toForm(p.values?.[f.code], f))]).filter(([, v]) => v !== '').slice(0, 3).map(([n, v]) => `${n} ${v}`).join(' · ');

/** Type-ahead against the master Products list. Selecting fills price, tax and the editable fields. */
export default function ProductInput({ line, currency, variantFields, onPick, onType, onClear, autoFocus }) {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState('');
  const [hi, setHi] = useState(-1);
  const seq = useRef(0);
  const wrap = useRef(null);
  const [pos, setPos] = useState(null);
  const term = line.name.trim();

  // The dropdown is positioned against the viewport so the table's scroll container can never clip it.
  useEffect(() => {
    if (!open) return undefined;
    const update = () => {
      const r = wrap.current?.getBoundingClientRect();
      if (!r) return;
      const below = window.innerHeight - r.bottom;
      const flip = below < 260 && r.top > below;
      setPos({
        left: Math.max(4, Math.min(r.left, window.innerWidth - 300)),
        width: Math.max(r.width, 300),
        ...(flip ? { bottom: window.innerHeight - r.top + 2, maxHeight: Math.max(140, r.top - 12) }
                 : { top: r.bottom + 2, maxHeight: Math.max(140, below - 12) }),
      });
    };
    update();
    window.addEventListener('scroll', update, true);
    window.addEventListener('resize', update);
    return () => { window.removeEventListener('scroll', update, true); window.removeEventListener('resize', update); };
  }, [open, items.length, loading]);

  useEffect(() => {
    if (!open || line.productId || term.length < 2) { setItems([]); setLoading(false); return undefined; }
    setLoading(true);
    const id = ++seq.current;
    const t = setTimeout(async () => {
      const r = await api('GET', `/api/products/search?q=${encodeURIComponent(term)}`);
      if (id !== seq.current) return; // a newer keystroke superseded this response
      setLoading(false);
      if (!r.ok) { setErr(r.json?.error || 'Search failed'); setItems([]); return; }
      setErr('');
      setItems(r.json.items || []);
      setHi(-1);
    }, 300);
    return () => clearTimeout(t);
  }, [term, open, line.productId]);

  const priceFor = (p) => (p.prices.find((x) => x.currency === currency) || p.prices[0] || { price: 0 }).price;
  const exact = items.some((p) => p.name.trim().toLowerCase() === term.toLowerCase());
  const canCreate = term.length >= 2 && !exact && !loading;
  const options = [...items.map((p) => ({ type: 'item', p })), ...(canCreate ? [{ type: 'create' }] : [])];

  const pick = (p) => { setOpen(false); onPick({ ...p, price: priceFor(p) }); };
  const onKey = (e) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setHi((h) => Math.min(h + 1, options.length - 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setHi((h) => Math.max(h - 1, 0)); }
    else if (e.key === 'Enter' && hi >= 0) { e.preventDefault(); const o = options[hi]; if (o.type === 'item') pick(o.p); else setOpen(false); }
    else if (e.key === 'Escape') setOpen(false);
  };

  if (line.productId) {
    return (
      <div className="picked" title={line.name}>
        <span className="picked-name">{line.name}</span>
        {line.code ? <span className="muted">{line.code}</span> : null}
        <button type="button" className="icon-btn" aria-label="Choose a different product" onClick={onClear}>×</button>
      </div>
    );
  }
  return (
    <div className="typeahead" ref={wrap}>
      <input value={line.name} placeholder="Start typing to search" aria-label="Product" autoFocus={autoFocus}
        onChange={(e) => { onType(e.target.value); setOpen(true); }} onFocus={() => setOpen(true)}
        onBlur={() => setTimeout(() => setOpen(false), 150)} onKeyDown={onKey} maxLength={255} />
      {term && !line.productId && !open && <div className="new-badge">New product: will be created in the Products list</div>}
      {open && term.length >= 2 && (
        <div className="dropdown" role="listbox" style={pos || { visibility: 'hidden' }}>
          {loading && <div className="dd-note">Searching…</div>}
          {err && <div className="dd-note error">{err}</div>}
          {options.map((o, i) => (
            <div key={o.type === 'item' ? o.p.id : 'create'} role="option" aria-selected={i === hi}
              className={`dd-item ${i === hi ? 'hi' : ''}`} onMouseDown={(e) => { e.preventDefault(); if (o.type === 'item') pick(o.p); else setOpen(false); }}>
              {o.type === 'item' ? (
                <>
                  <span className="dd-name">{o.p.name}</span>
                  <span className="muted">{[o.p.code, meta(o.p, variantFields)].filter(Boolean).join(' · ')}</span>
                </>
              ) : (
                <span className="dd-create">+ Create new product “{term}”</span>
              )}
            </div>
          ))}
          {!loading && !err && options.length === 0 && <div className="dd-note">No matches</div>}
        </div>
      )}
    </div>
  );
}
