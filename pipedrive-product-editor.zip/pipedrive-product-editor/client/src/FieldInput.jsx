import React from 'react';

/** One input for an editable product field, matching the field's type. */
export default function FieldInput({ field: f, value, onChange, currencies = [] }) {
  if (f.type === 'monetary') {
    const v = value && typeof value === 'object' ? value : { value: '', currency: '' };
    const list = [...new Set([...currencies, v.currency].filter(Boolean))];
    return (
      <span className="money-field">
        <input aria-label={f.name} inputMode="decimal" value={v.value ?? ''} onChange={(e) => onChange({ ...v, value: e.target.value })} />
        <select aria-label={`${f.name} currency`} value={v.currency || ''} onChange={(e) => onChange({ ...v, currency: e.target.value })}>
          {!v.currency && <option value="">–</option>}
          {list.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </span>
    );
  }
  if (f.type === 'time') return <input type="time" aria-label={f.name} value={value ?? ''} onChange={(e) => onChange(e.target.value)} />;
  if (f.type === 'enum') {
    return (
      <select aria-label={f.name} value={value ?? ''} onChange={(e) => onChange(e.target.value)}>
        <option value="">–</option>
        {(f.options || []).map((o) => <option key={o.id} value={String(o.id)}>{o.label}</option>)}
      </select>
    );
  }
  if (f.type === 'set') {
    const cur = new Set(value || []);
    return (
      <span className="checks" role="group" aria-label={f.name}>
        {(f.options || []).map((o) => (
          <label key={o.id} className="check">
            <input type="checkbox" checked={cur.has(String(o.id))}
              onChange={(e) => { const n = new Set(cur); if (e.target.checked) n.add(String(o.id)); else n.delete(String(o.id)); onChange([...n]); }} />
            {o.label}
          </label>
        ))}
      </span>
    );
  }
  if (f.type === 'text') return <textarea aria-label={f.name} rows={2} value={value ?? ''} onChange={(e) => onChange(e.target.value)} />;
  if (f.type === 'date') return <input type="date" aria-label={f.name} value={value ?? ''} onChange={(e) => onChange(e.target.value)} />;
  const numeric = f.type === 'double' || f.type === 'int';
  return <input aria-label={f.name} inputMode={numeric ? 'decimal' : undefined} type={f.type === 'phone' ? 'tel' : 'text'} maxLength={f.type === 'text' ? undefined : 255}
    value={value ?? ''} onChange={(e) => onChange(e.target.value)} />;
}
