import React, { useEffect, useRef, useState } from 'react';
import Popover from './Popover.jsx';
import { api } from './api.js';

const Chevron = () => <svg className="chev" width="10" height="6" viewBox="0 0 10 6" aria-hidden="true"><path d="M1 1l4 4 4-4" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" /></svg>;
const IconOrg = () => <svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true"><path d="M3 14V2.5h7V14M10 6h3v8M5.5 5h2M5.5 8h2M5.5 11h2" fill="none" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" /></svg>;
const IconPerson = () => <svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="5" r="2.6" fill="none" stroke="currentColor" strokeWidth="1.3" /><path d="M2.8 14c.4-2.7 2.5-4.2 5.2-4.2s4.8 1.5 5.2 4.2" fill="none" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" /></svg>;
const IconUser = IconPerson;
const ICONS = { org: IconOrg, people: IconPerson, user: IconUser };

/** Single option: a segmented control for a few short options (like Pipedrive), a searchable dropdown otherwise. */
function SingleOption({ field: f, value, onChange }) {
  const opts = f.options || [];
  const compact = opts.length <= 5 && opts.every((o) => o.label.length <= 22);
  const anchor = useRef(null);
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  if (compact) {
    return (
      <div className="segmented" role="radiogroup" aria-label={f.name}>
        <button type="button" role="radio" aria-checked={!value} className={!value ? 'on' : ''} onClick={() => onChange('')}>(None)</button>
        {opts.map((o) => (
          <button key={o.id} type="button" role="radio" aria-checked={String(value) === String(o.id)} className={String(value) === String(o.id) ? 'on' : ''}
            onClick={() => onChange(String(o.id))}>{o.label}</button>
        ))}
      </div>
    );
  }
  const cur = opts.find((o) => String(o.id) === String(value));
  const shown = opts.filter((o) => o.label.toLowerCase().includes(q.trim().toLowerCase()));
  return (
    <div ref={anchor} className="selectbox">
      <button type="button" className="select-trigger" aria-label={f.name} aria-haspopup="listbox" aria-expanded={open} onClick={() => setOpen((o) => !o)}>
        <span className={cur ? '' : 'ph'}>{cur ? cur.label : 'Select…'}</span><Chevron />
      </button>
      <Popover anchor={anchor} open={open} onClose={() => setOpen(false)}>
        <input className="dd-search" autoFocus placeholder="Search…" value={q} onChange={(e) => setQ(e.target.value)} aria-label={`Search ${f.name}`} />
        <div role="listbox">
          <div className="dd-item" role="option" aria-selected={!value} onMouseDown={(e) => { e.preventDefault(); onChange(''); setOpen(false); }}><span className="muted">(None)</span></div>
          {shown.map((o) => (
            <div key={o.id} className={`dd-item ${String(value) === String(o.id) ? 'sel' : ''}`} role="option" aria-selected={String(value) === String(o.id)}
              onMouseDown={(e) => { e.preventDefault(); onChange(String(o.id)); setOpen(false); }}>{o.label}</div>
          ))}
          {!shown.length && <div className="dd-note">No match found</div>}
        </div>
      </Popover>
    </div>
  );
}

/** Multiple options: a dropdown with checkboxes and a search box; picked values show as chips. */
function MultiOption({ field: f, value, onChange }) {
  const anchor = useRef(null);
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const cur = new Set(value || []);
  const opts = f.options || [];
  const toggle = (id) => { const n = new Set(cur); if (n.has(id)) n.delete(id); else n.add(id); onChange([...n]); };
  const shown = opts.filter((o) => o.label.toLowerCase().includes(q.trim().toLowerCase()));
  const picked = opts.filter((o) => cur.has(String(o.id)));
  return (
    <div ref={anchor} className="selectbox">
      <div className="select-trigger multi" role="button" tabIndex={0} aria-label={f.name} aria-haspopup="listbox" aria-expanded={open}
        onClick={() => setOpen((o) => !o)} onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setOpen((o) => !o); } }}>
        <span className="tags">
          {picked.length === 0 && <span className="ph">Select…</span>}
          {picked.map((o) => (
            <span key={o.id} className="tag">{o.label}
              <button type="button" aria-label={`Remove ${o.label}`} onClick={(e) => { e.stopPropagation(); toggle(String(o.id)); }}>×</button>
            </span>
          ))}
        </span>
        <Chevron />
      </div>
      <Popover anchor={anchor} open={open} onClose={() => setOpen(false)}>
        <input className="dd-search" autoFocus placeholder="Search…" value={q} onChange={(e) => setQ(e.target.value)} aria-label={`Search ${f.name}`} />
        <div role="listbox" aria-multiselectable="true">
          {shown.map((o) => (
            <label key={o.id} className="dd-item check-row" role="option" aria-selected={cur.has(String(o.id))}>
              <input type="checkbox" checked={cur.has(String(o.id))} onChange={() => toggle(String(o.id))} /> {o.label}
            </label>
          ))}
          {!shown.length && <div className="dd-note">No match found</div>}
        </div>
      </Popover>
    </div>
  );
}

/** User / organization / person picker with search. */
function Lookup({ field: f, value, onChange }) {
  const anchor = useRef(null);
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [items, setItems] = useState([]);
  const [state, setState] = useState('idle'); // idle | loading | error
  const [err, setErr] = useState('');
  const seq = useRef(0);
  const Icon = ICONS[f.type];

  useEffect(() => {
    if (!open) return undefined;
    setState('loading');
    const id = ++seq.current;
    const t = setTimeout(async () => {
      const r = await api('GET', `/api/lookup?type=${f.type}&q=${encodeURIComponent(q.trim())}`);
      if (id !== seq.current) return;
      if (!r.ok) { setErr(r.json?.error || 'Search failed'); setItems([]); setState('error'); return; }
      setItems(r.json.items || []); setState('idle');
    }, q ? 250 : 0);
    return () => clearTimeout(t);
  }, [q, open, f.type]);

  const pick = (it) => { onChange({ id: it.id, name: it.name }); setOpen(false); setQ(''); };
  const has = !!(value && (value.id || value.isNew));
  const term = q.trim();
  const canAdd = f.type !== 'user' && term.length >= 1 && state !== 'loading' && !items.some((it) => it.name.trim().toLowerCase() === term.toLowerCase());
  const addNew = () => { onChange({ id: null, isNew: true, name: term }); setOpen(false); setQ(''); };
  return (
    <div ref={anchor} className="lookup">
      <span className="lk-icon"><Icon /></span>
      {has && !open ? (
        <button type="button" className="lk-value" aria-label={f.name} onClick={() => setOpen(true)}>{value.name || `#${value.id}`}</button>
      ) : (
        <input aria-label={f.name} value={q} placeholder={has ? (value.name || `#${value.id}`) : (f.type === 'user' ? 'Select a user' : 'Start typing to search')}
          onChange={(e) => { setQ(e.target.value); setOpen(true); }} onFocus={() => setOpen(true)} />
      )}
      {value?.isNew && !open && <span className="badge-new">NEW</span>}
      {has && <button type="button" className="icon-btn lk-clear" aria-label={`Clear ${f.name}`} onClick={() => { onChange(null); setQ(''); }}>×</button>}
      {f.type === 'user' && !has && <Chevron />}
      <Popover anchor={anchor} open={open} onClose={() => { setOpen(false); setQ(''); }}>
        {state === 'loading' && <div className="dd-note">Searching…</div>}
        {state === 'error' && <div className="dd-note error">{err}</div>}
        {state === 'idle' && items.map((it) => (
          <div key={it.id} className="dd-item" role="option" onMouseDown={(e) => { e.preventDefault(); pick(it); }}>
            <span className="dd-name">{it.name}</span>{it.sub ? <span className="muted">{it.sub}</span> : null}
          </div>
        ))}
        {state === 'idle' && !items.length && !canAdd && <div className="dd-note">No match found</div>}
        {canAdd && (
          <div className="dd-item dd-add" role="option" onMouseDown={(e) => { e.preventDefault(); addNew(); }}>
            <span>+ Add “{term}” as new {f.type === 'org' ? 'organization' : 'contact'}</span>
          </div>
        )}
      </Popover>
    </div>
  );
}

const IconPin = () => <svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true"><path d="M8 14.5s4.5-4.1 4.5-7.6A4.5 4.5 0 0 0 3.5 6.900C3.500 10.400 8 14.500 8 14.500z" fill="none" stroke="currentColor" strokeWidth="1.300" strokeLinejoin="round" /><circle cx="8" cy="6.800" r="1.600" fill="none" stroke="currentColor" strokeWidth="1.300" /></svg>;

/** Free text with suggestions: previous values (autocomplete fields) or places (address fields). */
function SuggestInput({ field: f, value, onChange }) {
  const kind = f.type === 'address' ? 'address' : 'field';
  const anchor = useRef(null);
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState([]);
  const [provider, setProvider] = useState(null);
  const seq = useRef(0);
  const text = value ?? '';

  useEffect(() => {
    const min = kind === 'address' ? 3 : 1;
    if (!open || text.trim().length < min) { setItems([]); return undefined; }
    const id = ++seq.current;
    const t = setTimeout(async () => {
      const qs = kind === 'address' ? `kind=address&q=${encodeURIComponent(text.trim())}` : `kind=field&code=${f.code}&q=${encodeURIComponent(text.trim())}`;
      const r = await api('GET', `/api/suggest?${qs}`);
      if (id !== seq.current) return;
      const list = r.ok ? (r.json.items || []).filter((x) => x !== text.trim()) : [];
      setItems(list); setProvider(r.ok ? r.json.provider : null);
    }, 300);
    return () => clearTimeout(t);
  }, [text, open, kind, f.code]);

  const pick = (v) => { onChange(v); setOpen(false); setItems([]); };
  return (
    <div ref={anchor} className={kind === 'address' ? 'lookup' : ''}>
      {kind === 'address' && <span className="lk-icon"><IconPin /></span>}
      <input aria-label={f.name} value={text} maxLength={255} autoComplete="off"
        onChange={(e) => { onChange(e.target.value); setOpen(true); }} onFocus={() => setOpen(true)} onKeyDown={(e) => { if (e.key === 'Escape') setOpen(false); }} />
      <Popover anchor={anchor} open={open && items.length > 0} onClose={() => setOpen(false)}>
        {items.map((it) => (
          <div key={it} className="dd-item sug" role="option" onMouseDown={(e) => { e.preventDefault(); pick(it); }}>
            {kind === 'address' && <span className="lk-icon"><IconPin /></span>}<span>{it}</span>
          </div>
        ))}
        {kind === 'address' && provider && <div className="dd-foot">{provider === 'google' ? 'powered by Google' : 'Suggestions © OpenStreetMap contributors'}</div>}
      </Popover>
    </div>
  );
}

/** One input for an editable product field, styled after Pipedrive's own product form. */
export default function FieldInput({ field: f, value, onChange, currencies = [] }) {
  switch (f.type) {
    case 'enum': return <SingleOption field={f} value={value} onChange={onChange} />;
    case 'set': return <MultiOption field={f} value={value} onChange={onChange} />;
    case 'user': case 'org': case 'people': return <Lookup field={f} value={value} onChange={onChange} />;
    case 'address': case 'varchar_auto': return <SuggestInput field={f} value={value} onChange={onChange} />;
    case 'monetary': {
      const v = value && typeof value === 'object' ? value : { value: '', currency: '' };
      const list = currencies.some((c) => c.code === v.currency) || !v.currency ? currencies : [...currencies, { code: v.currency, name: v.currency }];
      return (
        <span className="money-field">
          <input aria-label={f.name} inputMode="decimal" value={v.value ?? ''} onChange={(e) => onChange({ ...v, value: e.target.value })} />
          <span className="selectwrap">
            <select aria-label={`${f.name} currency`} value={v.currency || ''} onChange={(e) => onChange({ ...v, currency: e.target.value })}>
              {!v.currency && <option value="">–</option>}
              {list.map((c) => <option key={c.code} value={c.code}>{c.name} ({c.code})</option>)}
            </select><Chevron />
          </span>
        </span>
      );
    }
    case 'daterange': case 'timerange': {
      const v = value && typeof value === 'object' ? value : { from: '', to: '' };
      const t = f.type === 'timerange' ? 'time' : 'date';
      return (
        <span className="range">
          <input type={t} aria-label={`${f.name} from`} value={v.from || ''} onChange={(e) => onChange({ ...v, from: e.target.value })} />
          <span className="dash" aria-hidden="true">-</span>
          <input type={t} aria-label={`${f.name} to`} value={v.to || ''} onChange={(e) => onChange({ ...v, to: e.target.value })} />
        </span>
      );
    }
    case 'text': return <textarea aria-label={f.name} rows={3} value={value ?? ''} onChange={(e) => onChange(e.target.value)} />;
    case 'date': return <input type="date" aria-label={f.name} value={value ?? ''} onChange={(e) => onChange(e.target.value)} />;
    case 'time': return <input type="time" aria-label={f.name} value={value ?? ''} onChange={(e) => onChange(e.target.value)} />;
    default: {
      const numeric = f.type === 'double' || f.type === 'int';
      return <input aria-label={f.name} inputMode={numeric ? 'decimal' : undefined} type={f.type === 'phone' ? 'tel' : 'text'} maxLength={255}
        value={value ?? ''} onChange={(e) => onChange(e.target.value)} />;
    }
  }
}
