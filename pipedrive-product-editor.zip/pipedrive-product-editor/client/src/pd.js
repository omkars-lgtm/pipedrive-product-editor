// Pipedrive Custom UI SDK wrapper. Outside Pipedrive (no parent frame) the SDK is skipped.
// A page opened directly with ?token=<signed JWT> works in "standalone" mode, which is only useful for testing:
// the server still verifies the token signature, so this grants nothing extra.
import AppExtensionsSDK, { Command, Modal, Event } from '@pipedrive/app-extensions-sdk';

export const params = new URLSearchParams(window.location.search);
export const embedded = window.self !== window.top;
export const standaloneToken = !embedded ? params.get('token') : null;

let sdkPromise = null;
export function getSdk(size) {
  if (!embedded) return Promise.resolve(null);
  if (!sdkPromise) {
    sdkPromise = new AppExtensionsSDK().initialize(size ? { size } : undefined).catch((e) => {
      sdkPromise = null;
      throw e;
    });
  }
  return sdkPromise;
}

let cached = { token: null, at: 0 };
export async function getToken() {
  if (standaloneToken) return standaloneToken;
  const sdk = await getSdk();
  if (!sdk) return null;
  if (cached.token && Date.now() - cached.at < 4 * 60_000) return cached.token; // tokens live 5 minutes
  const { token } = await sdk.execute(Command.GET_SIGNED_TOKEN);
  cached = { token, at: Date.now() };
  return token;
}

/** The deal id from the iframe URL (selectedIds for panels, dealId when passed to a modal). */
export function getDealId() {
  const direct = params.get('dealId');
  if (direct && /^\d+$/.test(direct)) return Number(direct);
  const sel = (params.get('selectedIds') || '').split(',').filter(Boolean);
  if (sel.length === 1 && /^\d+$/.test(sel[0])) return Number(sel[0]);
  return null;
}

export async function resizeTo(height) {
  try { const sdk = await getSdk(); await sdk?.execute(Command.RESIZE, { height: Math.ceil(height) }); } catch { /* not resizable here */ }
}

export async function snackbar(message) {
  try { const sdk = await getSdk(); await sdk?.execute(Command.SHOW_SNACKBAR, { message }); } catch { /* optional */ }
}

export async function closeModal() {
  try { const sdk = await getSdk(); await sdk?.execute(Command.CLOSE_MODAL); } catch { /* not in a modal */ }
}

export async function openEditorModal(actionId, dealId) {
  const sdk = await getSdk();
  if (!sdk) return false;
  await sdk.execute(Command.OPEN_MODAL, { type: Modal.CUSTOM_MODAL, action_id: actionId, data: { dealId: String(dealId) } });
  return true;
}

export async function onModalClosed(handler) {
  const sdk = await getSdk();
  if (!sdk) return () => {};
  return sdk.listen(Event.CLOSE_CUSTOM_MODAL, handler);
}

/**
 * Size to request for the editor popup. Pipedrive limits a custom modal to the browser window, so we ask for
 * a large size based on the screen and let Pipedrive clamp it. Minimums per Pipedrive docs: 320 x 120.
 */
export function modalSize() {
  const w = Math.max(320, Math.min(1400, (window.screen?.availWidth || 1280) - 60));
  const h = Math.max(320, Math.min(900, (window.screen?.availHeight || 800) - 90));
  return { width: w, height: h };
}
