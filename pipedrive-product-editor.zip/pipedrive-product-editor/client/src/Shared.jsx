import React from 'react';

export const Spinner = ({ label = 'Loading…' }) => (
  <div className="center" role="status"><span className="spinner" aria-hidden="true" /> {label}</div>
);

export const Banner = ({ kind = 'error', children, onClose }) => (
  <div className={`banner ${kind}`} role={kind === 'error' ? 'alert' : 'status'}>
    <div>{children}</div>
    {onClose && <button type="button" className="icon-btn" aria-label="Dismiss" onClick={onClose}>×</button>}
  </div>
);

/** Shown when this Pipedrive user has not authorized the app yet (or authorization expired). */
export function AuthCard({ authorizeUrl = '/auth/pipedrive', onRetry }) {
  return (
    <div className="card">
      <h3>Authorization needed</h3>
      <p>This app needs your permission to read and update deal products. The sign-in opens in a new tab.</p>
      <p>
        <a className="btn primary" href={authorizeUrl} target="_blank" rel="noopener noreferrer">Authorize</a>{' '}
        <button type="button" className="btn" onClick={onRetry}>I’ve authorized, reload</button>
      </p>
    </div>
  );
}

export const OpenFromDeal = () => (
  <div className="card">
    <h3>Open this from a deal</h3>
    <p>This app needs a single deal. Open a deal in Pipedrive and find it in the deal details.</p>
  </div>
);
