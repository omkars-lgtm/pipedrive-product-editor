import { getToken } from './pd.js';

/** Returns { ok, status, json }. Never throws for HTTP errors, only for network failures. */
export async function api(method, path, body) {
  const token = await getToken();
  let res;
  try {
    res = await fetch(path, {
      method,
      headers: { 'Content-Type': 'application/json', ...(token ? { 'x-pd-token': token } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    return { ok: false, status: 0, json: { error: 'Could not reach the server. Check your connection and try again.', code: 'NETWORK' } };
  }
  let json = null;
  try { json = await res.json(); } catch { /* no body */ }
  return { ok: res.ok, status: res.status, json };
}

let configPromise = null;
export function getConfig() {
  configPromise ||= fetch('/api/config').then((r) => r.json()).catch(() => ({ modalActionId: null }));
  return configPromise;
}
