import React from 'react';
import { createRoot } from 'react-dom/client';
import { embedded, getDealId, getSdk, modalSize, standaloneToken } from './pd.js';
import Panel from './Panel.jsx';
import Editor from './Editor.jsx';
import { OpenFromDeal } from './Shared.jsx';
import './styles.css';

const isModal = window.location.pathname.startsWith('/modal');

// The SDK must be initialised first so Pipedrive knows the extension has loaded.
if (embedded) getSdk(isModal ? modalSize() : { height: 320 }).catch(() => {});

function ModalPage() {
  const dealId = getDealId();
  if (!dealId || (!embedded && !standaloneToken)) return <OpenFromDeal />;
  return <Editor dealId={dealId} mode="modal" />;
}

createRoot(document.getElementById('root')).render(isModal ? <ModalPage /> : <Panel />);
