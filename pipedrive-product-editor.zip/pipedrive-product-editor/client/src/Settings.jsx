import React, { useCallback, useEffect, useState } from 'react';
import { api } from './api.js';
import { AuthCard, Banner, Spinner } from './Shared.jsx';

const TYPE_LABEL = { varchar: 'Text', text: 'Long text', double: 'Number', int: 'Whole number', enum: 'Dropdown', set: 'Multiple choice', date: 'Date' };

/** Admin screen: which product fields may users change on a deal? Changing one creates a new product in the Products list. */
export default function Settings({ onDone }) {
  const [phase, setPhase] = useState('loading');
  const [err, setErr] = useState(null);
  const [data, setData] = useState(null);
  const [selected, setSelected] = useState([]);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState(null);

  const load = useCallback(async () => {
    setPhase('loading'); setErr(null);
    const r = await api('GET', '/api/settings');
    if (!r.ok) { setErr(r.json || { error: 'Could not load settings.' }); setPhase('error'); return; }
    setData(r.json); setSelected(r.json.selected); setPhase('ready');
  }, []);
  useEffect(() => { load(); }, [load]);

  async function save() {
    setSaving(true); setMsg(null);
    const r = await api('PUT', '/api/settings', { variantFieldCodes: selected });
    setSaving(false);
    if (r.ok) { setMsg({ kind: 'success', text: 'Saved. Users will see these fields the next time they open a deal.' }); setData((d) => ({ ...d, isDefault: false })); return; }
    setMsg({ kind: 'error', text: r.json?.error || 'Could not save.' });
  }
  const toggle = (code) => setSelected((s) => (s.includes(code) ? s.filter((c) => c !== code) : [...s, code]));

  if (phase === 'loading') return <div className="editor"><Spinner label="Loading settings…" /></div>;
  if (phase === 'error') {
    return <div className="editor">{err?.code === 'NOT_AUTHORIZED'
      ? <AuthCard authorizeUrl={err.authorizeUrl} onRetry={load} />
      : <Banner kind="error">{err?.error}</Banner>}</div>;
  }
  return (
    <div className="editor inline settings">
      <header className="ed-head"><h2>Editable product fields</h2></header>
      <div className="ed-body">
        <p>Choose which product fields users may change on a deal. When a user changes one for an existing product, the app creates a <strong>new product</strong> in the Products list with the new values (the original is never edited). Only custom fields are listed.</p>
        {data.isDefault && <Banner kind="info">Nothing has been chosen yet, so the fields named “Min” and “Max” (if they exist) are used. Press Save to make your choice official.</Banner>}
        {!data.isAdmin && <Banner kind="info">Only Pipedrive admins can change this. You can see the current choice.</Banner>}
        {msg && <Banner kind={msg.kind} onClose={() => setMsg(null)}>{msg.text}</Banner>}
        {data.candidates.length === 0 && <p className="muted">There are no custom product fields yet. Add them in Pipedrive under Settings, Data fields, Products.</p>}
        <ul className="field-list">
          {data.candidates.map((c) => (
            <li key={c.code}>
              <label className="check">
                <input type="checkbox" disabled={!data.isAdmin} checked={selected.includes(c.code)} onChange={() => toggle(c.code)} aria-label={c.name} />
                <span>{c.name}</span> <span className="chip">{TYPE_LABEL[c.type] || c.type}</span>
              </label>
            </li>
          ))}
        </ul>
      </div>
      <footer className="ed-foot">
        {onDone && <button type="button" className="btn" onClick={onDone}>Close</button>}
        <button type="button" className="btn primary" onClick={save} disabled={saving || !data.isAdmin}>{saving ? 'Saving…' : 'Save'}</button>
      </footer>
    </div>
  );
}
